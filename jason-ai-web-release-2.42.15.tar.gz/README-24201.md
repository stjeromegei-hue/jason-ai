# JASON AI — Phase 24201

## Persistent authentication

Web/PWA and private Android clients now share database-backed authentication when `DATABASE_URL` is configured.

- PostgreSQL users and sessions survive restarts.
- Email verification tokens are persisted.
- Password reset tokens are persisted.
- Logout revokes the database session.
- The existing in-memory auth remains the development fallback when no database is configured.
- Production reset requests never return the reset token in the API response.

Migration: `24201_auth_persistence.sql`.

## Client contract

Both clients use the same HTTPS API and session cookie. The Android client must point at the deployed JASON API; it does not contain AI provider secrets.
