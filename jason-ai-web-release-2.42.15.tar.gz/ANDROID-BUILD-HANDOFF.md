# JASON AI — Android Private APK Build Handoff

The repository contains the Capacitor Android project. A signed APK is **not** included in this release because the build environment does not contain the Android SDK and Gradle/Gradle Wrapper.

## Required build machine

- JDK 17+
- Android SDK Platform 35
- Android Build Tools 35.x
- Gradle 8.x compatible with the Android Gradle Plugin used by the project, or a generated Gradle Wrapper
- Node.js 20+

## Build

```bash
npm ci
npm run build
npx cap sync android
cd android
./gradlew assembleRelease
```

Configure `JASON_API_BASE` in `android/app/build.gradle` to the real HTTPS JASON API endpoint before release signing.

## Signing

Use an externally managed release keystore. Never commit the keystore, passwords, API keys, or production secrets. Configure signing through Gradle properties or the CI secret store.

## Install privately

The resulting release APK can be distributed directly to authorized Android devices. Google Play publication is not required for private/direct installation.
