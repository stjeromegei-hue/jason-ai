# JASON AI Production Deployment

Required environment: DATABASE_URL, PORT, REQUIRE_DATABASE=true.
Optional AI: AI_BASE_URL, AI_API_KEY, AI_PROVIDER_NAME, AI_MODEL.

Production sequence:
1. provision PostgreSQL 16+
2. run `npm run build && npm run migrate`
3. set REQUIRE_DATABASE=true
4. set AI provider credentials through a secret manager
5. build Docker image
6. deploy behind HTTPS reverse proxy/load balancer
7. configure backups, monitoring and alerting
8. run `/health` and authenticated E2E smoke tests

The repository intentionally does not contain production credentials and does not claim a public deployment until a real hosting/database account is connected.
