# JASON AI — Private Android APK

JASON uses one shared web/PWA frontend. Capacitor wraps the same `dist/ui` build as a native Android application.

## Build

1. Install dependencies: `npm install`
2. Sync Android project: `npm run cap:sync`
3. Open Android Studio: `npm run android:open`
4. Build a debug APK from Android Studio, or run `npm run android:build` for a release build when signing is configured.

The Android app ID is `ai.jason.private`. It does not require a Google Play listing. The APK can be distributed directly for private installation.

## Backend

The APK calls the same JASON HTTPS backend as the web/PWA. Do not embed AI provider keys in the APK. Configure provider credentials only on the backend.

## Important

An APK is the client. JASON Cloud/backend must be reachable over HTTPS for the phone to work when the PC is off. A local-PC model can be added through the AI Gateway as an optional route, but it is not required for the app itself.
