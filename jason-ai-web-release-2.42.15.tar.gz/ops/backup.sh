#!/bin/sh
set -eu
: "${DATABASE_URL:?DATABASE_URL is required}"
: "${BACKUP_DIR:=./backups}"
mkdir -p "$BACKUP_DIR"
ts="$(date -u +%Y%m%dT%H%M%SZ)"
pg_dump --format=custom --no-owner --no-acl "$DATABASE_URL" > "$BACKUP_DIR/jason-ai-$ts.dump"
find "$BACKUP_DIR" -type f -name 'jason-ai-*.dump' -mtime +7 -delete
printf '%s\n' "$BACKUP_DIR/jason-ai-$ts.dump"
