# JASON AI — Shared Web/PWA + Private Android Client Integration

## Completed
- One shared `src/ui` client for browser/PWA and Capacitor Android.
- Android app id: `ai.jason.private`.
- Added account endpoints: signup, verification, login, session lookup, logout.
- Added private-account UI shared by Web/PWA and Android.
- Session cookie is HttpOnly/Secure/SameSite=Strict in HTTPS production.
- Client never receives AI provider credentials.
- Capability dashboard remains shared across both clients.
- ₹0 spending policy remains server-side.

## Production note
The current auth store is an in-process adapter used by the client integration build. Before public production launch, connect authentication to the existing PostgreSQL `users_auth` and `auth_sessions` tables so accounts and sessions survive restarts and multiple backend instances.

## Android
Run `npm install`, `npm run cap:sync`, then build/open the generated Android project with Android Studio. Direct APK distribution does not require a Play Store listing.
