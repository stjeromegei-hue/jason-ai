# JASON AI — Phase 1 (₹0) Local Development

Phase 1 is the zero-cost development and validation stage. It requires no VPS, domain, paid AI API, GPU, or paid storage.

## Policy

- Paid providers: OFF
- Spending limit: ₹0
- Automatic paid fallback: OFF
- Production deterministic AI: OFF
- Local deterministic AI is permitted only for development/smoke testing and must never be represented as a real production model.

## Run

```bash
npm ci
npm run build
npm run phase1:smoke
```

The smoke test starts the PWA/API locally, checks `/health`, the JASON AI UI, the PWA manifest, and the capabilities endpoint, then shuts the server down.

## Validation gates

```bash
npm run release:certify
npm run load:test
npm run phase1:smoke
```

`release:certify` does not mean public deployment. It certifies the source package and local release gates only.

## Phase 1 exit criteria

- TypeScript build passes.
- All automated tests pass.
- E2E passes.
- Performance tests pass.
- Security gate passes.
- Recovery gate passes.
- Local UI/API smoke passes.
- ₹0 policy remains enforced.

## Not included in Phase 1

- Public Internet deployment
- Production PostgreSQL instance
- Production TLS certificate
- Paid AI inference
- Signed Android APK
