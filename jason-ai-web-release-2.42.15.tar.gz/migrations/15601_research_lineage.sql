CREATE TABLE IF NOT EXISTS research_source_versions (
  tenant_id TEXT NOT NULL, source_id TEXT NOT NULL, version_id TEXT PRIMARY KEY,
  canonical_url TEXT NOT NULL, content_hash TEXT NOT NULL, captured_at TIMESTAMPTZ NOT NULL,
  previous_version_id TEXT REFERENCES research_source_versions(version_id), changed BOOLEAN NOT NULL DEFAULT FALSE,
  stale BOOLEAN NOT NULL DEFAULT FALSE
);
CREATE INDEX IF NOT EXISTS idx_rsv_tenant_source ON research_source_versions(tenant_id,source_id,captured_at DESC);
CREATE INDEX IF NOT EXISTS idx_rsv_hash ON research_source_versions(tenant_id,content_hash);

CREATE TABLE IF NOT EXISTS research_evidence_lineage (
  tenant_id TEXT NOT NULL, evidence_id TEXT PRIMARY KEY, source_id TEXT NOT NULL, source_version_id TEXT NOT NULL,
  content_hash TEXT NOT NULL, captured_at TIMESTAMPTZ NOT NULL, expires_at TIMESTAMPTZ,
  stale BOOLEAN NOT NULL DEFAULT FALSE, supersedes_evidence_id TEXT
);
CREATE INDEX IF NOT EXISTS idx_rel_tenant_source ON research_evidence_lineage(tenant_id,source_id);
CREATE INDEX IF NOT EXISTS idx_rel_stale ON research_evidence_lineage(tenant_id,stale,expires_at);

CREATE TABLE IF NOT EXISTS research_claim_lineage (
  tenant_id TEXT NOT NULL, claim_id TEXT PRIMARY KEY, normalized_claim_id TEXT NOT NULL, research_run_id TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL, evidence_ids JSONB NOT NULL DEFAULT '[]', source_ids JSONB NOT NULL DEFAULT '[]',
  supersedes_claim_id TEXT, invalidated BOOLEAN NOT NULL DEFAULT FALSE, invalidated_at TIMESTAMPTZ, invalidation_reason TEXT
);
CREATE INDEX IF NOT EXISTS idx_rcl_reuse ON research_claim_lineage(tenant_id,normalized_claim_id,invalidated);
CREATE INDEX IF NOT EXISTS idx_rcl_run ON research_claim_lineage(tenant_id,research_run_id,created_at);

CREATE TABLE IF NOT EXISTS research_citation_lineage (
  tenant_id TEXT NOT NULL, citation_id TEXT PRIMARY KEY, claim_id TEXT NOT NULL, evidence_id TEXT NOT NULL,
  research_run_id TEXT NOT NULL, created_at TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_rcl_citation_claim ON research_citation_lineage(tenant_id,claim_id);

CREATE TABLE IF NOT EXISTS research_lineage_events (
  tenant_id TEXT NOT NULL, event_id TEXT PRIMARY KEY, event_type TEXT NOT NULL, entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL, research_run_id TEXT, event_at TIMESTAMPTZ NOT NULL, metadata JSONB NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_rle_entity ON research_lineage_events(tenant_id,entity_type,entity_id,event_at DESC);
CREATE INDEX IF NOT EXISTS idx_rle_run ON research_lineage_events(tenant_id,research_run_id,event_at DESC);
