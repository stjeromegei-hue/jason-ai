CREATE TABLE IF NOT EXISTS projects (
 id UUID PRIMARY KEY, tenant_id TEXT NOT NULL, owner_user_id TEXT NOT NULL,
 name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'ACTIVE',
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS project_items (
 id UUID PRIMARY KEY, project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
 tenant_id TEXT NOT NULL, kind TEXT NOT NULL, ref_id TEXT NOT NULL, title TEXT NOT NULL DEFAULT '',
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), UNIQUE(project_id,kind,ref_id)
);
CREATE INDEX IF NOT EXISTS idx_projects_tenant_updated ON projects(tenant_id,updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_project_items_tenant_project ON project_items(tenant_id,project_id,created_at DESC);
