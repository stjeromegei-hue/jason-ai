CREATE TABLE IF NOT EXISTS provider_scheduler_state (
  scope TEXT NOT NULL,
  name TEXT NOT NULL,
  limit_value INTEGER,
  remaining INTEGER,
  reset_at TIMESTAMPTZ,
  status TEXT NOT NULL CHECK (status IN ('available','exhausted','cooldown','unknown')),
  cooldown_until TIMESTAMPTZ,
  last_error TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (scope, name)
);
CREATE INDEX IF NOT EXISTS idx_provider_scheduler_state_status_reset
  ON provider_scheduler_state(status, reset_at);
