CREATE TABLE IF NOT EXISTS research_contradiction_clusters (
  tenant_id TEXT NOT NULL,
  cluster_id TEXT NOT NULL,
  research_run_id TEXT NOT NULL,
  claim_ids JSONB NOT NULL,
  pair_ids JSONB NOT NULL,
  score NUMERIC(8,4) NOT NULL,
  severity TEXT NOT NULL CHECK (severity IN ('LOW','MEDIUM','HIGH')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (tenant_id, cluster_id)
);
CREATE TABLE IF NOT EXISTS research_claim_resolutions (
  tenant_id TEXT NOT NULL,
  resolution_id TEXT NOT NULL,
  research_run_id TEXT NOT NULL,
  claim_id TEXT NOT NULL,
  competing_claim_ids JSONB NOT NULL,
  decision TEXT NOT NULL,
  score NUMERIC(8,4) NOT NULL,
  winning_factors JSONB NOT NULL,
  explanation JSONB NOT NULL,
  requires_review BOOLEAN NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (tenant_id, resolution_id)
);
CREATE TABLE IF NOT EXISTS research_graph_decisions (
  tenant_id TEXT NOT NULL,
  decision_id TEXT NOT NULL,
  research_run_id TEXT NOT NULL,
  decision TEXT NOT NULL CHECK (decision IN ('ANSWER','REVIEW')),
  score NUMERIC(8,4) NOT NULL,
  answerable_claim_ids JSONB NOT NULL,
  review_claim_ids JSONB NOT NULL,
  explanation JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (tenant_id, decision_id)
);
CREATE INDEX IF NOT EXISTS idx_contradiction_clusters_tenant_run ON research_contradiction_clusters(tenant_id,research_run_id);
CREATE INDEX IF NOT EXISTS idx_claim_resolutions_tenant_run ON research_claim_resolutions(tenant_id,research_run_id);
CREATE INDEX IF NOT EXISTS idx_graph_decisions_tenant_run ON research_graph_decisions(tenant_id,research_run_id);
