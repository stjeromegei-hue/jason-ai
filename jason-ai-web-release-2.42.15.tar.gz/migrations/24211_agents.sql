CREATE TABLE IF NOT EXISTS agent_runs (
 id UUID PRIMARY KEY, tenant_id TEXT NOT NULL, user_id TEXT NOT NULL, status TEXT NOT NULL,
 max_steps INTEGER NOT NULL, timeout_ms INTEGER NOT NULL, max_output_chars INTEGER NOT NULL,
 retry_budget INTEGER NOT NULL, cancelled BOOLEAN NOT NULL DEFAULT FALSE, error TEXT,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS agent_steps (
 id UUID PRIMARY KEY, run_id UUID NOT NULL REFERENCES agent_runs(id) ON DELETE CASCADE,
 tenant_id TEXT NOT NULL, step_index INTEGER NOT NULL, tool TEXT NOT NULL, permission TEXT NOT NULL,
 status TEXT NOT NULL, input_fingerprint TEXT NOT NULL, output_fingerprint TEXT, error TEXT,
 started_at TIMESTAMPTZ, finished_at TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS agent_approvals (
 id UUID PRIMARY KEY, run_id UUID NOT NULL REFERENCES agent_runs(id) ON DELETE CASCADE,
 step_id UUID NOT NULL REFERENCES agent_steps(id) ON DELETE CASCADE, tenant_id TEXT NOT NULL,
 decision TEXT NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_agent_runs_tenant_updated ON agent_runs(tenant_id,updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_agent_steps_tenant_run ON agent_steps(tenant_id,run_id,step_index);
