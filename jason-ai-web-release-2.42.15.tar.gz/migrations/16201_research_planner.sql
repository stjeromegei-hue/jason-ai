CREATE TABLE IF NOT EXISTS research_plans (
 tenant_id TEXT NOT NULL,
 research_run_id TEXT NOT NULL,
 iteration INTEGER NOT NULL CHECK (iteration >= 0),
 decision TEXT NOT NULL CHECK (decision IN ('CONTINUE','ANSWER','REVIEW')),
 expected_information_gain NUMERIC(8,4) NOT NULL,
 actions JSONB NOT NULL,
 explanation JSONB NOT NULL,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 PRIMARY KEY (tenant_id,research_run_id,iteration)
);
CREATE INDEX IF NOT EXISTS idx_research_plans_tenant_run ON research_plans(tenant_id,research_run_id,created_at DESC);
CREATE TABLE IF NOT EXISTS research_plan_actions (
 tenant_id TEXT NOT NULL,
 research_run_id TEXT NOT NULL,
 iteration INTEGER NOT NULL,
 action_key TEXT NOT NULL,
 action TEXT NOT NULL,
 claim_id TEXT,
 priority NUMERIC(8,4) NOT NULL,
 reason TEXT NOT NULL,
 query TEXT,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 PRIMARY KEY (tenant_id,research_run_id,iteration,action_key)
);
CREATE INDEX IF NOT EXISTS idx_research_plan_actions_claim ON research_plan_actions(tenant_id,claim_id,created_at DESC);
