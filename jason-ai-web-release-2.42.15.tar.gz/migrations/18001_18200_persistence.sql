-- Phase 18001-18200: production persistence compatibility and operational metadata.
-- Core tenant/document/report tables are created by 16401_18000_platform.sql.
CREATE INDEX IF NOT EXISTS idx_documents_tenant_created ON documents(tenant_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_document_chunks_document_ordinal ON document_chunks(document_id,ordinal);
CREATE INDEX IF NOT EXISTS idx_sessions_tenant_expiry ON sessions(tenant_id,expires_at);
CREATE INDEX IF NOT EXISTS idx_audit_actor_time ON audit_events(actor_id,created_at DESC);
