CREATE TABLE IF NOT EXISTS auth_verification_tokens(token TEXT PRIMARY KEY,user_id UUID NOT NULL REFERENCES users_auth(id) ON DELETE CASCADE,expires_at TIMESTAMPTZ NOT NULL);
CREATE INDEX IF NOT EXISTS auth_verification_user_idx ON auth_verification_tokens(user_id);
CREATE TABLE IF NOT EXISTS auth_reset_tokens(token TEXT PRIMARY KEY,user_id UUID NOT NULL REFERENCES users_auth(id) ON DELETE CASCADE,expires_at TIMESTAMPTZ NOT NULL);
CREATE INDEX IF NOT EXISTS auth_reset_user_idx ON auth_reset_tokens(user_id);
CREATE INDEX IF NOT EXISTS users_auth_tenant_idx ON users_auth(tenant_id);
CREATE INDEX IF NOT EXISTS auth_sessions_user_idx ON auth_sessions(user_id);
