CREATE TABLE IF NOT EXISTS research_graph_nodes (
  tenant_id TEXT NOT NULL,
  node_id TEXT NOT NULL,
  node_type TEXT NOT NULL CHECK (node_type IN ('ENTITY','CLAIM','EVIDENCE','SOURCE','SOURCE_VERSION','CITATION','RESEARCH_RUN')),
  label TEXT NOT NULL,
  normalized_label TEXT NOT NULL,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id,node_id)
);
CREATE INDEX IF NOT EXISTS idx_research_graph_nodes_label ON research_graph_nodes (tenant_id,normalized_label);
CREATE INDEX IF NOT EXISTS idx_research_graph_nodes_type ON research_graph_nodes (tenant_id,node_type);
CREATE TABLE IF NOT EXISTS research_graph_edges (
  tenant_id TEXT NOT NULL,
  edge_id TEXT NOT NULL,
  from_node_id TEXT NOT NULL,
  to_node_id TEXT NOT NULL,
  edge_type TEXT NOT NULL CHECK (edge_type IN ('MENTIONS','SUPPORTS','CONTRADICTS','DERIVED_FROM','CITES','VERSION_OF','SUPERSEDES','SAME_AS','RELATED_TO','PART_OF')),
  weight DOUBLE PRECISION NOT NULL,
  confidence DOUBLE PRECISION NOT NULL,
  research_run_id TEXT,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id,edge_id),
  FOREIGN KEY (tenant_id,from_node_id) REFERENCES research_graph_nodes(tenant_id,node_id),
  FOREIGN KEY (tenant_id,to_node_id) REFERENCES research_graph_nodes(tenant_id,node_id)
);
CREATE INDEX IF NOT EXISTS idx_research_graph_edges_from ON research_graph_edges (tenant_id,from_node_id);
CREATE INDEX IF NOT EXISTS idx_research_graph_edges_to ON research_graph_edges (tenant_id,to_node_id);
CREATE INDEX IF NOT EXISTS idx_research_graph_edges_type ON research_graph_edges (tenant_id,edge_type);
