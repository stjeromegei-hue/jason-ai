
CREATE TABLE IF NOT EXISTS capability_usage(
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  capability TEXT NOT NULL,
  used INTEGER NOT NULL DEFAULT 0 CHECK (used >= 0),
  limit_count INTEGER NOT NULL CHECK (limit_count >= 0),
  reset_at TIMESTAMPTZ NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(tenant_id, capability)
);
CREATE INDEX IF NOT EXISTS capability_usage_reset_idx ON capability_usage(reset_at);
