CREATE TABLE IF NOT EXISTS research_quality_assessments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  research_run_id UUID NOT NULL,
  score NUMERIC(6,4) NOT NULL,
  confidence_band TEXT NOT NULL CHECK (confidence_band IN ('HIGH','MEDIUM','LOW')),
  decision TEXT NOT NULL CHECK (decision IN ('ANSWER','REVIEW')),
  review_reasons JSONB NOT NULL DEFAULT '[]'::jsonb,
  explanation JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_research_quality_tenant_run ON research_quality_assessments(tenant_id,research_run_id);
