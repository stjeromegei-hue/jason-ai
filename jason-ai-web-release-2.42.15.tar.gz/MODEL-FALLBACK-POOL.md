# JASON AI Capability-Aware Model Fallback Pool

JASON now accepts an optional fallback chain per capability. Requests carry the routed capability into the AI gateway, so Chat, Coding, Research, Vision/media-related tasks, and other capabilities can have independent provider pools.

## Environment pattern

For a capability such as `coding`:

- `AI_CODING_BASE_URL`
- `AI_CODING_API_KEY`
- `AI_CODING_MODEL`
- `AI_CODING_NAME`
- `AI_CODING_PAID=false`
- `AI_CODING_FALLBACK_1_*` through `_4_*`

The same pattern is supported for the other routed capabilities.

## Selection order

1. Capability primary
2. Capability fallback 1..4
3. Development deterministic fallback when enabled
4. Otherwise fail closed

If a provider is marked paid and the global policy is `JASON_PAID_PROVIDERS=false` or the spending limit is `0`, that provider is excluded before execution.

If a capability has no dedicated pool, the generic `AI_*` primary/fallback pool is used.

Provider health exposes the configured capability pools without exposing API keys.

## Provider quota intelligence

JASON can schedule among eligible providers using explicit quota metadata instead of blindly following fixed order.

Optional per-provider variables:

- `<PREFIX>_QUOTA_LIMIT`
- `<PREFIX>_QUOTA_REMAINING`
- `<PREFIX>_QUOTA_RESET_AT` (ISO-8601 timestamp)
- `<PREFIX>_QUOTA_RESET_SECONDS`
- `<PREFIX>_COOLDOWN_SECONDS`

Rules:

- Explicitly exhausted providers are skipped until their reset time.
- Providers with more known remaining quota are preferred over providers with less remaining quota.
- Unknown quota is never guessed; unknown providers remain eligible after known-healthy capacity.
- A successful call decrements known remaining quota.
- HTTP 429 responses may update state from standard `Retry-After`, `X-RateLimit-Remaining`, and `X-RateLimit-Reset` headers.
- Other provider failures enter a short bounded cooldown to avoid hammering an unavailable provider.
- Capability pools maintain independent scheduling state.
- Paid slots are removed before scheduling when ₹0 mode blocks paid providers.
- The health endpoint exposes safe quota state only; API keys are never returned.

This is quota intelligence, not a promise that a provider exposes quota data. JASON only uses metadata or response headers it can actually observe.
