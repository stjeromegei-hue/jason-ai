import {randomUUID} from 'node:crypto';

export type UsageCapability='research'|'analysis'|'images'|'video'|'agents';
export type UsageStatus='AVAILABLE'|'QUOTA'|'EXHAUSTED'|'PAID_OFF'|'UNAVAILABLE';
export interface UsageState { capability:UsageCapability; used:number|null; limit:number|null; remaining:number|null; resetAt:string|null; status:UsageStatus; }

const LIMIT_ENV:Record<UsageCapability,string>={research:'JASON_RESEARCH_LIMIT',analysis:'JASON_ANALYSIS_LIMIT',images:'JASON_IMAGE_LIMIT',video:'JASON_VIDEO_LIMIT',agents:'JASON_AGENT_LIMIT'};
const int=(v:string|undefined)=>{const n=Number(v);return Number.isInteger(n)&&n>=0?n:0;};
function nextReset(now=new Date()):Date{
  const hour=Math.min(23,Math.max(0,int(process.env.JASON_USAGE_RESET_HOUR)||7));
  const minute=Math.min(59,Math.max(0,int(process.env.JASON_USAGE_RESET_MINUTE)||57));
  const tz=process.env.JASON_USAGE_TIMEZONE||'Asia/Kolkata';
  const parts=new Intl.DateTimeFormat('en-US',{timeZone:tz,hour12:false,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit'}).formatToParts(now);
  const p=Object.fromEntries(parts.map(x=>[x.type,x.value]));
  const candidate=new Date(Date.UTC(Number(p.year),Number(p.month)-1,Number(p.day),hour,minute,0));
  // Offset for the target timezone at the candidate instant.
  const asLocal=new Intl.DateTimeFormat('en-US',{timeZone:tz,timeZoneName:'longOffset',hour:'2-digit',minute:'2-digit'}).formatToParts(candidate).find(x=>x.type==='timeZoneName')?.value||'GMT+00:00';
  const m=asLocal.match(/GMT([+-])(\d{2}):?(\d{2})/); const offset=m?(Number(m[2])*60+Number(m[3]))*(m[1]==='-'?-1:1):0;
  const corrected=new Date(candidate.getTime()-offset*60000);
  if(corrected.getTime()<=now.getTime()) return new Date(corrected.getTime()+24*60*60*1000);
  return corrected;
}

export interface UsageStore { consume(tenantId:string,capability:UsageCapability,units?:number):Promise<UsageState>; state(tenantId:string,capability:UsageCapability):Promise<UsageState>; }

export class MemoryUsageStore implements UsageStore {
  private rows=new Map<string,{used:number;resetAt:string}>();
  private key(t:string,c:UsageCapability){return `${t}:${c}`;}
  private limit(c:UsageCapability){return int(process.env[LIMIT_ENV[c]]);}
  private current(t:string,c:UsageCapability){const k=this.key(t,c),limit=this.limit(c);let row=this.rows.get(k);if(row&&Date.now()>=Date.parse(row.resetAt)){row={used:0,resetAt:nextReset().toISOString()};this.rows.set(k,row);}if(!row&&limit>0){row={used:0,resetAt:nextReset().toISOString()};this.rows.set(k,row);}return row;}
  async state(tenantId:string,c:UsageCapability):Promise<UsageState>{const limit=this.limit(c),row=this.current(tenantId,c);if(limit<=0)return{capability:c,used:null,limit:null,remaining:null,resetAt:null,status:'UNAVAILABLE'};const used=row?.used||0;return{capability:c,used,limit,remaining:Math.max(0,limit-used),resetAt:row?.resetAt||nextReset().toISOString(),status:used>=limit?'EXHAUSTED':used/limit>=.8?'QUOTA':'AVAILABLE'};}
  async consume(tenantId:string,c:UsageCapability,units=1):Promise<UsageState>{if(!Number.isInteger(units)||units<1||units>100)throw new Error('INVALID_USAGE_UNITS');const s=await this.state(tenantId,c);if(s.status==='UNAVAILABLE')throw new Error('CAPABILITY_UNAVAILABLE');if((s.remaining??0)<units)throw new UsageLimitError(s);const row=this.current(tenantId,c)!;row.used+=units;return this.state(tenantId,c);}
}

export class UsageLimitError extends Error { constructor(public state:UsageState){super('USAGE_LIMIT_REACHED');this.name='UsageLimitError';} }

export class PostgresUsageStore implements UsageStore {
  private constructor(private pool:any){}
  static async connect(connectionString:string){const mod:any=await import('pg');const pool=new mod.Pool({connectionString,max:5,idleTimeoutMillis:30000,connectionTimeoutMillis:5000});await pool.query('SELECT 1');return new PostgresUsageStore(pool);}
  private limit(c:UsageCapability){return int(process.env[LIMIT_ENV[c]]);}
  private async ensure(t:string,c:UsageCapability){const limit=this.limit(c);if(limit<=0)return null;const q=await this.pool.query('SELECT tenant_id,capability,used,limit_count,reset_at FROM capability_usage WHERE tenant_id=$1 AND capability=$2',[t,c]);if(q.rowCount)return q.rows[0];const reset=nextReset();const x=await this.pool.query('INSERT INTO capability_usage(id,tenant_id,capability,used,limit_count,reset_at) VALUES($1,$2,$3,0,$4,$5) ON CONFLICT(tenant_id,capability) DO UPDATE SET limit_count=EXCLUDED.limit_count RETURNING tenant_id,capability,used,limit_count,reset_at',[randomUUID(),t,c,limit,reset]);return x.rows[0];}
  async state(t:string,c:UsageCapability):Promise<UsageState>{const limit=this.limit(c);if(limit<=0)return{capability:c,used:null,limit:null,remaining:null,resetAt:null,status:'UNAVAILABLE'};let row=await this.ensure(t,c);if(Date.now()>=Date.parse(row.reset_at)){row=(await this.pool.query('UPDATE capability_usage SET used=0,limit_count=$3,reset_at=$4,updated_at=now() WHERE tenant_id=$1 AND capability=$2 RETURNING tenant_id,capability,used,limit_count,reset_at',[t,c,limit,nextReset()])).rows[0];}const used=Number(row.used);return{capability:c,used,limit:Number(row.limit_count),remaining:Math.max(0,Number(row.limit_count)-used),resetAt:new Date(row.reset_at).toISOString(),status:used>=Number(row.limit_count)?'EXHAUSTED':used/Number(row.limit_count)>=.8?'QUOTA':'AVAILABLE'};}
  async consume(t:string,c:UsageCapability,units=1):Promise<UsageState>{if(!Number.isInteger(units)||units<1||units>100)throw new Error('INVALID_USAGE_UNITS');const s=await this.state(t,c);if(s.status==='UNAVAILABLE')throw new Error('CAPABILITY_UNAVAILABLE');const q=await this.pool.query('UPDATE capability_usage SET used=used+$3,updated_at=now() WHERE tenant_id=$1 AND capability=$2 AND reset_at>now() AND used+$3<=limit_count RETURNING used,limit_count,reset_at',[t,c,units]);if(!q.rowCount){const fresh=await this.state(t,c);throw new UsageLimitError(fresh);}return this.state(t,c);}
}

export async function createUsageStore():Promise<UsageStore>{if(!process.env.DATABASE_URL)return new MemoryUsageStore();try{return await PostgresUsageStore.connect(process.env.DATABASE_URL);}catch(e){if(process.env.REQUIRE_DATABASE==='true')throw e;return new MemoryUsageStore();}}
