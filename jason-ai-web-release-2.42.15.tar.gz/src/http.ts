import {startServer} from './api.js';
await startServer(Number(process.env.PORT||3000));
