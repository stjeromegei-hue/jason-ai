import {AIProvider,ProviderRequest,ProviderResponse,DeterministicProvider} from './platform.js';
import {HttpAIProvider,ProviderHttpError,StreamEvent} from './ai-provider.js';

export type ProviderHealth='healthy'|'degraded'|'unavailable';
type Slot={name:string;baseUrl:string;apiKey:string;model:string;paid?:boolean;quota?:ProviderQuotaConfig};
export interface ProviderQuotaConfig { limit?:number; remaining?:number; resetAt?:string; resetSeconds?:number; cooldownSeconds?:number }
export interface ProviderQuotaState { name:string; limit:number|null; remaining:number|null; resetAt:string|null; status:'available'|'exhausted'|'cooldown'|'unknown'; cooldownUntil:string|null; lastError:string|null }
export interface GatewayConfig {
  primary?: Slot;
  fallbacks?: Slot[];
  capabilityPools?: Record<string,{primary?:Slot;fallbacks:Slot[]}>;
  fallbackEnabled:boolean; timeoutMs:number; maxRetries:number
  providerQuotas?: Record<string,ProviderQuotaConfig|undefined>;
  defaultCooldownSeconds?:number;
}
export interface GatewayResult { provider:string; attempts:number; fallback:boolean; response:ProviderResponse }

function sleep(ms:number){return new Promise(r=>setTimeout(r,ms));}
function bounded(n:number,min:number,max:number){return Math.max(min,Math.min(max,Number.isFinite(n)?n:min));}
function validateText(s:string,max:number){if(typeof s!=='string'||!s.trim()||s.length>max)throw new Error('INVALID_AI_INPUT');}
function safeDate(v?:string|null){if(!v)return null;const d=new Date(v);return Number.isFinite(d.getTime())?d.toISOString():null;}

class ProviderStateStore {
  private pool?:any;
  private enabled=false;
  private initPromise:Promise<void>;
  constructor(){ this.initPromise=this.init(); }
  private async init(){
    const url=process.env.DATABASE_URL;
    if(!url)return;
    try{const mod:any=await import('pg');const P=mod.Pool||mod.default?.Pool;if(!P)return;this.pool=new P({connectionString:url,max:2,idleTimeoutMillis:10000});this.enabled=true;}catch{}
  }
  async load():Promise<Array<{scope:string;name:string;limit:number|null;remaining:number|null;resetAt:string|null;status:ProviderQuotaState['status'];cooldownUntil:string|null;lastError:string|null}>>{
    await this.initPromise;if(!this.enabled||!this.pool)return [];
    try{const q=await this.pool.query(`SELECT scope,name,limit_value AS "limit",remaining,reset_at AS "resetAt",status,cooldown_until AS "cooldownUntil",last_error AS "lastError" FROM provider_scheduler_state`);return q.rows;}catch{return []}
  }
  async save(scope:string,s:ProviderQuotaState){
    await this.initPromise;if(!this.enabled||!this.pool)return;
    try{await this.pool.query(`INSERT INTO provider_scheduler_state(scope,name,limit_value,remaining,reset_at,status,cooldown_until,last_error,updated_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,NOW()) ON CONFLICT(scope,name) DO UPDATE SET limit_value=EXCLUDED.limit_value,remaining=EXCLUDED.remaining,reset_at=EXCLUDED.reset_at,status=EXCLUDED.status,cooldown_until=EXCLUDED.cooldown_until,last_error=EXCLUDED.last_error,updated_at=NOW()`,[scope,s.name,s.limit,s.remaining,s.resetAt,s.status,s.cooldownUntil,s.lastError]);}catch{}
  }
}

class ProviderScheduler {
  private states=new Map<string,ProviderQuotaState>();
  private ready:Promise<void>;
  private store=new ProviderStateStore();
  constructor(private cfg:GatewayConfig){
    for(const [name,q] of Object.entries(cfg.providerQuotas||{})) this.states.set(this.key('*',name),this.initial(name,q||{}));
    this.ready=this.hydrate();
  }
  private key(scope:string,name:string){return `${scope}::${name}`;}
  private initial(name:string,q:ProviderQuotaConfig):ProviderQuotaState{
    const limit=Number.isFinite(q.limit as number)?Math.max(0,Number(q.limit)):null;
    let remaining=Number.isFinite(q.remaining as number)?Math.max(0,Number(q.remaining)):null;
    if(remaining!==null&&limit!==null)remaining=Math.min(remaining,limit);
    let resetAt=safeDate(q.resetAt);
    if(!resetAt&&Number.isFinite(q.resetSeconds as number))resetAt=new Date(Date.now()+Math.max(0,Number(q.resetSeconds))*1000).toISOString();
    return {name,limit,remaining,resetAt,status:remaining===0&&resetAt&&new Date(resetAt).getTime()>Date.now()?'exhausted':remaining===null?'unknown':'available',cooldownUntil:null,lastError:null};
  }
  private refresh(s:ProviderQuotaState){
    const now=Date.now();
    if(s.cooldownUntil&&new Date(s.cooldownUntil).getTime()<=now){s.cooldownUntil=null;if(s.remaining===0&&s.resetAt&&new Date(s.resetAt).getTime()<=now)s.remaining=s.limit===null?null:s.limit;}
    if(s.resetAt&&new Date(s.resetAt).getTime()<=now&&s.remaining===0){s.remaining=s.limit===null?null:s.limit;s.resetAt=null;s.status=s.remaining===null?'unknown':'available';}
    if(s.cooldownUntil&&new Date(s.cooldownUntil).getTime()>now)s.status='cooldown';
    else if(s.remaining===0&&s.resetAt&&new Date(s.resetAt).getTime()>now)s.status='exhausted';
    else s.status=s.remaining===null?'unknown':'available';
  }
  private async hydrate(){
    const rows=await this.store.load();
    for(const row of rows){
      const key=this.key(row.scope,row.name);const base=this.states.get(key)||this.states.get(this.key('*',row.name))||this.initial(row.name,{});
      this.states.set(key,{...base,limit:row.limit,remaining:row.remaining,resetAt:row.resetAt,status:row.status,cooldownUntil:row.cooldownUntil,lastError:row.lastError});
      this.refresh(this.states.get(key)!);
    }
  }
  private ensure(name:string,q?:ProviderQuotaConfig,scope='*'){
    const k=this.key(scope,name);
    if(!this.states.has(k)){const global=this.states.get(this.key('*',name));this.states.set(k,global?{...global}:this.initial(name,q||{}));}
    const s=this.states.get(k);if(s)this.refresh(s);return s;
  }
  async eligible(names:string[],scope='*'):Promise<string[]>{
    await this.ready;
    const rows=names.map((name,i)=>({name,i,state:this.ensure(name,undefined,scope)})).filter(x=>{if(!x.state)return true;this.refresh(x.state);return x.state.status!=='exhausted'&&x.state.status!=='cooldown';});
    rows.sort((a,b)=>{
      const ar=a.state?.remaining,br=b.state?.remaining;
      if(ar!==null&&br===null)return -1;if(ar===null&&br!==null)return 1;if(ar!==null&&ar!==undefined&&br!==null&&br!==undefined&&ar!==br)return br-ar;
      return a.i-b.i;
    });
    return rows.map(x=>x.name);
  }
  async onSuccess(name:string,scope='*'){await this.ready;const s=this.ensure(name,undefined,scope);if(!s)return;if(s.remaining!==null)s.remaining=Math.max(0,s.remaining-1);s.lastError=null;this.refresh(s);await this.store.save(scope,s);}
  async onError(name:string,e:unknown,scope='*'){await this.ready;const s=this.ensure(name,undefined,scope);if(!s)return;s.lastError=e instanceof Error?e.message:String(e);const pe=e instanceof ProviderHttpError?e:null;
    if(pe?.status===429){
      const retry=Number(pe.headers['retry-after']);
      const reset=Number(pe.headers['x-ratelimit-reset']);
      if(Number.isFinite(retry)&&retry>=0)s.resetAt=new Date(Date.now()+Math.min(retry,86400)*1000).toISOString();
      else if(Number.isFinite(reset)){const ms=(reset>1e12?reset:reset*1000)-Date.now();if(ms>0&&ms<86400000)s.resetAt=new Date(Date.now()+ms).toISOString();}
      const rem=Number(pe.headers['x-ratelimit-remaining']);if(Number.isFinite(rem)&&rem>=0)s.remaining=Math.floor(rem);
      if(s.remaining===0&&!s.resetAt)s.resetAt=new Date(Date.now()+60000).toISOString();
      this.refresh(s);await this.store.save(scope,s);return;
    }
    const cooldown=Math.max(1,Math.min(300,Number(this.cfg.defaultCooldownSeconds||5)));
    s.cooldownUntil=new Date(Date.now()+cooldown*1000).toISOString();s.status='cooldown';await this.store.save(scope,s);
  }
  snapshot(names?:string[],scope='*'):ProviderQuotaState[]{const keys=names||Array.from(this.states.keys()).map(k=>k.slice(k.indexOf('::')+2));return keys.map(n=>{const s=this.ensure(n,undefined,scope);return s?{...s}:({name:n,limit:null,remaining:null,resetAt:null,status:'unknown',cooldownUntil:null,lastError:null});});}
}

export class AIGateway {
  private scheduler:ProviderScheduler;
  private labels=new WeakMap<AIProvider,string>();
  constructor(private cfg:GatewayConfig, private primary?:AIProvider, private fallback:AIProvider=new DeterministicProvider(), private fallbackProviders:AIProvider[]=[], private capabilityProviders:Record<string,{primary?:AIProvider;fallbacks:AIProvider[]}>= {}){
    this.scheduler=new ProviderScheduler(cfg);
    if(primary&&cfg.primary)this.labels.set(primary,cfg.primary.name);
    this.fallbackProviders.forEach((p,i)=>{const slot=cfg.fallbacks?.[i];if(slot)this.labels.set(p,slot.name);});
    for(const [cap,pool] of Object.entries(this.capabilityProviders)){
      const cp=cfg.capabilityPools?.[cap]; if(pool.primary&&cp?.primary)this.labels.set(pool.primary,cp.primary.name);
      pool.fallbacks.forEach((p,i)=>{const slot=cp?.fallbacks[i];if(slot)this.labels.set(p,slot.name);});
    }
  }
  private providerName(p:AIProvider){return this.labels.get(p)||p.constructor.name;}
  private async callWithRetry(p:AIProvider,req:ProviderRequest){
    let last:unknown;
    for(let attempt=1;attempt<=this.cfg.maxRetries+1;attempt++){
      try{const response=await p.generate({...req,timeoutMs:bounded(req.timeoutMs,1000,this.cfg.timeoutMs)});await this.scheduler.onSuccess(this.providerName(p),String(req.capability||'*').trim().toLowerCase()||'*');return {response,attempt};}
      catch(e){last=e;await this.scheduler.onError(this.providerName(p),e,String(req.capability||'*').trim().toLowerCase()||'*');if(attempt<=this.cfg.maxRetries)await sleep(Math.min(250*2**(attempt-1),1000));}
    }
    throw last instanceof Error?last:new Error('AI_PROVIDER_FAILED');
  }
  private providerPool(req:ProviderRequest):AIProvider[]{
    const cap=String(req.capability||'').trim().toLowerCase();const cp=cap?this.capabilityProviders[cap]:undefined;
    if(cp){const out:AIProvider[]=[];if(cp.primary)out.push(cp.primary);if(this.cfg.fallbackEnabled)out.push(...cp.fallbacks,this.fallback);return out;}
    const out:AIProvider[]=[];if(this.primary)out.push(this.primary);if(this.cfg.fallbackEnabled)out.push(...this.fallbackProviders,this.fallback);return out;
  }
  private async providersFor(req:ProviderRequest):Promise<AIProvider[]>{
    const pool=this.providerPool(req);const names=pool.map(p=>this.providerName(p));const scope=String(req.capability||'*').trim().toLowerCase()||'*';const ordered=await this.scheduler.eligible(names,scope);const byName=new Map(pool.map(p=>[this.providerName(p),p]));
    return ordered.map(n=>byName.get(n)).filter(Boolean) as AIProvider[];
  }
  async generate(req:ProviderRequest):Promise<GatewayResult>{
    validateText(req.prompt,50000);const providers=await this.providersFor(req);let last:unknown;
    for(let i=0;i<providers.length;i++){try{const x=await this.callWithRetry(providers[i],req);return{provider:x.response.provider,attempts:x.attempt,fallback:i>0,response:x.response};}catch(e){last=e;if(!this.cfg.fallbackEnabled)break;}}
    if(!providers.length&&this.cfg.fallbackEnabled&&this.fallback){const x=await this.callWithRetry(this.fallback,req);return{provider:x.response.provider,attempts:x.attempt,fallback:true,response:x.response};}
    throw last instanceof Error?last:new Error('AI_PROVIDER_FAILED');
  }
  async *stream(req:ProviderRequest):AsyncGenerator<StreamEvent>{
    validateText(req.prompt,50000);const providers=await this.providersFor(req);let last:unknown;
    for(let i=0;i<providers.length;i++){
      const p=providers[i] as AIProvider & {stream?: (r:ProviderRequest)=>AsyncGenerator<StreamEvent>};
      try{
        if(p.stream){for await(const e of p.stream(req)){if(e.type==='error')throw new Error(e.error||'AI_PROVIDER_STREAM_FAILED');yield e;}await this.scheduler.onSuccess(this.providerName(p),String(req.capability||'*').trim().toLowerCase()||'*');return;}
        const x=await this.callWithRetry(p,req);yield {type:'delta',text:x.response.text};yield {type:'done',usage:x.response.usage};return;
      }catch(e){last=e;if(!this.cfg.fallbackEnabled)break;if(i<providers.length-1)yield {type:'error',error:'PROVIDER_FAILED'};}
    }
    throw last instanceof Error?last:new Error('AI_PROVIDER_FAILED');
  }
  health(){
    const providers=[...(this.cfg.primary?[{name:this.cfg.primary.name,role:'primary' as const,paid:Boolean(this.cfg.primary.paid)}]:[]),...((this.cfg.fallbacks||[]).map(x=>({name:x.name,role:'fallback' as const,paid:Boolean(x.paid)})))];
    const capabilities=Object.fromEntries(Object.entries(this.cfg.capabilityPools||{}).map(([cap,p])=>[cap,{primary:p.primary?.name||null,fallbacks:p.fallbacks.map(x=>x.name),paidAllowed:[p.primary,...p.fallbacks].some(Boolean)&&[p.primary,...p.fallbacks].some(x=>Boolean(x?.paid))?paidAllowed() : true,quota:this.scheduler.snapshot([p.primary?.name,...p.fallbacks.map(x=>x.name)].filter(Boolean) as string[],cap)}]));
    return{primary:this.primary?'healthy':'unavailable',fallback:this.cfg.fallbackEnabled?'healthy':'unavailable',providers,capabilities,quota:this.scheduler.snapshot(providers.map(x=>x.name)),policy:this.cfg.fallbackEnabled?'fallback-enabled':'fail-closed'};
  }
}

function truthy(v:unknown){return String(v||'false').toLowerCase()==='true';}
function paidAllowed(){return truthy(process.env.JASON_PAID_PROVIDERS) && Number(process.env.JASON_SPENDING_LIMIT_INR||0)>0;}
function numberEnv(key:string){const n=Number(process.env[key]);return Number.isFinite(n)?n:undefined;}
function quota(prefix:string):ProviderQuotaConfig|undefined{
 const q:ProviderQuotaConfig={limit:numberEnv(`${prefix}_QUOTA_LIMIT`),remaining:numberEnv(`${prefix}_QUOTA_REMAINING`),resetAt:process.env[`${prefix}_QUOTA_RESET_AT`]||undefined,resetSeconds:numberEnv(`${prefix}_QUOTA_RESET_SECONDS`),cooldownSeconds:numberEnv(`${prefix}_COOLDOWN_SECONDS`)};
 return Object.values(q).some(v=>v!==undefined)?q:undefined;
}
function slot(prefix:string){
 const base=process.env[`${prefix}_BASE_URL`];const model=process.env[`${prefix}_MODEL`];if(!base||!model)return null;
 const apiKey=process.env[`${prefix}_API_KEY`]||'';const paid=truthy(process.env[`${prefix}_PAID`]);if(paid&&!paidAllowed())return null;
 return{name:process.env[`${prefix}_NAME`]||prefix.toLowerCase(),baseUrl:base,apiKey,model,paid,quota:quota(prefix)};
}
const CAPABILITIES=['chat','reasoning','research','files','knowledge','memory','coding','writing','analysis','presentation','images','video','voice','websites','agents','verify','projects'];
function capabilityPool(cap:string){const key=cap.toUpperCase().replace(/[^A-Z0-9]+/g,'_');const primary=slot(`AI_${key}`);const fallbacks=[1,2,3,4].map(i=>slot(`AI_${key}_FALLBACK_${i}`)).filter(Boolean) as Slot[];return primary||fallbacks.length?{primary:primary||undefined,fallbacks}:null;}
export function createGatewayFromEnv():AIGateway{
 const primarySlot=slot('AI');const fallbacks=[1,2,3,4].map(i=>slot(`AI_FALLBACK_${i}`)).filter(Boolean) as Slot[];const pools:Record<string,{primary?:Slot;fallbacks:Slot[]}>= {};
 for(const cap of CAPABILITIES){const pool=capabilityPool(cap);if(pool)pools[cap]=pool;}
 const allSlots=[primarySlot,...fallbacks,...Object.values(pools).flatMap(p=>[p.primary,...p.fallbacks])].filter(Boolean) as Slot[];const make=(x:Slot)=>new HttpAIProvider(x);
 const primary=primarySlot?make(primarySlot):undefined;const fallbackProviders=fallbacks.map(make);const capabilityProviders:Record<string,{primary?:AIProvider;fallbacks:AIProvider[]}>=Object.fromEntries(Object.entries(pools).map(([cap,p])=>[cap,{primary:p.primary?make(p.primary):undefined,fallbacks:p.fallbacks.map(make)}]));
 const production=process.env.NODE_ENV==='production';const deterministic=truthy(process.env.ALLOW_DETERMINISTIC_AI||(!production?'true':'false'));const fallbackEnabled=fallbacks.length>0||deterministic||Object.values(pools).some(p=>p.fallbacks.length>0);
 if(production&&!allSlots.length&&!deterministic)throw new Error('AI_PROVIDER_REQUIRED');
 const providerQuotas:Record<string,ProviderQuotaConfig>={};for(const s of allSlots){if(s.quota)providerQuotas[s.name]=s.quota;}
 const cfg={primary:primarySlot?{...primarySlot,apiKey:'[REDACTED]'}:undefined,fallbacks:fallbacks.map(x=>({...x,apiKey:'[REDACTED]'})),capabilityPools:Object.fromEntries(Object.entries(pools).map(([cap,p])=>[cap,{primary:p.primary?{...p.primary,apiKey:'[REDACTED]'}:undefined,fallbacks:p.fallbacks.map(x=>({...x,apiKey:'[REDACTED]'}))}])),fallbackEnabled,timeoutMs:Number(process.env.AI_TIMEOUT_MS||15000),maxRetries:Math.min(3,Math.max(0,Number(process.env.AI_MAX_RETRIES||1))),providerQuotas,defaultCooldownSeconds:Number(process.env.AI_PROVIDER_COOLDOWN_SECONDS||5)};
 return new AIGateway(cfg,primary,undefined,fallbackProviders,capabilityProviders);
}
