declare module 'node:http'; declare module 'node:fs/promises'; declare const Buffer:any;

declare const process: any;
declare const console: any;
declare module 'pg' { const value:any; export = value; }
declare module 'node:crypto' { export function randomUUID():string; export function randomBytes(n:number):any; export function scryptSync(password:string,salt:string,keylen:number):any; export function timingSafeEqual(a:any,b:any):boolean; export function createHash(name:string):{update(x:string):any;digest(enc:string):string}; }
declare module 'node:path' { export function join(...parts:string[]):string; }
declare module 'node:dns/promises' { export function lookup(host:string,options:{all:true}):Promise<Array<{address:string}>>; }
declare module 'node:net' { export function isIP(address:string):0|4|6; }

declare module 'node:zlib' { export function inflateRawSync(data:any):any; }
