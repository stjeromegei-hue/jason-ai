export type Role='OWNER'|'ADMIN'|'MEMBER'|'VIEWER';
export interface User {id:string; tenantId:string; email:string; role:Role; active:boolean}
export interface Session {id:string; userId:string; tenantId:string; expiresAt:number}
const roles:Record<Role,number>={OWNER:4,ADMIN:3,MEMBER:2,VIEWER:1};
export function authorize(user:User, minimum:Role):boolean{return user.active&&roles[user.role]>=roles[minimum];}
export function safeTenant(user:User,tenantId:string):void{if(user.tenantId!==tenantId)throw new Error('TENANT_FORBIDDEN');}
export function validateEmail(email:string):boolean{return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)&&email.length<=254;}
export function validateUpload(name:string,size:number,mime:string):{ok:boolean;reason?:string}{const allowed=new Set(['application/pdf','text/plain','application/json','text/markdown','text/csv','application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','application/vnd.openxmlformats-officedocument.presentationml.presentation']);if(!name||name.length>255||/[\\/]/.test(name)||name==='.'||name==='..'||name.includes('..'))return{ok:false,reason:'INVALID_NAME'};if(size<0||size>25*1024*1024)return{ok:false,reason:'SIZE_LIMIT'};if(!allowed.has(mime))return{ok:false,reason:'UNSUPPORTED_TYPE'};return{ok:true};}
export function securityHeaders():Record<string,string>{return {'X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Referrer-Policy':'strict-origin-when-cross-origin','Content-Security-Policy':"default-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'self'",'Permissions-Policy':'camera=(), microphone=(), geolocation=()','Cache-Control':'no-store'};}
