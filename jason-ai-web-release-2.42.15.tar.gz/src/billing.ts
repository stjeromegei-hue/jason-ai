export type Plan='FREE'|'PRO'|'BUSINESS';
export interface PlanLimits {documents:number;monthlyTokens:number;storageBytes:number;researchRuns:number}
export const PLAN_LIMITS:Record<Plan,PlanLimits>={FREE:{documents:50,monthlyTokens:100000,storageBytes:1073741824,researchRuns:100},PRO:{documents:500,monthlyTokens:2000000,storageBytes:10737418240,researchRuns:2000},BUSINESS:{documents:5000,monthlyTokens:20000000,storageBytes:107374182400,researchRuns:20000}};
export interface Usage {documents:number;tokens:number;storageBytes:number;researchRuns:number}
export function withinPlan(plan:Plan,usage:Usage,delta:Partial<Usage>){const l=PLAN_LIMITS[plan];return usage.documents+(delta.documents||0)<=l.documents&&usage.tokens+(delta.tokens||0)<=l.monthlyTokens&&usage.storageBytes+(delta.storageBytes||0)<=l.storageBytes&&usage.researchRuns+(delta.researchRuns||0)<=l.researchRuns}
