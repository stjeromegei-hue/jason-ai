import { createHash } from 'node:crypto';

export type DeploymentEnvironment = 'staging' | 'production';
export type PromotionStatus = 'READY' | 'BLOCKED';

export interface DeploymentCheck {
  name: string;
  passed: boolean;
  required: boolean;
  details: string;
}

export interface ReleaseManifest {
  release: string;
  packageVersion: string;
  environment: DeploymentEnvironment;
  artifactSha256: string;
  migrations: number;
  checks: DeploymentCheck[];
  status: PromotionStatus;
  generatedAt: string;
}

const SHA256 = /^[a-f0-9]{64}$/;

export function validateArtifactSha256(value: string): boolean {
  return SHA256.test(value);
}

export function evaluatePromotion(checks: DeploymentCheck[]): PromotionStatus {
  return checks.some(c => c.required && !c.passed) ? 'BLOCKED' : 'READY';
}

export function buildReleaseManifest(input: Omit<ReleaseManifest, 'status' | 'generatedAt'> & { generatedAt?: string }): ReleaseManifest {
  if (!validateArtifactSha256(input.artifactSha256)) throw new Error('INVALID_ARTIFACT_SHA256');
  if (!Number.isInteger(input.migrations) || input.migrations < 1) throw new Error('INVALID_MIGRATION_COUNT');
  const checks = [...input.checks];
  return {
    ...input,
    checks,
    status: evaluatePromotion(checks),
    generatedAt: input.generatedAt ?? new Date().toISOString(),
  };
}

export function deploymentDigest(manifest: ReleaseManifest): string {
  const canonical = JSON.stringify({
    release: manifest.release,
    packageVersion: manifest.packageVersion,
    environment: manifest.environment,
    artifactSha256: manifest.artifactSha256,
    migrations: manifest.migrations,
    checks: manifest.checks,
    status: manifest.status,
  });
  return createHash('sha256').update(canonical).digest('hex');
}

export function canPromoteToProduction(manifest: ReleaseManifest): boolean {
  return manifest.environment === 'staging' && manifest.status === 'READY';
}
