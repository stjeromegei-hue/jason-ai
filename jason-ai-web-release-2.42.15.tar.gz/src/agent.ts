import {createHash,randomUUID} from 'node:crypto';
import type {Repository} from './persistence.js';
import {searchKnowledge} from './knowledge.js';
import {fetchEvidence} from './private-intelligence.js';
import type {UsageCapability} from './usage.js';

export type AgentToolName='knowledge.search'|'memory.list'|'research.fetch'|'report.create';
export type PermissionClass='READ_ONLY'|'EXTERNAL_READ'|'CONSEQUENTIAL';
export type AgentStepStatus='PENDING'|'WAITING_APPROVAL'|'RUNNING'|'SUCCEEDED'|'FAILED'|'CANCELLED';
export interface AgentStep {id:string;runId:string;index:number;tool:AgentToolName;permission:PermissionClass;status:AgentStepStatus;inputFingerprint:string;outputFingerprint?:string;startedAt?:string;finishedAt?:string;error?:string;}
export interface AgentRun {id:string;tenantId:string;userId:string;status:'RUNNING'|'WAITING_APPROVAL'|'SUCCEEDED'|'FAILED'|'CANCELLED';createdAt:string;updatedAt:string;maxSteps:number;timeoutMs:number;maxOutputChars:number;retryBudget:number;steps:AgentStep[];result?:unknown;error?:string;cancelled:boolean;}
export interface AgentRequest {steps:Array<{tool:AgentToolName;input?:any}>;maxSteps?:number;timeoutMs?:number;maxOutputChars?:number;retryBudget?:number;}
export interface AgentUsage {consume:(tenantId:string,capability:UsageCapability,count?:number)=>Promise<any>}

const registry:Record<AgentToolName,{permission:PermissionClass;capability?:UsageCapability}>={
 'knowledge.search':{permission:'READ_ONLY'},
 'memory.list':{permission:'READ_ONLY'},
 'research.fetch':{permission:'EXTERNAL_READ',capability:'research'},
 'report.create':{permission:'CONSEQUENTIAL'}
};
const runs=new Map<string,AgentRun>();
const hash=(v:unknown)=>createHash('sha256').update(JSON.stringify(v)).digest('hex');
const cap=(n:number,min:number,max:number)=>Math.max(min,Math.min(max,Number.isFinite(n)?Math.floor(n):min));
export function agentTools(){return Object.entries(registry).map(([name,v])=>({name,permission:v.permission,capability:v.capability||null,approvalRequired:v.permission==='CONSEQUENTIAL'}));}
export function getAgentRun(id:string,tenantId:string){const r=runs.get(id);return r&&r.tenantId===tenantId?r:undefined;}
export function listAgentRuns(tenantId:string){return [...runs.values()].filter(r=>r.tenantId===tenantId).sort((a,b)=>b.createdAt.localeCompare(a.createdAt));}
export function createAgentRun(tenantId:string,userId:string,req:AgentRequest){
 if(!tenantId||!userId||!Array.isArray(req.steps)||req.steps.length===0)throw new Error('INVALID_AGENT_PLAN');
 const maxSteps=cap(req.maxSteps??10,1,20); if(req.steps.length>maxSteps)throw new Error('AGENT_MAX_STEPS');
 const steps=req.steps.map((s,i)=>{if(!(s.tool in registry))throw new Error('UNKNOWN_AGENT_TOOL');const permission=registry[s.tool].permission;return {id:randomUUID(),runId:'',index:i,tool:s.tool,permission,status:permission==='CONSEQUENTIAL'?'WAITING_APPROVAL':'PENDING',inputFingerprint:hash(s.input??{})} as AgentStep;});
 const id=randomUUID(); steps.forEach(s=>s.runId=id); const now=new Date().toISOString();
 const r:AgentRun={id,tenantId,userId,status:steps.some(s=>s.status==='WAITING_APPROVAL')?'WAITING_APPROVAL':'RUNNING',createdAt:now,updatedAt:now,maxSteps,timeoutMs:cap(req.timeoutMs??30000,1000,120000),maxOutputChars:cap(req.maxOutputChars??12000,500,50000),retryBudget:cap(req.retryBudget??1,0,3),steps,cancelled:false};runs.set(id,r);return r;
}
export function cancelAgentRun(id:string,tenantId:string){const r=getAgentRun(id,tenantId);if(!r)throw new Error('AGENT_NOT_FOUND');r.cancelled=true;r.status='CANCELLED';r.updatedAt=new Date().toISOString();for(const s of r.steps)if(['PENDING','RUNNING','WAITING_APPROVAL'].includes(s.status))s.status='CANCELLED';return r;}
export function approveAgentStep(id:string,tenantId:string,stepId:string){const r=getAgentRun(id,tenantId);if(!r)throw new Error('AGENT_NOT_FOUND');const s=r.steps.find(x=>x.id===stepId);if(!s)throw new Error('AGENT_STEP_NOT_FOUND');if(s.status!=='WAITING_APPROVAL')throw new Error('AGENT_STEP_NOT_WAITING');s.status='PENDING';r.status='RUNNING';r.updatedAt=new Date().toISOString();return r;}
async function executeTool(step:AgentStep,tenantId:string,repo:Repository,input:any){
 switch(step.tool){
  case 'knowledge.search': {const items=await repo.listKnowledge(tenantId);return searchKnowledge(items,tenantId,String(input?.query||''),cap(input?.limit??8,1,20));}
  case 'memory.list': return repo.listMemories(tenantId,cap(input?.limit??20,1,100));
  case 'research.fetch': {const urls=Array.isArray(input?.urls)?input.urls.slice(0,5):[];if(!urls.length)throw new Error('NO_SOURCES');const out=[];for(const u of urls){try{out.push(await fetchEvidence(String(u),cap(input?.timeoutMs??8000,1000,10000),cap(input?.maxBytes??1000000,1000,2000000)));}catch(e){out.push({url:String(u),error:e instanceof Error?e.message:'SOURCE_FAILED'});}}return out;}
  case 'report.create': {const title=String(input?.title||'').trim();const content=String(input?.content||'').trim();if(!title||!content)throw new Error('INVALID_REPORT');return repo.saveReport({tenantId,kind:'REPORT',title,content});}
 }
}
export async function executeAgentRun(id:string,tenantId:string,repo:Repository,usage:AgentUsage){
 const r=getAgentRun(id,tenantId);if(!r)throw new Error('AGENT_NOT_FOUND'); if(r.cancelled)return r; const deadline=Date.now()+r.timeoutMs;
 for(const s of r.steps){if(r.cancelled){s.status='CANCELLED';break;}if(Date.now()>deadline){r.status='FAILED';r.error='AGENT_TIMEOUT';break;}if(s.status==='WAITING_APPROVAL')continue;if(s.status!=='PENDING')continue;
  s.status='RUNNING';s.startedAt=new Date().toISOString();let attempts=0;
  while(true){try{const reg=registry[s.tool];if(reg.capability)await usage.consume(tenantId,reg.capability,1);const input=(r as any)._inputs?.[s.index]??{}; // populated by HTTP layer
    const output=await executeTool(s,tenantId,repo,input);const safe=JSON.stringify(output);if(safe.length>r.maxOutputChars)throw new Error('AGENT_OUTPUT_LIMIT');s.outputFingerprint=hash(output);s.status='SUCCEEDED';s.finishedAt=new Date().toISOString();(s as any).outputSummary={size:safe.length};break;
   }catch(e){const msg=e instanceof Error?e.message:'TOOL_FAILED';const retryable=!/QUOTA|LIMIT|FORBIDDEN|UNAUTHORIZED|UNAUTHENTICATED|UNSAFE|INVALID|NOT_FOUND|OUTPUT_LIMIT/.test(msg);attempts++;if(retryable&&attempts<=r.retryBudget)continue;s.status='FAILED';s.error=e instanceof Error?e.message:'TOOL_FAILED';s.finishedAt=new Date().toISOString();r.status='FAILED';r.error=s.error;break;}}
  if(r.status==='FAILED')break;
 }
 if(r.status==='RUNNING'&&!r.steps.some(s=>s.status==='WAITING_APPROVAL'))r.status='SUCCEEDED';r.updatedAt=new Date().toISOString();return r;
}
export function setAgentInputs(run:AgentRun,steps:Array<{input?:any}>){(run as any)._inputs=steps.map(s=>s.input??{});return run;}
export function publicAgentRun(r:AgentRun){const {tenantId,_inputs,result,...safe}=r as any; return safe;}
