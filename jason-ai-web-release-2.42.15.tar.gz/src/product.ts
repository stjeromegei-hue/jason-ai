import {createHash,randomUUID} from 'node:crypto';
export type Surface='ASK'|'VERIFY'|'FILES'|'CREATE'|'BUILD';
export type ArtifactKind='REPORT'|'PRESENTATION'|'INFOGRAPHIC';
export interface Workspace {id:string;tenantId:string;name:string;createdAt:string;onboardingComplete:boolean}
export interface Citation {id:string;sourceId:string;locator?:string;label:string}
export interface Answer {id:string;workspaceId:string;text:string;citations:Citation[];confidence:'HIGH'|'MEDIUM'|'LOW';decision:'ANSWER'|'REVIEW'}
export interface Artifact {id:string;workspaceId:string;kind:ArtifactKind;title:string;content:string;createdAt:string}
export function createWorkspace(tenantId:string,name:string):Workspace { if(!tenantId||!name.trim()) throw new Error('INVALID_WORKSPACE'); return {id:randomUUID(),tenantId,name:name.trim().slice(0,120),createdAt:new Date().toISOString(),onboardingComplete:false}; }
export function completeOnboarding(w:Workspace):Workspace{return {...w,onboardingComplete:true};}
export function buildAnswer(workspaceId:string,text:string,citations:Citation[],confidence:Answer['confidence'],decision:Answer['decision']):Answer { if(!workspaceId||!text.trim()) throw new Error('INVALID_ANSWER'); const clean=[...new Map(citations.map(c=>[c.id,c])).values()]; return {id:randomUUID(),workspaceId,text:text.trim(),citations:clean,confidence,decision}; }
export function buildArtifact(workspaceId:string,kind:ArtifactKind,title:string,content:string):Artifact { if(!workspaceId||!title.trim()||!content.trim()) throw new Error('INVALID_ARTIFACT'); return {id:randomUUID(),workspaceId,kind,title:title.trim().slice(0,200),content,createdAt:new Date().toISOString()}; }
export function stableContentHash(content:string){return createHash('sha256').update(content).digest('hex');}
