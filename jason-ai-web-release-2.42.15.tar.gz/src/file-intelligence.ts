import {createHash} from 'node:crypto';
import {inflateRawSync} from 'node:zlib';
import {validateUpload} from './security.js';
export interface ExtractedDocument {sha256:string;text:string;pages:number;metadata:Record<string,string>}
export interface RetrievalChunk {id:string;ordinal:number;text:string;score:number}

const XML_ENTITIES:Record<string,string>={'amp':'&','lt':'<','gt':'>','quot':'"','apos':"'"};
function xmlDecode(s:string){return s.replace(/&#(\d+);/g,(_,n)=>String.fromCharCode(Number(n))).replace(/&#x([0-9a-f]+);/gi,(_,n)=>String.fromCharCode(parseInt(n,16))).replace(/&([a-z]+);/gi,(_,n)=>XML_ENTITIES[n]??`&${n};`)}
function xmlText(s:string){return xmlDecode(s.replace(/<w:tab\s*\/?>(?:\s*)/gi,'\t').replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim())}

function zipEntries(buf:any):Map<string,any>{
  const out=new Map<string,any>(); let p=0;
  while(p+30<=buf.length){
    const sig=buf.readUInt32LE(p); if(sig===0x06054b50)break;
    if(sig!==0x04034b50){p++;continue;}
    const method=buf.readUInt16LE(p+8), csize=buf.readUInt32LE(p+18), nlen=buf.readUInt16LE(p+26), xlen=buf.readUInt16LE(p+28);
    if(csize>25*1024*1024||p+30+nlen+xlen+csize>buf.length)throw new Error('INVALID_ARCHIVE');
    const name=buf.subarray(p+30,p+30+nlen).toString('utf8'); const data=buf.subarray(p+30+nlen+xlen,p+30+nlen+xlen+csize);
    if(!name.includes('..')&&!name.startsWith('/')){
      if(method===0)out.set(name,new Uint8Array(data)); else if(method===8)out.set(name,new Uint8Array(inflateRawSync(data))); else throw new Error('UNSUPPORTED_COMPRESSION');
    }
    p+=30+nlen+xlen+csize;
  }
  return out;
}
function extractOoxml(buf:any,mime:string){
  const z=zipEntries(buf); const texts:string[]=[];
  if(mime.includes('wordprocessingml')){
    for(const [name,data] of z) if(/^word\/(document|header|footer|footnotes|endnotes).*\.xml$/.test(name)) texts.push(xmlText(Buffer.from(data).toString('utf8')));
  } else if(mime.includes('spreadsheetml')){
    const shared=z.get('xl/sharedStrings.xml'); const sharedStrings:string[]=[]; if(shared){for(const m of Buffer.from(shared).toString().matchAll(/<t[^>]*>([\s\S]*?)<\/t>/gi)) sharedStrings.push(xmlDecode(m[1]));}
    for(const [name,data] of z) if(/^xl\/worksheets\/sheet\d+\.xml$/.test(name)){
      const x=Buffer.from(data).toString('utf8').replace(/<row[^>]*>/gi,'\n'); const vals=[];
      for(const m of x.matchAll(/<c([^>]*)>([\s\S]*?)<\/c>/gi)){const attrs=m[1], body=m[2], typ=/t="([^"]+)"/i.exec(attrs)?.[1], v=/<v[^>]*>([\s\S]*?)<\/v>/i.exec(body)?.[1]??'', inline=/<is[^>]*>([\s\S]*?)<\/is>/i.exec(body)?.[1]; if(inline) vals.push(xmlText(inline)); else if(typ==='s') vals.push(sharedStrings[Number(v)]??''); else vals.push(xmlDecode(v));}
      texts.push(vals.join(' '));
    }
  } else if(mime.includes('presentationml')){
    for(const [name,data] of z) if(/^ppt\/(slides|notesSlides)\/.*\.xml$/.test(name)) texts.push(xmlText(Buffer.from(data).toString('utf8')));
  }
  const text=texts.join('\n').replace(/\s+\n/g,'\n').replace(/\n{3,}/g,'\n\n').trim();
  if(!text)throw new Error('EMPTY_DOCUMENT'); return text;
}
function extractPdf(buf:any){
  const raw=buf.toString('latin1'); if(!raw.startsWith('%PDF-'))throw new Error('INVALID_PDF');
  const chunks:string[]=[];
  for(const m of raw.matchAll(/\(([^()]*)\)\s*(?:Tj|\')/g)) chunks.push(m[1]);
  for(const m of raw.matchAll(/\[([^\]]+)\]\s*TJ/g)){for(const s of m[1].matchAll(/\(([^()]*)\)/g))chunks.push(s[1]);}
  const text=chunks.join(' ').replace(/\\([\\()])/g,'$1').replace(/\\n/g,'\n').replace(/\\r/g,'\r').replace(/\s+/g,' ').trim();
  if(!text)throw new Error('PDF_TEXT_UNAVAILABLE'); return text;
}
export function extractBinaryText(name:string,mime:string,buf:any):ExtractedDocument{
  buf=Buffer.from(buf);
  const v=validateUpload(name,buf.length,mime); if(!v.ok)throw new Error(v.reason); const sha256=createHash('sha256').update(buf).digest('hex');
  let text:string;
  if(mime==='application/pdf') text=extractPdf(buf);
  else if(mime.startsWith('text/')||mime==='application/json'||mime==='text/markdown') text=buf.toString('utf8').replace(/\u0000/g,'').trim();
  else if(mime.includes('openxmlformats')){if(buf.readUInt32LE(0)!==0x04034b50&&buf.readUInt32LE(0)!==0x05034b50)throw new Error('INVALID_OFFICE_FILE'); text=extractOoxml(buf,mime);}
  else throw new Error('UNSUPPORTED_TYPE');
  if(!text)throw new Error('EMPTY_DOCUMENT');
  return {sha256,text,pages:Math.max(1,(text.match(/\f/g)?.length||0)+1),metadata:{name,mime,size:String(buf.length),extraction:'native-text'}};
}
export function extractText(name:string,mime:string,size:number,content:string):ExtractedDocument{const v=validateUpload(name,size,mime);if(!v.ok)throw new Error(v.reason);const text=content.replace(/\u0000/g,'').replace(/[ \t]+/g,' ').trim();if(!text)throw new Error('EMPTY_DOCUMENT');return{sha256:createHash('sha256').update(content).digest('hex'),text,pages:Math.max(1,text.split(/\f|\n\n/).length),metadata:{name,mime,size:String(size),extraction:'text'}}}
export function chunkText(text:string,maxChars=1800,overlap=180):string[]{if(maxChars<100||overlap>=maxChars)throw new Error('INVALID_CHUNK_POLICY');const out:string[]=[];let start=0;while(start<text.length){let end=Math.min(text.length,start+maxChars);if(end<text.length){const p=text.lastIndexOf(' ',end);if(p>start+500)end=p}out.push(text.slice(start,end).trim());if(end>=text.length)break;start=Math.max(start+1,end-overlap)}return out.filter(Boolean)}
function terms(s:string){return new Set(s.toLowerCase().split(/[^a-z0-9]+/).filter(x=>x.length>2))}
export function retrieve(chunks:string[],query:string,limit=8):RetrievalChunk[]{const q=terms(query);return chunks.map((text,ordinal)=>{const t=terms(text);let hits=0;for(const x of q)if(t.has(x))hits++;const score=q.size?hits/q.size:0;return{id:createHash('sha256').update(`${ordinal}:${text}`).digest('hex').slice(0,24),ordinal,text,score}}).filter(x=>x.score>0).sort((a,b)=>b.score-a.score||a.ordinal-b.ordinal).slice(0,limit)}
export function sanitizeRetrievedText(text:string){return text.replace(/ignore (all|any|previous)(?: instructions| previous instructions)?/gi,'[redacted instruction-like text]').replace(/system message/gi,'[redacted system-like text]')}
