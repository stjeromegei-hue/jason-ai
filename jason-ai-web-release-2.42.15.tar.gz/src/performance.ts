export type PerformanceSample={latencyMs:number;ok:boolean;error?:string};
export type LoadResult={requests:number;concurrency:number;completed:number;failed:number;durationMs:number;rps:number;p50Ms:number;p95Ms:number;p99Ms:number;maxMs:number;errorRate:number};

export class ConcurrencyLimiter {
  private active=0;
  private queue:Array<()=>void>=[];
  constructor(private readonly limit:number){if(!Number.isInteger(limit)||limit<1)throw new Error('INVALID_CONCURRENCY');}
  async run<T>(task:()=>Promise<T>):Promise<T>{
    if(this.active>=this.limit) await new Promise<void>(resolve=>this.queue.push(resolve));
    this.active++;
    try{return await task();}finally{this.active--;const next=this.queue.shift();if(next)next();}
  }
}

export function percentile(values:number[],p:number):number{
  if(!values.length)return 0;
  const sorted=[...values].sort((a,b)=>a-b); const rank=(sorted.length-1)*Math.min(1,Math.max(0,p));
  const lo=Math.floor(rank),hi=Math.ceil(rank); return sorted[lo]+(sorted[hi]-sorted[lo])*(rank-lo);
}

export async function runLoad(options:{requests:number;concurrency:number;task:()=>Promise<void>}):Promise<LoadResult>{
  if(!Number.isInteger(options.requests)||options.requests<1)throw new Error('INVALID_REQUEST_COUNT');
  const limiter=new ConcurrencyLimiter(options.concurrency); const samples:PerformanceSample[]=[]; const started=Date.now();
  await Promise.all(Array.from({length:options.requests},async()=>limiter.run(async()=>{
    const t=Date.now(); try{await options.task();samples.push({latencyMs:Date.now()-t,ok:true});}
    catch(e){samples.push({latencyMs:Date.now()-t,ok:false,error:e instanceof Error?e.message:'unknown_error'});}
  })));
  const durationMs=Math.max(1,Date.now()-started),latencies=samples.map(s=>s.latencyMs),failed=samples.filter(s=>!s.ok).length;
  return {requests:options.requests,concurrency:options.concurrency,completed:samples.length-failed,failed,durationMs,rps:samples.length/(durationMs/1000),p50Ms:percentile(latencies,.5),p95Ms:percentile(latencies,.95),p99Ms:percentile(latencies,.99),maxMs:Math.max(...latencies),errorRate:failed/samples.length};
}

export function performanceBudget(result:LoadResult,budget={p95Ms:1000,p99Ms:2000,maxErrorRate:.01}):{passed:boolean;reasons:string[]}{
  const reasons:string[]=[]; if(result.p95Ms>budget.p95Ms)reasons.push(`p95 latency ${result.p95Ms.toFixed(1)}ms exceeds ${budget.p95Ms}ms`); if(result.p99Ms>budget.p99Ms)reasons.push(`p99 latency ${result.p99Ms.toFixed(1)}ms exceeds ${budget.p99Ms}ms`); if(result.errorRate>budget.maxErrorRate)reasons.push(`error rate ${(result.errorRate*100).toFixed(2)}% exceeds ${(budget.maxErrorRate*100).toFixed(2)}%`); return {passed:reasons.length===0,reasons};
}
