import {randomUUID,createHash} from 'node:crypto';
export type ProjectStatus='ACTIVE'|'ARCHIVED';
export interface Project {id:string;tenantId:string;ownerUserId:string;name:string;description:string;status:ProjectStatus;createdAt:string;updatedAt:string;}
export interface ProjectItem {id:string;projectId:string;tenantId:string;kind:string;refId:string;title:string;createdAt:string;}
const projects=new Map<string,Project>();
const items=new Map<string,ProjectItem>();
const clean=(s:unknown,max:number)=>String(s??'').trim().slice(0,max);
export function createProject(tenantId:string,ownerUserId:string,input:any):Project{
 if(!tenantId||!ownerUserId) throw new Error('UNAUTHENTICATED');
 const name=clean(input?.name,120); if(!name) throw new Error('INVALID_PROJECT_NAME');
 const now=new Date().toISOString(); const p:Project={id:randomUUID(),tenantId,ownerUserId,name,description:clean(input?.description,1000),status:'ACTIVE',createdAt:now,updatedAt:now}; projects.set(p.id,p); return p;
}
export function listProjects(tenantId:string){return [...projects.values()].filter(p=>p.tenantId===tenantId).sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt));}
export function getProject(id:string,tenantId:string){const p=projects.get(id);return p?.tenantId===tenantId?p:undefined;}
export function updateProject(id:string,tenantId:string,input:any){const p=getProject(id,tenantId);if(!p)throw new Error('PROJECT_NOT_FOUND');if(input?.name!==undefined){p.name=clean(input.name,120);if(!p.name)throw new Error('INVALID_PROJECT_NAME');}if(input?.description!==undefined)p.description=clean(input.description,1000);if(input?.status!==undefined){const s=String(input.status);if(s!=='ACTIVE'&&s!=='ARCHIVED')throw new Error('INVALID_PROJECT_STATUS');p.status=s;}p.updatedAt=new Date().toISOString();return p;}
export function addProjectItem(projectId:string,tenantId:string,input:any){const p=getProject(projectId,tenantId);if(!p)throw new Error('PROJECT_NOT_FOUND');const kind=clean(input?.kind,40),refId=clean(input?.refId,200),title=clean(input?.title,200);if(!kind||!refId)throw new Error('INVALID_PROJECT_ITEM');const i:ProjectItem={id:randomUUID(),projectId,tenantId,kind,refId,title,createdAt:new Date().toISOString()};items.set(i.id,i);p.updatedAt=new Date().toISOString();return i;}
export function listProjectItems(projectId:string,tenantId:string){const p=getProject(projectId,tenantId);if(!p)throw new Error('PROJECT_NOT_FOUND');return [...items.values()].filter(i=>i.projectId===projectId&&i.tenantId===tenantId).sort((a,b)=>b.createdAt.localeCompare(a.createdAt));}
export function removeProjectItem(id:string,tenantId:string){const i=items.get(id);if(!i||i.tenantId!==tenantId)return false;items.delete(id);return true;}
export function projectFingerprint(p:Project){return createHash('sha256').update(JSON.stringify(p)).digest('hex');}
