export type RuntimeConfig={nodeEnv:string;port:number;databaseUrl?:string;requireDatabase:boolean;aiConfigured:boolean;release:string};
export function loadConfig():RuntimeConfig{
 const port=Number(process.env.PORT||3000);
 if(!Number.isInteger(port)||port<1||port>65535) throw new Error('INVALID_PORT');
 const requireDatabase=String(process.env.REQUIRE_DATABASE||'false').toLowerCase()==='true';
 const databaseUrl=process.env.DATABASE_URL||undefined;
 if(requireDatabase&&!databaseUrl) throw new Error('DATABASE_URL_REQUIRED');
 if(process.env.NODE_ENV==='production' && String(process.env.ALLOW_DETERMINISTIC_AI||'false').toLowerCase()!=='true' && !process.env.AI_BASE_URL) { /* provider may be injected later; startup remains safe */ }
 return {nodeEnv:process.env.NODE_ENV||'development',port,databaseUrl,requireDatabase,aiConfigured:Boolean(process.env.AI_BASE_URL&&process.env.AI_API_KEY),release:'24215'};
}
