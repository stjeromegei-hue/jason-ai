import {createHash} from 'node:crypto';
import {redactSecrets} from './privacy.js';
export interface ReleaseGate {name:string;passed:boolean;details:string}
export interface ReleaseCertificate {version:string;gates:ReleaseGate[];passed:boolean;sha256:string;generatedAt:string}
export function releaseDigest(files:string[]){return createHash('sha256').update(files.slice().sort().join('\n')).digest('hex');}
export function certifyRelease(version:string,gates:ReleaseGate[]):ReleaseCertificate{const passed=gates.length>0&&gates.every(g=>g.passed);const sha256=releaseDigest(gates.map(g=>`${g.name}:${g.passed}:${redactSecrets(g.details)}`));return {version,gates,passed,sha256,generatedAt:new Date().toISOString()};}
export function percentile(values:number[],p:number){if(!values.length)return 0;const a=[...values].sort((x,y)=>x-y);const i=Math.min(a.length-1,Math.max(0,Math.ceil(p*a.length)-1));return a[i];}
