import {readdir,readFile} from 'node:fs/promises';
import {join} from 'node:path';
export async function migrate(databaseUrl=process.env.DATABASE_URL,migrationsDir=process.env.MIGRATIONS_DIR||'migrations'){
  if(!databaseUrl)throw new Error('DATABASE_URL_REQUIRED'); const mod:any=await import('pg'); const pool=new mod.Pool({connectionString:databaseUrl,max:2});
  await pool.query('CREATE TABLE IF NOT EXISTS schema_migrations(version text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())');
  const files=(await readdir(migrationsDir)).filter((x:string)=>x.endsWith('.sql')).sort();
  for(const file of files){const version=file.replace(/\.sql$/,'');const exists=await pool.query('SELECT 1 FROM schema_migrations WHERE version=$1',[version]);if(exists.rowCount)continue;const sql=await readFile(join(migrationsDir,file),'utf8');const client=await pool.connect();try{await client.query('BEGIN');await client.query(sql);await client.query('INSERT INTO schema_migrations(version) VALUES($1)',[version]);await client.query('COMMIT');}catch(e){await client.query('ROLLBACK');throw new Error(`MIGRATION_FAILED:${file}:${e instanceof Error?e.message:String(e)}`)}finally{client.release();}}
  await pool.end(); return {applied:files.length};
}
if(process.argv[1]?.endsWith('migrate.js'))migrate().then(x=>console.log(JSON.stringify(x))).catch(e=>{console.error(e);process.exitCode=1});
