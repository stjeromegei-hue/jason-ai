export interface AuditEvent{eventId:string;tenantId:string;actorId:string;action:string;resource:string;at:string;metadata:Record<string,string>}
export interface Metric{name:string;value:number;tags:Record<string,string>}
export class Observability{readonly audits:AuditEvent[]=[];readonly metrics:Metric[]=[];audit(e:AuditEvent){this.audits.push(e)} metric(m:Metric){this.metrics.push(m)} snapshot(){return{auditCount:this.audits.length,metrics:this.metrics.length}}}
