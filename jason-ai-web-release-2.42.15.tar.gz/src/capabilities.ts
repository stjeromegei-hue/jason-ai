export type CapabilityStatus = 'AVAILABLE'|'QUOTA'|'EXHAUSTED'|'PAID_OFF'|'UNAVAILABLE';
export interface Capability { id:string; icon:string; name:string; status:CapabilityStatus; used:number|null; limit:number|null; resetAt:string|null; mode:'local'|'free'|'paid'|'mixed'|'unavailable'; }
const bool=(v:string|undefined)=>String(v||'').toLowerCase()==='true';
const quota=(id:string, icon:string, name:string, env:string, mode:'free'|'mixed'='free'):Capability=>{
  const limit=Number(process.env[env]||0); const used=Number(process.env[`${env}_USED`]||0);
  if(limit>0) return {id,icon,name,status:used>=limit?'EXHAUSTED':used/limit>=.8?'QUOTA':'AVAILABLE',used,limit,resetAt:process.env[`${env}_RESET`]||null,mode};
  return {id,icon,name,status:'UNAVAILABLE',used:null,limit:null,resetAt:null,mode:'unavailable'};
};
export function capabilities():Capability[]{
  return [
    {id:'chat',icon:'💬',name:'Chat',status:'AVAILABLE',used:null,limit:null,resetAt:null,mode:'mixed'},
    {id:'reasoning',icon:'🧠',name:'Reasoning',status:'AVAILABLE',used:null,limit:null,resetAt:null,mode:'mixed'},
    quota('research','🔎','Research','JASON_RESEARCH_LIMIT'),
    {id:'files',icon:'📄',name:'Files',status:'AVAILABLE',used:null,limit:null,resetAt:null,mode:'local'},
    {id:'knowledge',icon:'🧠',name:'Knowledge',status:'AVAILABLE',used:null,limit:null,resetAt:null,mode:'local'},
    {id:'memory',icon:'💾',name:'Memory',status:'AVAILABLE',used:null,limit:null,resetAt:null,mode:'local'},
    {id:'coding',icon:'💻',name:'Coding',status:'AVAILABLE',used:null,limit:null,resetAt:null,mode:'mixed'},
    {id:'writing',icon:'📝',name:'Writing',status:'AVAILABLE',used:null,limit:null,resetAt:null,mode:'mixed'},
    quota('analysis','📊','Analysis','JASON_ANALYSIS_LIMIT'),
    {id:'presentation',icon:'📑',name:'Presentation',status:'AVAILABLE',used:null,limit:null,resetAt:null,mode:'local'},
    quota('images','🖼️','Images','JASON_IMAGE_LIMIT'),
    quota('video','🎬','Video','JASON_VIDEO_LIMIT'),
    {id:'voice',icon:'🎙️',name:'Voice',status:'AVAILABLE',used:null,limit:null,resetAt:null,mode:'mixed'},
    {id:'websites',icon:'🌐',name:'Websites',status:'AVAILABLE',used:null,limit:null,resetAt:null,mode:'local'},
    quota('agents','🤖','Agents','JASON_AGENT_LIMIT'),
    {id:'verify',icon:'🔬',name:'Verify',status:'AVAILABLE',used:null,limit:null,resetAt:null,mode:'local'},
    {id:'projects',icon:'🗂️',name:'Projects',status:'AVAILABLE',used:null,limit:null,resetAt:null,mode:'local'},
  ];
}
export function spendingPolicy(){ const limit=Math.max(0,Number(process.env.JASON_SPENDING_LIMIT_INR||0)); const requested=bool(process.env.JASON_PAID_PROVIDERS); return {currency:'INR',limit,spent:0,paidProvidersEnabled:requested&&limit>0,autoBilling:false,hardCeiling:true}; }
