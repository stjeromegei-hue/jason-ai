export interface Consent {tenantId:string;userId:string;purpose:string;version:string;granted:boolean;at:string}
export interface RetentionPolicy {auditDays:number;feedbackDays:number;deletedDocumentGraceDays:number}
export const DEFAULT_RETENTION:RetentionPolicy={auditDays:365,feedbackDays:180,deletedDocumentGraceDays:30};
export function recordConsent(tenantId:string,userId:string,purpose:string,version:string,granted:boolean):Consent{return {tenantId,userId,purpose,version,granted,at:new Date().toISOString()};}
export function redactSecrets(input:string){return input.replace(/(sk-[A-Za-z0-9_-]{12,})/g,'[REDACTED_KEY]').replace(/(password|token|secret|api[_-]?key)\s*[:=]\s*[^\s,;]+/gi,'$1=[REDACTED]');}
export function validateRetention(p:RetentionPolicy){return p.auditDays>=30&&p.feedbackDays>=30&&p.deletedDocumentGraceDays>=7;}
