import {randomUUID} from 'node:crypto';

export type RequestContext={requestId:string;startedAt:number};
export function requestContext(headers:any):RequestContext{
  const incoming=String(headers?.['x-request-id']||'').trim();
  const requestId=/^[A-Za-z0-9._:-]{8,128}$/.test(incoming)?incoming:randomUUID();
  return {requestId,startedAt:Date.now()};
}
export function operationalHeaders(ctx:RequestContext){return {'X-Request-ID':ctx.requestId,'Cache-Control':'no-store'}}
export function logEvent(event:string,fields:Record<string,unknown>={}){
  console.log(JSON.stringify({ts:new Date().toISOString(),event,...fields}));
}
export function gracefulShutdown(server:any,closeResources:()=>Promise<void>=async()=>{}){
  let closing=false;
  const shutdown=async(signal:string)=>{if(closing)return;closing=true;logEvent('shutdown_start',{signal});await new Promise<void>(resolve=>server.close(()=>resolve()));await closeResources();logEvent('shutdown_complete');};
  process.on('SIGTERM',()=>void shutdown('SIGTERM'));
  process.on('SIGINT',()=>void shutdown('SIGINT'));
  return shutdown;
}
export function formatError(error:unknown,requestId:string){
  const message=error instanceof Error?error.message:'unknown_error';
  const publicCodes=new Set(['BODY_LIMIT','INVALID_PORT','DATABASE_URL_REQUIRED','FORBIDDEN','UPLOAD_NAME','UPLOAD_TYPE','UPLOAD_SIZE','INVALID_EMAIL','USAGE_LIMIT_REACHED','CAPABILITY_UNAVAILABLE','INVALID_USAGE_UNITS']);
  return {error:publicCodes.has(message)?message:'internal_error',requestId};
}

export class FixedWindowRateLimiter {
  private buckets=new Map<string,{started:number;count:number}>();
  constructor(private readonly limit:number=120,private readonly windowMs:number=60000){}
  allow(key:string,now=Date.now()){const current=this.buckets.get(key);if(!current||now-current.started>=this.windowMs){this.buckets.set(key,{started:now,count:1});return true;}if(current.count>=this.limit)return false;current.count++;return true;}
  prune(now=Date.now()){for(const [key,b] of this.buckets)if(now-b.started>=this.windowMs)this.buckets.delete(key);}
}
export function clientKey(headers:any):string{const forwarded=String(headers?.['x-forwarded-for']||'').split(',')[0].trim();return forwarded||String(headers?.['x-real-ip']||'unknown').trim()||'unknown';}
export function isJsonContentType(headers:any):boolean{const v=String(headers?.['content-type']||'').toLowerCase();return v.startsWith('application/json');}
