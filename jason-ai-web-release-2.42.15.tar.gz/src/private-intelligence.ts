import {createHash, randomUUID} from 'node:crypto';
import {lookup} from 'node:dns/promises';
import {isIP} from 'node:net';

export type MemoryKind='PREFERENCE'|'FACT'|'PROJECT'|'INSTRUCTION';
export interface MemoryItem {id:string;tenantId:string;kind:MemoryKind;content:string;source:string;createdAt:string;updatedAt:string;active:boolean;}
export interface Evidence {id:string;url:string;title:string;content:string;contentHash:string;fetchedAt:string;confidence:'HIGH'|'MEDIUM'|'LOW';}

const memories=new Map<string,MemoryItem[]>();
const privateIpv4=(ip:string)=>{const p=ip.split('.').map(Number);return p.length===4&&((p[0]===10)||(p[0]===127)||(p[0]===169&&p[1]===254)||(p[0]===172&&p[1]>=16&&p[1]<=31)||(p[0]===192&&p[1]===168));};
const privateIpv6=(ip:string)=>{const x=ip.toLowerCase();return x==='::1'||x.startsWith('fc')||x.startsWith('fd')||x.startsWith('fe80:');};
function safeIp(ip:string){return isIP(ip)===4?privateIpv4(ip):isIP(ip)===6?privateIpv6(ip):false;}
export async function validatePublicUrl(raw:string){
  let u:URL; try{u=new URL(raw);}catch{throw new Error('INVALID_URL');}
  if(!['http:','https:'].includes(u.protocol))throw new Error('UNSUPPORTED_URL_SCHEME');
  if(u.username||u.password)throw new Error('URL_CREDENTIALS_FORBIDDEN');
  if(u.port && !['80','443'].includes(u.port))throw new Error('UNSUPPORTED_URL_PORT');
  const host=u.hostname.toLowerCase().replace(/^\[|\]$/g,'');
  if(host==='localhost'||host.endsWith('.localhost')||host.endsWith('.local')||safeIp(host))throw new Error('PRIVATE_URL_FORBIDDEN');
  const records=await lookup(host,{all:true}).catch(()=>[] as Array<{address:string}>);
  if(!records.length)throw new Error('DNS_RESOLUTION_FAILED');
  if(records.some(r=>safeIp(r.address)))throw new Error('PRIVATE_URL_FORBIDDEN');
  u.hash=''; return u.toString();
}
function extractHtml(html:string){return html.replace(/<script[\s\S]*?<\/script>/gi,' ').replace(/<style[\s\S]*?<\/style>/gi,' ').replace(/<noscript[\s\S]*?<\/noscript>/gi,' ').replace(/<[^>]+>/g,' ').replace(/&nbsp;/gi,' ').replace(/&amp;/gi,'&').replace(/\s+/g,' ').trim();}
function titleOf(html:string){const m=html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);return m?extractHtml(m[1]).slice(0,300):'Untitled source';}
export async function fetchEvidence(rawUrl:string,timeoutMs=8000,maxBytes=2_000_000):Promise<Evidence>{
  const url=await validatePublicUrl(rawUrl); const controller=new AbortController(); const timer=setTimeout(()=>controller.abort(),Math.max(1000,Math.min(timeoutMs,20000)));
  try{
    const r=await fetch(url,{redirect:'error',signal:controller.signal,headers:{accept:'text/html,text/plain;q=0.9,application/json;q=0.7','user-agent':'JASON-AI-Evidence/1.0'}});
    if(!r.ok)throw new Error(`SOURCE_HTTP_${r.status}`);
    const type=(r.headers.get('content-type')||'').toLowerCase(); if(!(type.includes('text/html')||type.includes('text/plain')||type.includes('application/json')))throw new Error('UNSUPPORTED_CONTENT_TYPE');
    const buf=Buffer.from(await r.arrayBuffer()); if(buf.byteLength>maxBytes)throw new Error('SOURCE_TOO_LARGE');
    const raw=buf.toString('utf8'); const content=type.includes('text/html')?extractHtml(raw):raw.replace(/\s+/g,' ').trim(); if(!content)throw new Error('EMPTY_SOURCE');
    return{id:createHash('sha256').update(url+'\n'+content).digest('hex').slice(0,32),url,title:type.includes('text/html')?titleOf(raw):url,content:content.slice(0,100000),contentHash:createHash('sha256').update(content).digest('hex'),fetchedAt:new Date().toISOString(),confidence:'MEDIUM'};
  }finally{clearTimeout(timer);}
}
export function addMemory(tenantId:string,kind:MemoryKind,content:string,source='user'):MemoryItem{if(!tenantId||!content.trim())throw new Error('INVALID_MEMORY');const now=new Date().toISOString();const item={id:randomUUID(),tenantId,kind,content:content.trim().slice(0,4000),source:source.slice(0,200),createdAt:now,updatedAt:now,active:true};const list=memories.get(tenantId)||[];list.unshift(item);memories.set(tenantId,list.slice(0,1000));return item;}
export function listMemories(tenantId:string,limit=50){return(memories.get(tenantId)||[]).filter(x=>x.active).slice(0,Math.max(1,Math.min(100,limit)));}
export function deleteMemory(tenantId:string,id:string){const item=(memories.get(tenantId)||[]).find(x=>x.id===id);if(!item)return false;item.active=false;item.updatedAt=new Date().toISOString();return true;}
