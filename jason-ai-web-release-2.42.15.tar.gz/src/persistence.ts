import {randomUUID,createHash} from 'node:crypto';
import type {KnowledgeItem} from './knowledge.js';
import type {MemoryItem, MemoryKind} from './private-intelligence.js';
import type {AgentRun, AgentStep} from './agent.js';

export type Tenant={id:string;name:string};
export type StoredDocument={id:string;tenantId:string;name:string;mime:string;sizeBytes:number;sha256:string;status:string;chunkCount:number;createdAt:string};
export type StoredChunk={id:string;tenantId:string;documentId:string;ordinal:number;content:string;contentHash:string};
export type StoredReport={id:string;tenantId:string;kind:string;title:string;content:string;createdAt:string};

export interface Repository {
  ensureTenant(id:string,name?:string):Promise<Tenant>;
  saveDocument(input:{tenantId:string;name:string;mime:string;sizeBytes:number;content:string;chunks:string[]}):Promise<StoredDocument>;
  saveReport(input:{tenantId:string;kind:string;title:string;content:string}):Promise<StoredReport>;
  getDocument(id:string,tenantId:string):Promise<StoredDocument|undefined>;
  listKnowledge(tenantId:string):Promise<KnowledgeItem[]>;
  saveKnowledge(item:KnowledgeItem):Promise<KnowledgeItem>;
  listMemories(tenantId:string,limit?:number):Promise<MemoryItem[]>;
  saveMemory(item:MemoryItem):Promise<MemoryItem>;
  deleteMemory(tenantId:string,id:string):Promise<boolean>;
  saveProject(input:any):Promise<any>;
  listProjects(tenantId:string):Promise<any[]>;
  getProject(id:string,tenantId:string):Promise<any|undefined>;
  updateProject(id:string,tenantId:string,input:any):Promise<any>;
  addProjectItem(input:any):Promise<any>;
  listProjectItems(projectId:string,tenantId:string):Promise<any[]>;
  removeProjectItem(id:string,tenantId:string):Promise<boolean>;
  saveAgentRun(run:AgentRun):Promise<AgentRun>;
  getAgentRun(id:string,tenantId:string):Promise<AgentRun|undefined>;
  listAgentRuns(tenantId:string):Promise<AgentRun[]>;
  ping():Promise<boolean>;
}

export class MemoryRepository implements Repository {
  tenants=new Map<string,Tenant>(); documents=new Map<string,StoredDocument>(); chunks=new Map<string,StoredChunk[]>(); reports=new Map<string,StoredReport>(); knowledge=new Map<string,KnowledgeItem>(); memories=new Map<string,MemoryItem>();
  async ensureTenant(id:string,name='JASON AI Tenant'){const t=this.tenants.get(id)||{id,name};this.tenants.set(id,t);return t;}
  async saveDocument(x:{tenantId:string;name:string;mime:string;sizeBytes:number;content:string;chunks:string[]}){
    await this.ensureTenant(x.tenantId); const id=randomUUID(); const sha256=createHash('sha256').update(x.content).digest('hex'); const createdAt=new Date().toISOString();
    const d={id,tenantId:x.tenantId,name:x.name,mime:x.mime,sizeBytes:x.sizeBytes,sha256,status:'READY',chunkCount:x.chunks.length,createdAt};
    this.documents.set(id,d); this.chunks.set(id,x.chunks.map((content,ordinal)=>({id:randomUUID(),tenantId:x.tenantId,documentId:id,ordinal,content,contentHash:createHash('sha256').update(content).digest('hex')}))); return d;
  }
  async saveReport(x:{tenantId:string;kind:string;title:string;content:string}){await this.ensureTenant(x.tenantId);const r={id:randomUUID(),tenantId:x.tenantId,kind:x.kind,title:x.title,content:x.content,createdAt:new Date().toISOString()};this.reports.set(r.id,r);return r;}
  async getDocument(id:string,tenantId:string){const d=this.documents.get(id);return d?.tenantId===tenantId?d:undefined;}
  async listKnowledge(tenantId:string){return [...this.knowledge.values()].filter(x=>x.tenantId===tenantId&&x.status==='ACTIVE');}
  async saveKnowledge(item:KnowledgeItem){if(item.tenantId){this.knowledge.set(item.id,item);}return item;}
  async listMemories(tenantId:string,limit=100){return [...this.memories.values()].filter(x=>x.tenantId===tenantId&&x.active).sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt)).slice(0,Math.max(1,Math.min(100,limit)));}
  async saveMemory(item:MemoryItem){this.memories.set(item.id,item);return item;}
  async deleteMemory(tenantId:string,id:string){const m=this.memories.get(id);if(!m||m.tenantId!==tenantId)return false;m.active=false;m.updatedAt=new Date().toISOString();return true;}
  projects=new Map<string,any>(); projectItems=new Map<string,any>();
  async saveProject(x:any){await this.ensureTenant(x.tenantId);this.projects.set(x.id,x);return x;}
  async listProjects(tenantId:string){return [...this.projects.values()].filter(x=>x.tenantId===tenantId).sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt));}
  async getProject(id:string,tenantId:string){const x=this.projects.get(id);return x?.tenantId===tenantId?x:undefined;}
  async updateProject(id:string,tenantId:string,x:any){this.projects.set(id,x);return x;}
  async addProjectItem(x:any){this.projectItems.set(x.id,x);return x;}
  async listProjectItems(projectId:string,tenantId:string){return [...this.projectItems.values()].filter(x=>x.projectId===projectId&&x.tenantId===tenantId);}
  async removeProjectItem(id:string,tenantId:string){const x=this.projectItems.get(id);if(!x||x.tenantId!==tenantId)return false;this.projectItems.delete(id);return true;}
  agentRuns=new Map<string,AgentRun>();
  async saveAgentRun(run:AgentRun){this.agentRuns.set(run.id,JSON.parse(JSON.stringify(run)));return run;}
  async getAgentRun(id:string,tenantId:string){const r=this.agentRuns.get(id);return r?.tenantId===tenantId?JSON.parse(JSON.stringify(r)):undefined;}
  async listAgentRuns(tenantId:string){return [...this.agentRuns.values()].filter(r=>r.tenantId===tenantId).sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).map(r=>JSON.parse(JSON.stringify(r)));}
  async ping(){return true;}
}

export class PostgresRepository implements Repository {
  private constructor(private pool:any){}
  static async connect(connectionString:string){const mod:any=await import('pg');const pool=new mod.Pool({connectionString,max:10,idleTimeoutMillis:30000,connectionTimeoutMillis:5000});await pool.query('SELECT 1');return new PostgresRepository(pool);}
  async ensureTenant(id:string,name='JASON AI Tenant'){const q=await this.pool.query('INSERT INTO tenants(id,name) VALUES($1,$2) ON CONFLICT(id) DO UPDATE SET name=EXCLUDED.name RETURNING id,name',[id,name]);return q.rows[0];}
  async saveDocument(x:{tenantId:string;name:string;mime:string;sizeBytes:number;content:string;chunks:string[]}){
    await this.ensureTenant(x.tenantId); const client=await this.pool.connect();
    try { await client.query('BEGIN'); const id=randomUUID(); const sha256=createHash('sha256').update(x.content).digest('hex');
      const d=(await client.query('INSERT INTO documents(id,tenant_id,name,mime,size_bytes,sha256,status,chunk_count) VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id,tenant_id AS "tenantId",name,mime,size_bytes AS "sizeBytes",sha256,status,chunk_count AS "chunkCount",created_at AS "createdAt"',[id,x.tenantId,x.name,x.mime,x.sizeBytes,sha256,'READY',x.chunks.length])).rows[0];
      for(let i=0;i<x.chunks.length;i++){const c=x.chunks[i];await client.query('INSERT INTO document_chunks(id,tenant_id,document_id,ordinal,content,content_hash) VALUES($1,$2,$3,$4,$5,$6)',[randomUUID(),x.tenantId,id,i,c,createHash('sha256').update(c).digest('hex')]);}
      await client.query('COMMIT'); return d;
    } catch(e){await client.query('ROLLBACK');throw e;} finally {client.release();}
  }
  async saveReport(x:{tenantId:string;kind:string;title:string;content:string}){await this.ensureTenant(x.tenantId);const q=await this.pool.query('INSERT INTO reports(id,tenant_id,kind,title,content) VALUES($1,$2,$3,$4,$5) RETURNING id,tenant_id AS "tenantId",kind,title,content,created_at AS "createdAt"',[randomUUID(),x.tenantId,x.kind,x.title,x.content]);return q.rows[0];}
  async getDocument(id:string,tenantId:string){const q=await this.pool.query('SELECT id,tenant_id AS "tenantId",name,mime,size_bytes AS "sizeBytes",sha256,status,chunk_count AS "chunkCount",created_at AS "createdAt" FROM documents WHERE id=$1 AND tenant_id=$2',[id,tenantId]);return q.rows[0];}
  async listKnowledge(tenantId:string){const q=await this.pool.query('SELECT id,tenant_id AS "tenantId",document_id AS "documentId",title,content,version,content_hash AS "contentHash",status,updated_at AS "updatedAt" FROM knowledge_items WHERE tenant_id=$1 AND status=\'ACTIVE\' ORDER BY updated_at DESC',[tenantId]);return q.rows;}
  async saveKnowledge(item:KnowledgeItem){const q=await this.pool.query('INSERT INTO knowledge_items(id,tenant_id,document_id,title,content,version,content_hash,status,updated_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) ON CONFLICT(id) DO UPDATE SET title=EXCLUDED.title,content=EXCLUDED.content,version=EXCLUDED.version,content_hash=EXCLUDED.content_hash,status=EXCLUDED.status,updated_at=EXCLUDED.updated_at RETURNING id,tenant_id AS "tenantId",document_id AS "documentId",title,content,version,content_hash AS "contentHash",status,updated_at AS "updatedAt"',[item.id,item.tenantId,item.documentId,item.title,item.content,item.version,item.contentHash,item.status,item.updatedAt]);return q.rows[0];}
  async listMemories(tenantId:string,limit=100){const q=await this.pool.query('SELECT id,tenant_id AS "tenantId",user_id AS "userId",kind,content,source,created_at AS "createdAt",updated_at AS "updatedAt",active FROM user_memories WHERE tenant_id=$1 AND active=true ORDER BY updated_at DESC LIMIT $2',[tenantId,Math.max(1,Math.min(100,limit))]);return q.rows as MemoryItem[];}
  async saveMemory(item:MemoryItem){const q=await this.pool.query('INSERT INTO user_memories(id,tenant_id,user_id,kind,content,source,active,created_at,updated_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) ON CONFLICT(id) DO UPDATE SET content=EXCLUDED.content,source=EXCLUDED.source,active=EXCLUDED.active,updated_at=EXCLUDED.updated_at RETURNING id,tenant_id AS "tenantId",user_id AS "userId",kind,content,source,active,created_at AS "createdAt",updated_at AS "updatedAt"',[item.id,item.tenantId,(item as any).userId||'system',item.kind,item.content,item.source,item.active,item.createdAt,item.updatedAt]);return q.rows[0];}
  async deleteMemory(tenantId:string,id:string){const q=await this.pool.query('UPDATE user_memories SET active=false,updated_at=NOW() WHERE id=$1 AND tenant_id=$2 AND active=true RETURNING id',[id,tenantId]);return q.rowCount>0;}
  async saveProject(x:any){const q=await this.pool.query('INSERT INTO projects(id,tenant_id,owner_user_id,name,description,status,created_at,updated_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id,tenant_id AS "tenantId",owner_user_id AS "ownerUserId",name,description,status,created_at AS "createdAt",updated_at AS "updatedAt"',[x.id,x.tenantId,x.ownerUserId,x.name,x.description,x.status,x.createdAt,x.updatedAt]);return q.rows[0];}
  async listProjects(tenantId:string){const q=await this.pool.query('SELECT id,tenant_id AS "tenantId",owner_user_id AS "ownerUserId",name,description,status,created_at AS "createdAt",updated_at AS "updatedAt" FROM projects WHERE tenant_id=$1 ORDER BY updated_at DESC',[tenantId]);return q.rows;}
  async getProject(id:string,tenantId:string){const q=await this.pool.query('SELECT id,tenant_id AS "tenantId",owner_user_id AS "ownerUserId",name,description,status,created_at AS "createdAt",updated_at AS "updatedAt" FROM projects WHERE id=$1 AND tenant_id=$2',[id,tenantId]);return q.rows[0];}
  async updateProject(id:string,tenantId:string,x:any){const q=await this.pool.query('UPDATE projects SET name=$3,description=$4,status=$5,updated_at=$6 WHERE id=$1 AND tenant_id=$2 RETURNING id,tenant_id AS "tenantId",owner_user_id AS "ownerUserId",name,description,status,created_at AS "createdAt",updated_at AS "updatedAt"',[id,tenantId,x.name,x.description,x.status,x.updatedAt]);if(!q.rows[0])throw new Error('PROJECT_NOT_FOUND');return q.rows[0];}
  async addProjectItem(x:any){const q=await this.pool.query('INSERT INTO project_items(id,project_id,tenant_id,kind,ref_id,title,created_at) VALUES($1,$2,$3,$4,$5,$6,$7) ON CONFLICT(project_id,kind,ref_id) DO UPDATE SET title=EXCLUDED.title RETURNING id,project_id AS "projectId",tenant_id AS "tenantId",kind,ref_id AS "refId",title,created_at AS "createdAt"',[x.id,x.projectId,x.tenantId,x.kind,x.refId,x.title,x.createdAt]);return q.rows[0];}
  async listProjectItems(projectId:string,tenantId:string){const q=await this.pool.query('SELECT id,project_id AS "projectId",tenant_id AS "tenantId",kind,ref_id AS "refId",title,created_at AS "createdAt" FROM project_items WHERE project_id=$1 AND tenant_id=$2 ORDER BY created_at DESC',[projectId,tenantId]);return q.rows;}
  async removeProjectItem(id:string,tenantId:string){const q=await this.pool.query('DELETE FROM project_items WHERE id=$1 AND tenant_id=$2 RETURNING id',[id,tenantId]);return q.rowCount>0;}
  async saveAgentRun(run:AgentRun){
    await this.ensureTenant(run.tenantId);
    const client=await this.pool.connect();
    try { await client.query('BEGIN');
      await client.query(`INSERT INTO agent_runs(id,tenant_id,user_id,status,max_steps,timeout_ms,max_output_chars,retry_budget,cancelled,error,created_at,updated_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) ON CONFLICT(id) DO UPDATE SET status=EXCLUDED.status,cancelled=EXCLUDED.cancelled,error=EXCLUDED.error,updated_at=EXCLUDED.updated_at`,[run.id,run.tenantId,run.userId,run.status,run.maxSteps,run.timeoutMs,run.maxOutputChars,run.retryBudget,run.cancelled,run.error||null,run.createdAt,run.updatedAt]);
      await client.query('DELETE FROM agent_steps WHERE run_id=$1',[run.id]);
      for(const s of run.steps) await client.query(`INSERT INTO agent_steps(id,run_id,tenant_id,step_index,tool,permission,status,input_fingerprint,output_fingerprint,error,started_at,finished_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,[s.id,run.id,run.tenantId,s.index,s.tool,s.permission,s.status,s.inputFingerprint,s.outputFingerprint||null,s.error||null,s.startedAt||null,s.finishedAt||null]);
      await client.query('COMMIT'); return run;
    } catch(e){await client.query('ROLLBACK');throw e;} finally{client.release();}
  }
  async getAgentRun(id:string,tenantId:string){
    const q=await this.pool.query(`SELECT id,tenant_id AS "tenantId",user_id AS "userId",status,max_steps AS "maxSteps",timeout_ms AS "timeoutMs",max_output_chars AS "maxOutputChars",retry_budget AS "retryBudget",cancelled,error,created_at AS "createdAt",updated_at AS "updatedAt" FROM agent_runs WHERE id=$1 AND tenant_id=$2`,[id,tenantId]);
    if(!q.rows[0]) return undefined; const r=q.rows[0]; const st=await this.pool.query(`SELECT id,run_id AS "runId",step_index AS "index",tool,permission,status,input_fingerprint AS "inputFingerprint",output_fingerprint AS "outputFingerprint",error,started_at AS "startedAt",finished_at AS "finishedAt" FROM agent_steps WHERE run_id=$1 AND tenant_id=$2 ORDER BY step_index`,[id,tenantId]); return {...r,steps:st.rows};
  }
  async listAgentRuns(tenantId:string){const q=await this.pool.query(`SELECT id,tenant_id AS "tenantId",user_id AS "userId",status,max_steps AS "maxSteps",timeout_ms AS "timeoutMs",max_output_chars AS "maxOutputChars",retry_budget AS "retryBudget",cancelled,error,created_at AS "createdAt",updated_at AS "updatedAt" FROM agent_runs WHERE tenant_id=$1 ORDER BY created_at DESC`,[tenantId]); const out=[]; for(const r of q.rows){const st=await this.pool.query(`SELECT id,run_id AS "runId",step_index AS "index",tool,permission,status,input_fingerprint AS "inputFingerprint",output_fingerprint AS "outputFingerprint",error,started_at AS "startedAt",finished_at AS "finishedAt" FROM agent_steps WHERE run_id=$1 AND tenant_id=$2 ORDER BY step_index`,[r.id,tenantId]);out.push({...r,steps:st.rows});} return out;}
  async ping(){await this.pool.query('SELECT 1');return true;}
}

export async function createRepository(){const url=process.env.DATABASE_URL;if(!url)return new MemoryRepository();try{return await PostgresRepository.connect(url);}catch(error){if(process.env.REQUIRE_DATABASE==='true')throw error;return new MemoryRepository();}}
