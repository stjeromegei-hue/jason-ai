import {createServer} from 'node:http';
import {readFile} from 'node:fs/promises';
import {startServer} from './api.js';
const app=await startServer(Number(process.env.PORT||3000));
const original=app.listeners('request')[0] as any; app.removeAllListeners('request');
const files:Record<string,string>={'/':'index.html','/index.html':'index.html','/style.css':'style.css','/manifest.webmanifest':'manifest.webmanifest','/sw.js':'sw.js','/icons/jason.svg':'icons/jason.svg'};
const types:Record<string,string>={'html':'text/html; charset=utf-8','css':'text/css; charset=utf-8','webmanifest':'application/manifest+json','js':'text/javascript; charset=utf-8','svg':'image/svg+xml'};
app.on('request',async(req:any,res:any)=>{const file=files[req.url||''];if(req.method==='GET'&&file){const ext=file.split('.').pop()||'html';try{res.setHeader('Content-Type',types[ext]||'application/octet-stream');res.setHeader('Cache-Control',file==='sw.js'?'no-cache':'public, max-age=3600');res.end(await readFile(new URL(`./ui/${file}`,import.meta.url)));}catch{res.writeHead(404);res.end('Not found')}return;}return original(req,res);});
