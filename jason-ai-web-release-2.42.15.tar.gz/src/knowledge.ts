import {createHash,randomUUID} from 'node:crypto';
export interface KnowledgeItem {id:string;tenantId:string;documentId:string;title:string;content:string;version:number;contentHash:string;status:'ACTIVE'|'STALE'|'DELETED';updatedAt:string}
export interface SearchHit {itemId:string;score:number;snippet:string}
const norm=(s:string)=>s.toLowerCase().replace(/[^a-z0-9\s]/g,' ').split(/\s+/).filter(Boolean);
export function indexKnowledge(tenantId:string,documentId:string,title:string,content:string,version=1):KnowledgeItem {if(!tenantId||!documentId)throw new Error('INVALID_KNOWLEDGE');return {id:randomUUID(),tenantId,documentId,title:title.trim(),content,version,contentHash:createHash('sha256').update(content).digest('hex'),status:'ACTIVE',updatedAt:new Date().toISOString()};}
export function searchKnowledge(items:KnowledgeItem[],tenantId:string,query:string,limit=10):SearchHit[]{const q=new Set(norm(query));if(!q.size)return [];return items.filter(x=>x.tenantId===tenantId&&x.status==='ACTIVE').map(x=>{const words=norm(x.content);const hits=words.filter(w=>q.has(w)).length;const score=Math.min(1,hits/Math.max(1,q.size));return {itemId:x.id,score,snippet:x.content.slice(0,280)};}).filter(x=>x.score>0).sort((a,b)=>b.score-a.score).slice(0,Math.max(1,Math.min(50,limit)));}
export function markStale(item:KnowledgeItem):KnowledgeItem{return {...item,status:'STALE'};}
export function supersede(oldItem:KnowledgeItem,newContent:string):KnowledgeItem{return indexKnowledge(oldItem.tenantId,oldItem.documentId,oldItem.title,newContent,oldItem.version+1);}
export function canAccess(item:KnowledgeItem,tenantId:string){return item.tenantId===tenantId&&item.status!=='DELETED';}
