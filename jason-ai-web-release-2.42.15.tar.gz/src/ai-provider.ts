import { AIProvider, ProviderRequest, ProviderResponse, DeterministicProvider } from './platform.js';

export interface ProviderConfig { name:string; baseUrl:string; apiKey:string; model:string }
export class ProviderHttpError extends Error {
  constructor(public status:number, public headers:Record<string,string>, message:string){super(message);this.name='ProviderHttpError';}
}

export interface StreamEvent { type:'delta'|'done'|'error'; text?:string; usage?:{inputTokens:number;outputTokens:number}; error?:string }

function abortable(ms:number){const c=new AbortController();const t=setTimeout(()=>c.abort(),Math.max(1000,ms));return {c,t};}

export class HttpAIProvider implements AIProvider {
  constructor(private cfg:ProviderConfig){}
  async generate(req:ProviderRequest):Promise<ProviderResponse>{
    if(!this.cfg.baseUrl) throw new Error('AI_PROVIDER_NOT_CONFIGURED');
    const {c,t}=abortable(req.timeoutMs);
    try {
      const r=await fetch(this.cfg.baseUrl,{method:'POST',headers:{'content-type':'application/json',...(this.cfg.apiKey?{'authorization':`Bearer ${this.cfg.apiKey}`}:{})},body:JSON.stringify({model:(!req.model||req.model==='default'||req.model==='deterministic')?this.cfg.model:req.model,input:req.prompt,max_output_tokens:req.maxOutputTokens}),signal:c.signal});
      if(!r.ok){const headers:Record<string,string>={};r.headers.forEach((v,k)=>headers[k.toLowerCase()]=v);throw new ProviderHttpError(r.status,headers,`AI_PROVIDER_HTTP_${r.status}`);}
      const j:any=await r.json();
      return {text:String(j.output_text??j.text??j.output??''),model:(!req.model||req.model==='default'||req.model==='deterministic')?this.cfg.model:req.model,provider:this.cfg.name,usage:{inputTokens:Number(j.usage?.input_tokens||0),outputTokens:Number(j.usage?.output_tokens||0)}};
    } finally { clearTimeout(t); }
  }
  async *stream(req:ProviderRequest):AsyncGenerator<StreamEvent>{
    if(!this.cfg.baseUrl) throw new Error('AI_PROVIDER_NOT_CONFIGURED');
    const {c,t}=abortable(req.timeoutMs);
    try {
      const url=this.cfg.baseUrl.includes('?')?`${this.cfg.baseUrl}&stream=true`:`${this.cfg.baseUrl}?stream=true`;
      const r=await fetch(url,{method:'POST',headers:{'content-type':'application/json',...(this.cfg.apiKey?{'authorization':`Bearer ${this.cfg.apiKey}`}:{ }),'accept':'text/event-stream'},body:JSON.stringify({model:(!req.model||req.model==='default'||req.model==='deterministic')?this.cfg.model:req.model,input:req.prompt,max_output_tokens:req.maxOutputTokens,stream:true}),signal:c.signal});
      if(!r.ok){const headers:Record<string,string>={};r.headers.forEach((v,k)=>headers[k.toLowerCase()]=v);throw new ProviderHttpError(r.status,headers,`AI_PROVIDER_HTTP_${r.status}`);}
      if(!r.body){const j:any=await r.json();const text=String(j.output_text??j.text??j.output??'');yield {type:'delta',text};yield {type:'done',usage:{inputTokens:Number(j.usage?.input_tokens||0),outputTokens:Number(j.usage?.output_tokens||0)}};return;}
      const reader=r.body.getReader(); const decoder=new TextDecoder(); let buffer=''; let inTokens=0; let outTokens=0;
      while(true){const {done,value}=await reader.read(); if(done)break; buffer+=decoder.decode(value,{stream:true}); const lines=buffer.split(/\r?\n/); buffer=lines.pop()||'';
        for(const line of lines){const s=line.trim(); if(!s||s.startsWith(':'))continue; const payload=s.startsWith('data:')?s.slice(5).trim():s; if(payload==='[DONE]'){yield {type:'done',usage:{inputTokens:inTokens,outputTokens:outTokens}}; return;}
          try{const j:any=JSON.parse(payload); const text=String(j.delta??j.text??j.output_text??j.output??j.choices?.[0]?.delta?.content??''); if(text)yield {type:'delta',text}; inTokens+=Number(j.usage?.input_tokens||j.usage?.prompt_tokens||0); outTokens+=Number(j.usage?.output_tokens||j.usage?.completion_tokens||0);}catch{}
        }
      }
      yield {type:'done',usage:{inputTokens:inTokens,outputTokens:outTokens}};
    } finally { clearTimeout(t); }
  }
}

export class StreamingDeterministicProvider extends DeterministicProvider {
  async *stream(req:ProviderRequest):AsyncGenerator<StreamEvent>{
    const text=(await this.generate(req)).text; for(const part of text.split(/(?=\s)/)){yield {type:'delta',text:part}; await Promise.resolve();} yield {type:'done',usage:{inputTokens:0,outputTokens:text.length}};
  }
}
export function configuredProvider():AIProvider & {stream(req:ProviderRequest):AsyncGenerator<StreamEvent>} { return process.env.AI_BASE_URL&&process.env.AI_API_KEY?new HttpAIProvider({name:process.env.AI_PROVIDER_NAME||'configured',baseUrl:process.env.AI_BASE_URL,apiKey:process.env.AI_API_KEY,model:process.env.AI_MODEL||'default'}):new StreamingDeterministicProvider(); }
