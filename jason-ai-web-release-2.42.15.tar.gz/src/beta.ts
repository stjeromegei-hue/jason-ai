import {randomUUID} from 'node:crypto';

export type ConsentKind='privacy'|'terms'|'ai_processing'|'beta_feedback';
export type FeedbackKind='bug'|'idea'|'general';
export interface ConsentRecord {id:string;tenantId:string;userId:string;kind:ConsentKind;version:string;accepted:boolean;createdAt:string}
export interface FeedbackRecord {id:string;tenantId:string;userId:string;kind:FeedbackKind;message:string;createdAt:string}
export interface OnboardingState {tenantId:string;userId:string;completed:boolean;step:string;updatedAt:string}

export class BetaStore {
  readonly consents:ConsentRecord[]=[];
  readonly feedback:FeedbackRecord[]=[];
  readonly onboarding=new Map<string,OnboardingState>();
  setConsent(input:{tenantId:string;userId:string;kind:ConsentKind;version:string;accepted:boolean}):ConsentRecord {
    if(!input.tenantId||!input.userId||!input.version) throw new Error('INVALID_CONSENT');
    const rec={id:randomUUID(),...input,createdAt:new Date().toISOString()};
    this.consents.push(rec); return rec;
  }
  recordFeedback(input:{tenantId:string;userId:string;kind:FeedbackKind;message:string}):FeedbackRecord {
    if(!input.tenantId||!input.userId||!input.message||input.message.length>4000) throw new Error('INVALID_FEEDBACK');
    const rec={id:randomUUID(),...input,createdAt:new Date().toISOString()};
    this.feedback.push(rec); return rec;
  }
  setOnboarding(input:{tenantId:string;userId:string;completed:boolean;step:string}):OnboardingState {
    if(!input.tenantId||!input.userId||!input.step) throw new Error('INVALID_ONBOARDING');
    const state={...input,updatedAt:new Date().toISOString()};
    this.onboarding.set(input.userId,state); return state;
  }
  getOnboarding(userId:string){return this.onboarding.get(userId)||null}
}

export function onboardingSteps(){return [
  {id:'welcome',title:'Welcome to JASON AI',required:true},
  {id:'privacy',title:'Privacy & AI processing',required:true},
  {id:'workspace',title:'Create your workspace',required:true},
  {id:'first-research',title:'Run your first verified research',required:false},
  {id:'first-file',title:'Add a private file',required:false}
] as const;}
