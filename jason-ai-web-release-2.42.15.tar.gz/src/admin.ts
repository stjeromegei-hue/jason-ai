export type AdminRole='OWNER'|'ADMIN'|'MEMBER'|'VIEWER';
export interface AdminSnapshot {tenantId:string;users:number;documents:number;storageBytes:number;tokens:number;researchRuns:number;securityEvents:number;generatedAt:string}
export interface SecurityEvent {id:string;tenantId:string;type:string;severity:'INFO'|'WARN'|'HIGH';at:string;requestId?:string;details:Record<string,string>}
export function adminCan(role:AdminRole,action:'VIEW'|'MANAGE_USERS'|'MANAGE_BILLING'|'MANAGE_SECURITY'){if(action==='VIEW')return true;return role==='OWNER'||role==='ADMIN';}
export function makeSnapshot(tenantId:string,input:Omit<AdminSnapshot,'tenantId'|'generatedAt'>):AdminSnapshot{return {...input,tenantId,generatedAt:new Date().toISOString()};}
export function securityEvent(tenantId:string,type:string,severity:SecurityEvent['severity'],details:Record<string,string>={},requestId?:string):SecurityEvent{return {id:`sec_${tenantId}_${Date.now()}_${Math.random().toString(36).slice(2,8)}`,tenantId,type,severity,at:new Date().toISOString(),requestId,details};}
