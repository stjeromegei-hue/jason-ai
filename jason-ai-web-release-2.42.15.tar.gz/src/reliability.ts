import {createHash} from 'node:crypto';

export type HealthState='healthy'|'degraded'|'failed';
export type DependencyHealth={name:string;state:HealthState;latencyMs?:number;detail?:string};
export type ReliabilitySnapshot={release:string;state:HealthState;dependencies:DependencyHealth[];timestamp:string};
export type RetryPolicy={maxAttempts:number;baseDelayMs:number;maxDelayMs:number};

export const DEFAULT_RETRY_POLICY:RetryPolicy={maxAttempts:3,baseDelayMs:100,maxDelayMs:2000};
export function backoffDelay(attempt:number,p=DEFAULT_RETRY_POLICY){
  const n=Math.max(0,attempt-1); return Math.min(p.maxDelayMs,p.baseDelayMs*2**n);
}
export async function withRetry<T>(fn:()=>Promise<T>, policy=DEFAULT_RETRY_POLICY, sleep=(ms:number)=>new Promise(r=>setTimeout(r,ms))){
  let last:unknown;
  for(let attempt=1;attempt<=Math.max(1,policy.maxAttempts);attempt++){
    try{return await fn()}catch(e){last=e;if(attempt<policy.maxAttempts) await sleep(backoffDelay(attempt,policy));}
  }
  throw last;
}
export function classifyDependency(ok:boolean,detail=''):HealthState{return ok?'healthy':'failed'}
export function aggregateHealth(deps:DependencyHealth[]):HealthState{
  if(deps.some(d=>d.state==='failed')) return 'failed';
  if(deps.some(d=>d.state==='degraded')) return 'degraded';
  return 'healthy';
}
export function snapshot(release:string,dependencies:DependencyHealth[],now=new Date()):ReliabilitySnapshot{
  return {release,state:aggregateHealth(dependencies),dependencies,timestamp:now.toISOString()};
}
export function checksum(data:string|Uint8Array):string{return createHash('sha256').update(typeof data==='string'?data:Array.from(data).map(n=>String.fromCharCode(n)).join('')).digest('hex')}
export function validateBackupMetadata(meta:{sizeBytes:number;sha256:string;createdAt:string;database:string}){
  if(!Number.isSafeInteger(meta.sizeBytes)||meta.sizeBytes<=0) throw new Error('INVALID_BACKUP_SIZE');
  if(!/^[a-f0-9]{64}$/.test(meta.sha256)) throw new Error('INVALID_BACKUP_SHA256');
  if(!meta.database.trim()) throw new Error('INVALID_BACKUP_DATABASE');
  if(Number.isNaN(Date.parse(meta.createdAt))) throw new Error('INVALID_BACKUP_DATE');
  return true;
}
export function recoveryObjectives(){return {rpoMinutes:60,rtoMinutes:120}}
export function readinessForRecovery(input:{backupVerified:boolean;restoreVerified:boolean;migrationsVerified:boolean;secretsVerified:boolean}){
  const failed=Object.entries(input).filter(([,v])=>!v).map(([k])=>k);
  return {ready:failed.length===0,failed};
}
