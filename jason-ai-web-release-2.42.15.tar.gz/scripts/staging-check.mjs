const base=process.env.BASE_URL||'http://127.0.0.1:3000';
const checks=[['health','/health',200],['ready','/ready',200],['metrics','/metrics',200],['meta','/api/meta',200]];
let failed=0;
for(const [name,path,expected] of checks){try{const r=await fetch(base+path); if(r.status!==expected){console.error(`${name}: expected ${expected}, got ${r.status}`);failed++;}else console.log(`${name}: PASS`);}catch(e){console.error(`${name}: FAIL ${e.message}`);failed++;}}
if(failed)process.exit(1);
console.log('STAGING_GATE=PASS');
