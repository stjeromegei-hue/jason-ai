import { access, readFile } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';

const env = process.env;
const errors = [];
const required = ['NODE_ENV','DATABASE_URL','REQUIRE_DATABASE','POSTGRES_DB','POSTGRES_USER','POSTGRES_PASSWORD'];
for (const key of required) if (!env[key]) errors.push(`PREFLIGHT_MISSING:${key}`);
if (env.NODE_ENV !== 'production') errors.push('PREFLIGHT_NODE_ENV');
if (String(env.REQUIRE_DATABASE).toLowerCase() !== 'true') errors.push('PREFLIGHT_REQUIRE_DATABASE');
if (env.DATABASE_URL && !/^postgres(ql)?:\/\//i.test(env.DATABASE_URL)) errors.push('PREFLIGHT_DATABASE_URL');
for (const key of ['DATABASE_URL','POSTGRES_PASSWORD']) {
  if (env[key] && /change[-_ ]?me|changeme|CHANGE_|example|placeholder/i.test(env[key])) errors.push(`PREFLIGHT_DEFAULT_SECRET:${key}`);
}
if (String(env.ALLOW_DETERMINISTIC_AI || 'false').toLowerCase() === 'true') errors.push('PREFLIGHT_DETERMINISTIC_AI_ENABLED');
if (String(env.JASON_PAID_PROVIDERS || 'false').toLowerCase() === 'true' && Number(env.JASON_SPENDING_LIMIT_INR || 0) !== 0) errors.push('PREFLIGHT_PAID_POLICY_NOT_ZERO');

const compose = await readFile('deploy/docker-compose.production.yml','utf8');
if (!compose.includes('condition: service_completed_successfully')) errors.push('PREFLIGHT_MIGRATION_GATE');
if (!compose.includes('condition: service_healthy')) errors.push('PREFLIGHT_DB_HEALTH_GATE');
const nginx = await readFile('deploy/nginx.production.conf','utf8');
if (!nginx.includes('return 308 https://$host$request_uri')) errors.push('PREFLIGHT_HTTPS_REDIRECT');
if (!nginx.includes('ssl_protocols TLSv1.2 TLSv1.3')) errors.push('PREFLIGHT_TLS_POLICY');

const certDir = 'deploy/certs';
const certs = { certificate: false, privateKey: false };
try { await access(`${certDir}/fullchain.pem`); certs.certificate = true; } catch {}
try { await access(`${certDir}/privkey.pem`); certs.privateKey = true; } catch {}
// Certificates are intentionally not committed. A production preflight may require them only when
// TLS termination is performed by this compose stack; set JASON_TLS_TERMINATED_EXTERNALLY=true otherwise.
const externalTls = String(env.JASON_TLS_TERMINATED_EXTERNALLY || 'false').toLowerCase() === 'true';
if (!externalTls && (!certs.certificate || !certs.privateKey)) errors.push('PREFLIGHT_TLS_CERTS_MISSING');

const docker = spawnSync('docker',['compose','config','--quiet'],{encoding:'utf8'});
const dockerAvailable = docker.status === 0;
if (dockerAvailable && !docker.stdout && docker.stderr) errors.push(`PREFLIGHT_DOCKER_COMPOSE:${docker.stderr.trim()}`);

const result = {
  status: errors.length ? 'BLOCKED' : 'PASS',
  dockerComposeValidation: dockerAvailable ? 'PASS' : 'NOT_RUN_NO_DOCKER',
  tls: { externallyTerminated: externalTls, certificatePresent: certs.certificate, privateKeyPresent: certs.privateKey },
  errors,
};
console.log(JSON.stringify(result, null, 2));
if (errors.length) process.exit(1);
