import {readFile, writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';

const root = new URL('..', import.meta.url).pathname;
const pkg = JSON.parse(await readFile(`${root}/package.json`, 'utf8'));
const migrations = await (await import('node:fs/promises')).readdir(`${root}/migrations`);
const requiredFiles = [
  'Dockerfile', '.env.production.example', 'deploy/docker-compose.production.yml',
  'deploy/nginx.production.conf', 'scripts/production-preflight.mjs',
  'scripts/recovery-gate.mjs', 'scripts/rollback-production.mjs'
];
const checks = [];
for (const file of requiredFiles) {
  try { await readFile(`${root}/${file}`); checks.push({name:`file:${file}`,passed:true,required:true,details:'present'}); }
  catch { checks.push({name:`file:${file}`,passed:false,required:true,details:'missing'}); }
}
const sha = process.env.RELEASE_ARTIFACT_SHA256 ?? '';
checks.push({name:'artifact-sha256',passed:/^[a-f0-9]{64}$/.test(sha),required:true,details:sha ? 'valid SHA-256 supplied' : 'set RELEASE_ARTIFACT_SHA256'});
checks.push({name:'deterministic-ai-disabled',passed:!String(process.env.ALLOW_DETERMINISTIC_AI).toLowerCase().match(/^(true|1|yes)$/),required:true,details:'deterministic fallback must not be enabled for production promotion'});
const status = checks.some(c => c.required && !c.passed) ? 'BLOCKED' : 'READY';
const manifest = {
  release: '24215',
  packageVersion: pkg.version,
  environment: 'staging',
  artifactSha256: sha,
  migrations: migrations.filter(x => x.endsWith('.sql')).length,
  checks,
  status,
  generatedAt: new Date().toISOString(),
};
const digest = createHash('sha256').update(JSON.stringify({...manifest, generatedAt: undefined})).digest('hex');
await writeFile(`${root}/RELEASE-MANIFEST-24200.json`, JSON.stringify({...manifest, digest}, null, 2) + '\n');
console.log(`PROMOTION_STATUS=${status}`);
console.log(`RELEASE=${manifest.release}`);
console.log(`MIGRATIONS=${manifest.migrations}`);
console.log(`DIGEST=${digest}`);
if (status !== 'READY') process.exitCode = 2;
