import { access } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';

const required = ['android/settings.gradle','android/build.gradle','android/app/build.gradle','capacitor.config.ts'];
const missing=[];
for (const f of required) { try { await access(f); } catch { missing.push(f); } }
const java = spawnSync('java',['-version'],{encoding:'utf8'});
const gradle = spawnSync('gradle',['--version'],{encoding:'utf8'});
const sdk = process.env.ANDROID_HOME || process.env.ANDROID_SDK_ROOT || '';
const wrapper = await access('android/gradlew').then(()=>true).catch(()=>false);
const report={requiredFiles:missing.length===0,missing,javaAvailable:java.status===0||java.status===1,gradleAvailable:gradle.status===0,androidSdkConfigured:Boolean(sdk),gradleWrapperPresent:wrapper};
console.log(JSON.stringify(report,null,2));
if(!report.requiredFiles || !report.javaAvailable) process.exit(1);
if(!report.gradleAvailable && !report.gradleWrapperPresent) { console.error('ANDROID_BUILD_BLOCKED=NO_GRADLE'); process.exit(2); }
if(!report.androidSdkConfigured) { console.error('ANDROID_BUILD_BLOCKED=NO_ANDROID_SDK'); process.exit(2); }
console.log('ANDROID_BUILD_GATE=PASS');
