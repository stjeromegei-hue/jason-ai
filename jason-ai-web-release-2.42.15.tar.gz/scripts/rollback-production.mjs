import { execFileSync } from 'node:child_process';

const compose = process.env.COMPOSE_FILE || 'deploy/docker-compose.production.yml';
const previous = process.env.PREVIOUS_IMAGE;
if (!previous) throw new Error('PREVIOUS_IMAGE_REQUIRED');
if (!/^[-a-zA-Z0-9._/:@]+$/.test(previous)) throw new Error('INVALID_PREVIOUS_IMAGE');

const env = { ...process.env, JASON_IMAGE: previous };
execFileSync('docker', ['compose', '-f', compose, 'up', '-d', '--no-build', 'jason-ai'], { stdio: 'inherit', env });
console.log(JSON.stringify({ status: 'ROLLBACK_REQUESTED', image: previous }, null, 2));
