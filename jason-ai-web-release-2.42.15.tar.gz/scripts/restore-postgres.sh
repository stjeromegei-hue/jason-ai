#!/bin/sh
set -eu
: "${DATABASE_URL:?DATABASE_URL is required}"
: "${BACKUP_FILE:?BACKUP_FILE is required}"
case "$BACKUP_FILE" in
  *.sql.gz)
    gzip -dc "$BACKUP_FILE" | psql "$DATABASE_URL"
    ;;
  *.sql)
    psql "$DATABASE_URL" < "$BACKUP_FILE"
    ;;
  *.dump|*.backup)
    pg_restore --clean --if-exists --no-owner --dbname="$DATABASE_URL" "$BACKUP_FILE"
    ;;
  *)
    echo 'Backup must be .sql, .sql.gz, .dump, or .backup' >&2
    exit 1
    ;;
esac
echo 'RESTORE=PASS'
