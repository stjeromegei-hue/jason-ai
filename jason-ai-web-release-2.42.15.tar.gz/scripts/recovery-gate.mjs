import {readFileSync,existsSync} from 'node:fs';
const required=['scripts/backup-postgres.sh','scripts/restore-postgres.sh','scripts/rollback-production.mjs','scripts/check-migrations.mjs','deploy/docker-compose.production.yml'];
const missing=required.filter(f=>!existsSync(f));
if(missing.length){console.error(JSON.stringify({ok:false,error:'RECOVERY_ARTIFACTS_MISSING',missing}));process.exit(1)}
const compose=readFileSync('deploy/docker-compose.production.yml','utf8');
const backup=readFileSync('scripts/backup-postgres.sh','utf8');
const restore=readFileSync('scripts/restore-postgres.sh','utf8');
const checks={composeHasPostgres:compose.includes('postgres'),backupUsesPgDump:backup.includes('pg_dump'),restoreUsesPgRestore:restore.includes('pg_restore')||restore.includes('psql'),rollbackDocumented:readFileSync('scripts/rollback-production.mjs','utf8').length>0};
if(Object.values(checks).some(v=>!v)){console.error(JSON.stringify({ok:false,error:'RECOVERY_CHECK_FAILED',checks}));process.exit(1)}
console.log(JSON.stringify({ok:true,checks,rpoMinutes:60,rtoMinutes:120}));
