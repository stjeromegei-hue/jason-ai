import {readdirSync,readFileSync} from 'node:fs';
const files=readdirSync('migrations').filter(x=>x.endsWith('.sql')).sort();
if(!files.length) throw new Error('NO_MIGRATIONS');
const nums=files.map(x=>Number(x.split('_',1)[0]));
if(nums.some(n=>!Number.isInteger(n))) throw new Error('INVALID_MIGRATION_NAME');
if(new Set(nums).size!==nums.length) throw new Error('DUPLICATE_MIGRATION_NUMBER');
for(const f of files){if(!readFileSync('migrations/'+f,'utf8').trim()) throw new Error('EMPTY_MIGRATION:'+f)}
console.log(JSON.stringify({ok:true,count:files.length,latest:files.at(-1)}));
