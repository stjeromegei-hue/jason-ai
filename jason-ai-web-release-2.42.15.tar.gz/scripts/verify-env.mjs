const required=['NODE_ENV','DATABASE_URL','REQUIRE_DATABASE'];
const missing=required.filter(k=>!process.env[k]);
if(missing.length){console.error('Missing required deployment variables:',missing.join(','));process.exit(1)}
if(process.env.NODE_ENV!=='production'&&process.env.NODE_ENV!=='staging'){console.error('NODE_ENV must be staging or production');process.exit(1)}
if(process.env.DATABASE_URL.includes('change-me')){console.error('Refusing default database credential');process.exit(1)}
if(String(process.env.REQUIRE_DATABASE).toLowerCase()!=='true'){console.error('REQUIRE_DATABASE must be true');process.exit(1)}
console.log('ENV_GATE=PASS');
