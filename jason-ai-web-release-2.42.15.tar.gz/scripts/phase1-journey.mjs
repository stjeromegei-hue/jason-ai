import {spawn} from 'node:child_process';
import {setTimeout as delay} from 'node:timers/promises';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
const port=Number(process.env.PHASE1_JOURNEY_PORT||4311);
const env={...process.env,NODE_ENV:'development',REQUIRE_DATABASE:'false',ALLOW_DETERMINISTIC_AI:'true',JASON_PAID_PROVIDERS:'false',JASON_SPENDING_LIMIT_INR:'0',PORT:String(port)};
const child=spawn(process.execPath,['dist/ui-server.js'],{env,stdio:['ignore','pipe','pipe']}); let logs=''; child.stdout.on('data',b=>logs+=b); child.stderr.on('data',b=>logs+=b);
const get=async p=>{const r=await fetch(`http://127.0.0.1:${port}${p}`); return {r,body:await r.text()}};
const post=async(p,b)=>{const r=await fetch(`http://127.0.0.1:${port}${p}`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(b)});return {r,body:await r.text()}};
try{
 for(let i=0;i<50;i++){try{if((await get('/health')).r.status===200)break}catch{} await delay(100)}
 assert.equal((await get('/health')).r.status,200);
 const ui=await get('/'); assert.equal(ui.r.status,200); for(const marker of ['JASON AI','Ask JASON','Research + Verify','Create','Projects','Agents','auth-token']) assert.ok(ui.body.includes(marker),`UI marker missing: ${marker}`);
 assert.equal((await get('/manifest.webmanifest')).r.status,200);
 assert.equal((await get('/style.css')).r.status,200);
 const meta=await get('/api/meta'); assert.equal(meta.r.status,200);
 const caps=await get('/api/capabilities'); assert.equal(caps.r.status,200); const cap=JSON.parse(caps.body); assert.equal(cap.spending.limit,0); assert.equal(cap.spending.paidProvidersEnabled,false);
 const email=`phase1-${randomUUID()}@example.test`,password=['LocalPhase1!','Password123'].join('');
 const sign=await post('/api/auth/signup',{email,password}); assert.equal(sign.r.status,201); const sd=JSON.parse(sign.body); assert.ok(sd.verificationToken);
 assert.equal((await post('/api/auth/verify',{token:sd.verificationToken})).r.status,200);
 const login=await post('/api/auth/login',{email,password}); assert.equal(login.r.status,200); const cookie=login.r.headers.get('set-cookie'); assert.ok(cookie?.includes('jason_session='));
 const authed=async(p,b)=>{const r=await fetch(`http://127.0.0.1:${port}${p}`,{method:b?'POST':'GET',headers:{...(b?{'content-type':'application/json'}:{}),cookie},body:b?JSON.stringify(b):undefined});return {r,body:await r.text()}};
 const me=await authed('/api/auth/me'); assert.equal(me.r.status,200);
 const proj=await authed('/api/projects',{name:'Phase 1 Journey',description:'local acceptance'}); assert.equal(proj.r.status,201); const pd=JSON.parse(proj.body); assert.ok(pd.project.id);
 const report=await authed('/api/reports',{kind:'REPORT',title:'Phase 1 Artifact',sections:['Local acceptance passed.']}); assert.equal(report.r.status,201);
 const ingest=await authed('/api/documents/ingest',{name:'phase1.txt',mime:'text/plain',size:31,content:'JASON private knowledge test.'}); assert.equal(ingest.r.status,201);
 const mem=await authed('/api/memory',{kind:'FACT',content:'Phase 1 journey marker',source:'local-test'}); assert.equal(mem.r.status,201);
 const knowledge=await authed('/api/knowledge/search?q=journey'); assert.equal(knowledge.r.status,200);
 const ai=await authed('/api/ai/generate',{prompt:'Say hello in one short sentence.',maxOutputTokens:50}); assert.equal(ai.r.status,200); const aid=JSON.parse(ai.body); assert.ok(aid.response?.text||aid.text);
 const tools=await authed('/api/agents/tools'); assert.equal(tools.r.status,200); assert.ok(JSON.parse(tools.body).tools);
 const multi=await authed('/api/multimodal'); assert.equal(multi.r.status,200); assert.equal(JSON.parse(multi.body).spending.limit,0);
 const media=await authed('/api/media',{capability:'video',prompt:'test'}); assert.ok([400,503].includes(media.r.status) || media.r.status===429);
 const logout=await authed('/api/auth/logout',{}); assert.equal(logout.r.status,200);
 console.log(JSON.stringify({ok:true,phase:'1.5',journey:'local-full-stack',checks:{ui:true,pwa:true,auth:true,projects:true,artifact:true,filesKnowledge:true,memory:true,ai:true,agents:true,multimodal:true,logout:true},paidProviders:false,spendingLimitInr:0},null,2));
}finally{child.kill('SIGTERM');await delay(150)}
