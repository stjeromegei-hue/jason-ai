import { existsSync, readFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';

const checks = [];
function check(name, passed, details='') { checks.push({ name, passed, details }); }
function command(name) { const r = spawnSync(name, ['--version'], { encoding:'utf8' }); return r.status === 0 ? (r.stdout||r.stderr||'').trim() : null; }

check('production compose file', existsSync('deploy/docker-compose.production.yml'));
check('production environment template', existsSync('.env.production.example'));
check('production runbook', existsSync('PRODUCTION-RUNBOOK.md'));
check('deployment quickstart', existsSync('DEPLOYMENT-QUICKSTART.md'));
check('Docker available locally', Boolean(command('docker')), 'A real production host must provide Docker; absence here is not a source-code failure.');
check('Docker Compose available locally', Boolean(spawnSync('docker',['compose','version'],{encoding:'utf8'}).status === 0), 'Required on the production host.');
check('Node.js available', Boolean(command('node')));
check('npm available', Boolean(command('npm')));
check('Android toolchain is optional for Phase 2', true, 'APK build is intentionally a later gate.');

const envTemplate = readFileSync('.env.production.example','utf8');
check('paid providers disabled in template', /JASON_PAID_PROVIDERS=false/.test(envTemplate));
check('spending ceiling is zero in template', /JASON_SPENDING_LIMIT_INR=0/.test(envTemplate));
check('deterministic AI disabled in production template', /ALLOW_DETERMINISTIC_AI=false/.test(envTemplate) || !/ALLOW_DETERMINISTIC_AI=true/.test(envTemplate));

const missing = checks.filter(c => !c.passed).map(c => c.name);
const infrastructureOnly = new Set(['Docker available locally','Docker Compose available locally']);
const blocking = checks.filter(c => !c.passed && !infrastructureOnly.has(c.name)).map(c => c.name);

console.log(JSON.stringify({
  phase: '2-readiness',
  status: blocking.length ? 'BLOCKED' : 'READY_FOR_HOST_SETUP',
  sourceReady: blocking.length === 0,
  localInfrastructureAvailable: !missing.some(x => infrastructureOnly.has(x)),
  checks,
  nextRequired: [
    'Provision a Linux VPS or equivalent Docker host.',
    'Point a domain/subdomain to the host.',
    'Create .env.production from .env.production.example with real database credentials.',
    'Provide TLS certificates or terminate TLS upstream.',
    'Keep JASON_PAID_PROVIDERS=false and JASON_SPENDING_LIMIT_INR=0 until explicitly changed.',
    'Run npm run launch:production on the host.'
  ]
}, null, 2));
if (blocking.length) process.exit(2);
