const base = process.argv[2] || process.env.JASON_PUBLIC_URL;
if (!base) {
  console.error('Usage: node scripts/post-deploy-smoke.mjs https://your-domain');
  process.exit(2);
}
let url;
try { url = new URL(base); } catch { console.error('Invalid URL'); process.exit(2); }
if (url.protocol !== 'https:') { console.error('Production smoke requires HTTPS'); process.exit(2); }
url.pathname = '/health'; url.search = ''; url.hash = '';
const controller = new AbortController();
const timer = setTimeout(() => controller.abort(), 10000);
try {
  const r = await fetch(url, { signal: controller.signal, redirect: 'error', headers: {'Accept':'application/json'} });
  const body = await r.text();
  const ok = r.ok;
  console.log(JSON.stringify({ok, status:r.status, url:url.toString(), body:body.slice(0,1000)}, null, 2));
  if (!ok) process.exit(1);
} catch (e) {
  console.error(JSON.stringify({ok:false, error:String(e?.message||e)}, null, 2));
  process.exit(1);
} finally { clearTimeout(timer); }
