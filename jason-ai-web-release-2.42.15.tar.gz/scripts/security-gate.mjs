import { readdir, readFile } from 'node:fs/promises';
import { join } from 'node:path';

const root = process.cwd();
const findings = [];
const ignored = new Set(['node_modules', 'dist', '.git', 'deploy/certs']);
const secretPatterns = [
  /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/i,
  /(?:sk|rk)-[A-Za-z0-9_-]{20,}/,
  /AKIA[0-9A-Z]{16}/,
  /password\s*[:=]\s*["'][^"']{8,}["']/i
];

async function walk(dir) {
  const out = [];
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    const rel = join(dir, entry.name).replaceAll('\\', '/').replace(root + '/', '');
    if (ignored.has(entry.name) || rel.startsWith('deploy/certs/')) continue;
    if (entry.isDirectory()) out.push(...await walk(join(dir, entry.name)));
    else out.push(join(dir, entry.name));
  }
  return out;
}

for (const file of await walk(root)) {
  let text;
  try { text = await readFile(file, 'utf8'); } catch { continue; }
  for (const pattern of secretPatterns) {
    if (pattern.test(text) && !file.endsWith('.env.example') && !file.endsWith('.env.production.example')) {
      findings.push({ file: file.replace(root + '/', ''), pattern: pattern.toString() });
      break;
    }
  }
}

const envExample = await readFile('.env.production.example', 'utf8');
const required = ['NODE_ENV=production', 'REQUIRE_DATABASE=true', 'JASON_PAID_PROVIDERS=false', 'JASON_SPENDING_LIMIT_INR=0'];
for (const value of required) {
  if (!envExample.includes(value)) findings.push({ file: '.env.production.example', pattern: `missing ${value}` });
}

console.log(JSON.stringify({ ok: findings.length === 0, findings }, null, 2));
if (findings.length) process.exit(2);
