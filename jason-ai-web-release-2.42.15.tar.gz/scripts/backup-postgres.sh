#!/bin/sh
set -eu
: "${DATABASE_URL:?DATABASE_URL is required}"
OUT_DIR="${BACKUP_DIR:-./backups}"
RETENTION_DAYS="${BACKUP_RETENTION_DAYS:-7}"
mkdir -p "$OUT_DIR"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
FILE="$OUT_DIR/jason-ai-$STAMP.sql.gz"
pg_dump "$DATABASE_URL" | gzip > "$FILE"
find "$OUT_DIR" -type f -name 'jason-ai-*.sql.gz' -mtime "+$RETENTION_DAYS" -delete
printf '%s\n' "$FILE"
