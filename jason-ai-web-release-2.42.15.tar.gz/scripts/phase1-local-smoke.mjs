import { spawn } from 'node:child_process';
import { setTimeout as delay } from 'node:timers/promises';

const port = Number(process.env.PHASE1_PORT || 4310);
const env = {
  ...process.env,
  NODE_ENV: 'development',
  REQUIRE_DATABASE: 'false',
  ALLOW_DETERMINISTIC_AI: 'true',
  JASON_PAID_PROVIDERS: 'false',
  JASON_SPENDING_LIMIT_INR: '0',
  PORT: String(port)
};

const child = spawn(process.execPath, ['dist/ui-server.js'], { env, stdio: ['ignore', 'pipe', 'pipe'] });
let logs = '';
child.stdout.on('data', b => { logs += b.toString(); });
child.stderr.on('data', b => { logs += b.toString(); });

async function get(path) {
  const r = await fetch(`http://127.0.0.1:${port}${path}`);
  return { status: r.status, body: await r.text(), headers: r.headers };
}

try {
  let ready = false;
  for (let i = 0; i < 40; i++) {
    try {
      const r = await get('/health');
      if (r.status === 200) { ready = true; break; }
    } catch {}
    await delay(100);
  }
  if (!ready) throw new Error(`LOCAL_SERVER_NOT_READY\n${logs}`);

  const health = await get('/health');
  if (health.status !== 200 || !JSON.parse(health.body).ok) throw new Error('HEALTH_FAILED');

  const ui = await get('/');
  if (ui.status !== 200 || !ui.body.includes('JASON AI')) throw new Error('UI_FAILED');

  const manifest = await get('/manifest.webmanifest');
  if (manifest.status !== 200) throw new Error('PWA_MANIFEST_FAILED');

  const capabilities = await get('/api/capabilities');
  if (![200, 401].includes(capabilities.status)) throw new Error(`CAPABILITIES_UNEXPECTED_${capabilities.status}`);

  console.log(JSON.stringify({
    ok: true,
    phase: 1,
    mode: 'local-development',
    paidProviders: false,
    spendingLimitInr: 0,
    checks: {
      health: health.status === 200,
      ui: ui.status === 200,
      pwaManifest: manifest.status === 200,
      capabilitiesEndpoint: [200, 401].includes(capabilities.status)
    }
  }, null, 2));
} finally {
  child.kill('SIGTERM');
  await delay(100);
}
