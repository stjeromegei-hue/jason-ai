#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
ENV_FILE="${ENV_FILE:-.env.production}"
COMPOSE=(docker compose --env-file "$ENV_FILE" -f deploy/docker-compose.production.yml)

echo '[1/5] Verify production environment'
if [[ ! -f "$ENV_FILE" ]]; then echo "Missing $ENV_FILE" >&2; exit 2; fi
set -a; source "$ENV_FILE"; set +a
npm run verify:env

echo '[2/5] Run production preflight'
npm run production:preflight

echo '[3/5] Validate compose configuration'
"${COMPOSE[@]}" config --quiet

echo '[4/5] Build and start production stack'
"${COMPOSE[@]}" up -d --build

echo '[5/5] Wait for application health'
for i in {1..30}; do
  if "${COMPOSE[@]}" exec -T jason-ai node -e "fetch('http://127.0.0.1:3000/health').then(r=>process.exit(r.ok?0:1)).catch(()=>process.exit(1))"; then
    echo 'JASON AI application is healthy.'
    break
  fi
  if [[ "$i" == 30 ]]; then echo 'Application did not become healthy.' >&2; "${COMPOSE[@]}" ps; exit 1; fi
  sleep 2
done
if [[ -n "${JASON_PUBLIC_URL:-}" ]]; then
  node scripts/post-deploy-smoke.mjs "$JASON_PUBLIC_URL"
else
  echo 'JASON_PUBLIC_URL not set; external HTTPS smoke test not run.'
fi
"${COMPOSE[@]}" ps
