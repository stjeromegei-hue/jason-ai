# JASON AI — Phase 20201–20400

Production Operations & Staging foundation.

## Included
- Request IDs and correlation-safe JSON logs
- Internal-error redaction
- Graceful SIGTERM/SIGINT shutdown
- `/health`, `/ready`, and `/metrics`
- Migration integrity check
- PostgreSQL backup script with retention
- Production release version 20400
- CI/release-check compatible workflow

## Commands
`npm run release:check`

`DATABASE_URL=... ./scripts/backup-postgres.sh`

## Deployment boundary
Credentials, hosting, DNS, managed PostgreSQL, AI provider secrets, and public deployment are intentionally external. No credentials are embedded in the release.
