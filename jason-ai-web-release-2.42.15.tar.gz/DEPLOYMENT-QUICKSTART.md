# JASON AI — Production Deployment Quickstart

This package is deployment-ready but does not contain production credentials, TLS private keys, or a signed Android keystore.

## Host requirements

- Ubuntu 22.04/24.04 or equivalent Linux host
- Docker Engine + Docker Compose v2
- Public DNS record pointing to the host
- Ports 80 and 443 available
- PostgreSQL is provided by the Compose stack
- Node.js 22/npm is useful for release verification; runtime is containerized

## 1. Prepare the environment

```bash
cp .env.production.example .env.production
chmod 600 .env.production
```

Edit `.env.production` and replace every placeholder. Keep:

```text
NODE_ENV=production
REQUIRE_DATABASE=true
JASON_PAID_PROVIDERS=false
JASON_SPENDING_LIMIT_INR=0
ALLOW_DETERMINISTIC_AI=false
```

Set `JASON_PUBLIC_URL=https://your-domain.example` for the external smoke test.

## 2. TLS

Place the certificate and private key at:

```text
deploy/certs/fullchain.pem
deploy/certs/privkey.pem
```

Do not commit these files.

If TLS is terminated by a trusted external load balancer instead, set:

```text
JASON_TLS_TERMINATED_EXTERNALLY=true
```

and expose the application only through that controlled proxy/load balancer.

## 3. Launch

```bash
npm ci
npm run launch:production
```

The launch script verifies the environment, runs production preflight, validates Compose, builds/starts the stack, waits for `/health`, and runs the HTTPS smoke test when `JASON_PUBLIC_URL` is set.

## 4. Backups

With PostgreSQL client tools available:

```bash
DATABASE_URL='...' BACKUP_DIR=./backups ./scripts/backup-postgres.sh
```

The backup is a compressed SQL dump (`.sql.gz`). Restore with:

```bash
DATABASE_URL='...' BACKUP_FILE=./backups/jason-ai-YYYYMMDDTHHMMSSZ.sql.gz ./scripts/restore-postgres.sh
```

Test restores on a separate database before relying on them for disaster recovery.

## 5. Rollback

Tag each released application image before promotion. To roll back to an existing image:

```bash
PREVIOUS_IMAGE='registry.example/jason-ai:previous' \
  npm run rollback:production
```

The rollback command does not rebuild the application and explicitly selects the previous image.

## 6. Android

After the API has a stable HTTPS URL, configure `JASON_API_BASE` in the Android build and run the Android build gate. A release keystore must be supplied outside this repository.
