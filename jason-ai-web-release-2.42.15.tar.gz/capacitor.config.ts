import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig={appId:'ai.jason.private',appName:'JASON AI',webDir:'dist/ui',server:{androidScheme:'https'}};
export default config;
