import test from 'node:test';
import assert from 'node:assert/strict';
import {extractBinaryText,chunkText} from '../dist/file-intelligence.js';

function zip(files){
  const chunks=[]; let offset=0;
  for(const [name,content] of Object.entries(files)){
    const n=Buffer.from(name), d=Buffer.from(content); const h=Buffer.alloc(30);
    h.writeUInt32LE(0x04034b50,0); h.writeUInt16LE(20,4); h.writeUInt16LE(0,6); h.writeUInt16LE(0,8); h.writeUInt32LE(0,14); h.writeUInt32LE(d.length,18); h.writeUInt32LE(d.length,22); h.writeUInt16LE(n.length,26); h.writeUInt16LE(0,28);
    chunks.push(h,n,d); offset+=30+n.length+d.length;
  }
  return Buffer.concat(chunks);
}

test('DOCX native extraction reads document XML',()=>{
  const b=zip({'word/document.xml':'<w:document><w:body><w:p><w:r><w:t>JASON private knowledge</w:t></w:r></w:p></w:body></w:document>'});
  const x=extractBinaryText('notes.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document',b);
  assert.match(x.text,/JASON private knowledge/); assert.equal(x.metadata.extraction,'native-text');
});

test('XLSX native extraction reads shared strings and cells',()=>{
  const b=zip({'xl/sharedStrings.xml':'<sst><si><t>Revenue</t></si><si><t>100</t></si></sst>','xl/worksheets/sheet1.xml':'<worksheet><sheetData><row><c t="s"><v>0</v></c><c t="s"><v>1</v></c></row></sheetData></worksheet>'});
  const x=extractBinaryText('data.xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',b);
  assert.match(x.text,/Revenue/); assert.match(x.text,/100/);
});

test('PPTX native extraction reads slide text',()=>{
  const b=zip({'ppt/slides/slide1.xml':'<p:sld><p:cSld><a:t>Quarterly strategy</a:t></p:cSld></p:sld>'});
  const x=extractBinaryText('deck.pptx','application/vnd.openxmlformats-officedocument.presentationml.presentation',b);
  assert.match(x.text,/Quarterly strategy/);
});

test('CSV is accepted and chunked deterministically',()=>{
  const csv=Buffer.from('name,score\nalpha,10\nbeta,20');
  const x=extractBinaryText('scores.csv','text/csv',csv); const chunks=chunkText(x.text,100,10);
  assert.match(x.text,/alpha,10/); assert.equal(chunks.length,1);
});

test('unsafe Office archive path is rejected',()=>{
  const b=zip({'../word/document.xml':'<w:t>bad</w:t>'});
  assert.throws(()=>extractBinaryText('bad.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document',b),/EMPTY_DOCUMENT/);
});


test('multipart upload endpoint ingests Office file into Knowledge', async()=>{
  const {startServer}=await import('../dist/api.js');
  const server=await startServer(0);
  await new Promise(r=>server.once('listening',r));
  const port=server.address().port;
  const b=zip({'word/document.xml':'<w:document><w:body><w:p><w:r><w:t>Upload pipeline verified</w:t></w:r></w:p></w:body></w:document>'});
  const form=new FormData(); form.append('file',new Blob([b],{type:'application/vnd.openxmlformats-officedocument.wordprocessingml.document'}),'verified.docx');
  const res=await fetch(`http://127.0.0.1:${port}/api/documents/upload`,{method:'POST',body:form});
  const out=await res.json(); server.close();
  assert.equal(res.status,201); assert.equal(out.knowledge.status,'ACTIVE'); assert.match(out.document.metadata.extraction,/native-text/); assert.equal(out.chunks,1);
});
