import test from 'node:test';
import assert from 'node:assert/strict';
import {startServer} from '../dist/api.js';
import {MemoryRepository} from '../dist/persistence.js';

test('API wires document knowledge and memory into answer context',async()=>{
 const oldNode=process.env.NODE_ENV, oldFallback=process.env.ALLOW_DETERMINISTIC_AI;
 process.env.NODE_ENV='development'; process.env.ALLOW_DETERMINISTIC_AI='true';
 const server=await startServer(32107,new MemoryRepository()); const port=32107;
 try{
  const ingest=await fetch(`http://127.0.0.1:${port}/api/documents/ingest`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({name:'notes.txt',mime:'text/plain',size:65,content:'JASON AI private project uses a zero cost spending ceiling.'})});
  assert.equal(ingest.status,201); const ij=await ingest.json(); assert.equal(ij.knowledge.status,'ACTIVE');
  const mem=await fetch(`http://127.0.0.1:${port}/api/memory`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({kind:'PREFERENCE',content:'Always prefer evidence-backed answers'})});
  assert.equal(mem.status,201);
  const answer=await fetch(`http://127.0.0.1:${port}/api/ai/generate`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({prompt:'What does JASON AI use as a spending ceiling?',capability:'chat'})});
  assert.equal(answer.status,200); const aj=await answer.json(); assert.ok(Array.isArray(aj.sources)); assert.ok(aj.sources.some(x=>x.kind==='KNOWLEDGE')); assert.match(aj.text,/PRIVATE\/VERIFIED CONTEXT|JASON AI/);
 } finally {await new Promise(r=>server.close(r)); process.env.NODE_ENV=oldNode; if(oldFallback===undefined)delete process.env.ALLOW_DETERMINISTIC_AI;else process.env.ALLOW_DETERMINISTIC_AI=oldFallback;}
});
