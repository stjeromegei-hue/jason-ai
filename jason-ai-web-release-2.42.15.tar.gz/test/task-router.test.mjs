import test from 'node:test'; import assert from 'node:assert/strict'; import {classifyTask,routeTask} from '../dist/task-router.js';
test('classifies video and research tasks',()=>{assert.equal(classifyTask('create a video about Bengaluru'),'video');assert.equal(classifyTask('research the latest policy with citations'),'research');});
test('zero cost keeps paid disabled',()=>{delete process.env.JASON_PAID_PROVIDERS;process.env.JASON_SPENDING_LIMIT_INR='0';const r=routeTask('make an image');assert.equal(r.paidAllowed,false);assert.equal(r.mode,'free');});
