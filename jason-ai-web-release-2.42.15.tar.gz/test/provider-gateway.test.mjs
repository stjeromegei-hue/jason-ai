import test from 'node:test';
import assert from 'node:assert/strict';
import {AIGateway} from '../dist/provider-gateway.js';
import {ProviderHttpError} from '../dist/ai-provider.js';

class Failing { constructor(){this.calls=0} async generate(){this.calls++; throw new Error('DOWN')} async *stream(){this.calls++; throw new Error('DOWN')} }
class Good { async generate(r){return {text:'ok',model:r.model,provider:'good',usage:{inputTokens:1,outputTokens:1}}} async *stream(){yield {type:'delta',text:'ok'};yield {type:'done',usage:{inputTokens:1,outputTokens:1}}} }
test('gateway falls back after bounded retries',async()=>{const f=new Failing();const g=new AIGateway({fallbackEnabled:true,timeoutMs:2000,maxRetries:1},f,new Good());const r=await g.generate({tenantId:'t',model:'m',prompt:'hello',maxOutputTokens:10,timeoutMs:1000});assert.equal(r.fallback,true);assert.equal(r.provider,'good');assert.equal(f.calls,2)});
test('gateway rejects empty input',async()=>{const g=new AIGateway({fallbackEnabled:true,timeoutMs:2000,maxRetries:0},undefined,new Good());await assert.rejects(()=>g.generate({tenantId:'t',model:'m',prompt:'',maxOutputTokens:10,timeoutMs:1000}),/INVALID_AI_INPUT/)});
test('gateway streams fallback',async()=>{const g=new AIGateway({fallbackEnabled:true,timeoutMs:2000,maxRetries:0},new Failing(),new Good());const a=[];for await(const e of g.stream({tenantId:'t',model:'m',prompt:'hello',maxOutputTokens:10,timeoutMs:1000}))a.push(e);assert.equal(a.at(-1).type,'done');assert.ok(a.some(x=>x.type==='delta'))});


test('gateway tries multiple configured fallbacks in order',async()=>{
  class NamedFail { constructor(name){this.name=name;this.calls=0} async generate(){this.calls++;throw new Error(this.name)} }
  class NamedGood { async generate(r){return {text:'fallback-ok',model:r.model,provider:'free-2',usage:{inputTokens:1,outputTokens:1}}} }
  const a=new NamedFail('A'), b=new NamedFail('B');
  const g=new AIGateway({fallbackEnabled:true,timeoutMs:2000,maxRetries:0,fallbacks:[{name:'free-1',baseUrl:'x',apiKey:'',model:'m1'},{name:'free-2',baseUrl:'y',apiKey:'',model:'m2'}]},a,new Good(),[b,new NamedGood()]);
  const r=await g.generate({tenantId:'t',model:'default',prompt:'hello',maxOutputTokens:10,timeoutMs:1000});
  assert.equal(r.provider,'free-2'); assert.equal(r.fallback,true); assert.equal(a.calls,1); assert.equal(b.calls,1);
});

test('environment provider pool excludes paid slots in zero cost mode',async()=>{
  const old={...process.env};
  try{
    process.env.NODE_ENV='development'; process.env.ALLOW_DETERMINISTIC_AI='true'; process.env.JASON_PAID_PROVIDERS='false'; process.env.JASON_SPENDING_LIMIT_INR='0';
    process.env.AI_BASE_URL='https://primary.example'; process.env.AI_API_KEY='k'; process.env.AI_MODEL='primary-model'; process.env.AI_PROVIDER_PAID='false';
    process.env.AI_FALLBACK_1_BASE_URL='https://free.example'; process.env.AI_FALLBACK_1_MODEL='free-model'; process.env.AI_FALLBACK_1_API_KEY='k'; process.env.AI_FALLBACK_1_PAID='false';
    process.env.AI_FALLBACK_2_BASE_URL='https://paid.example'; process.env.AI_FALLBACK_2_MODEL='paid-model'; process.env.AI_FALLBACK_2_API_KEY='k'; process.env.AI_FALLBACK_2_PAID='true';
    const {createGatewayFromEnv}=await import('../dist/provider-gateway.js?pooltest='+Date.now());
    const h=createGatewayFromEnv().health();
    assert.deepEqual(h.providers.map(x=>x.name),['ai','ai_fallback_1']);
    assert.equal(h.providers.some(x=>x.name==='free-2'),false);
  } finally { for(const k of Object.keys(process.env)){if(!(k in old))delete process.env[k];} Object.assign(process.env,old); }
});

test('capability-specific pool takes precedence over generic pool',async()=>{
  const old={...process.env};
  try{
    process.env.NODE_ENV='development'; process.env.ALLOW_DETERMINISTIC_AI='true'; process.env.JASON_PAID_PROVIDERS='false'; process.env.JASON_SPENDING_LIMIT_INR='0';
    process.env.AI_BASE_URL='https://generic.example'; process.env.AI_API_KEY='k'; process.env.AI_MODEL='generic';
    process.env.AI_CODING_BASE_URL='https://coding.example'; process.env.AI_CODING_API_KEY='k'; process.env.AI_CODING_MODEL='coding'; process.env.AI_CODING_NAME='coding-primary';
    const {createGatewayFromEnv}=await import('../dist/provider-gateway.js?captest='+Date.now());
    const g=createGatewayFromEnv();
    const calls=[];
    const replacement=async req=>{calls.push(req.capability); return {text:'coding',model:'coding',provider:'coding-primary',usage:{inputTokens:1,outputTokens:1}}};
    const cp=g;
    // Replace the capability provider through its private runtime map for deterministic unit verification.
    cp.capabilityProviders.coding.primary={generate:replacement};
    const r=await g.generate({tenantId:'t',capability:'coding',model:'default',prompt:'write code',maxOutputTokens:10,timeoutMs:1000});
    assert.equal(r.provider,'coding-primary'); assert.deepEqual(calls,['coding']);
  } finally { for(const k of Object.keys(process.env)){if(!(k in old))delete process.env[k];} Object.assign(process.env,old); }
});

test('capability health exposes independent pool names without secrets',async()=>{
  const old={...process.env};
  try{
    process.env.NODE_ENV='development'; process.env.ALLOW_DETERMINISTIC_AI='true'; process.env.JASON_PAID_PROVIDERS='false'; process.env.JASON_SPENDING_LIMIT_INR='0';
    process.env.AI_REASONING_BASE_URL='https://reason.example'; process.env.AI_REASONING_API_KEY='secret'; process.env.AI_REASONING_MODEL='reason'; process.env.AI_REASONING_NAME='reasoning-primary';
    const {createGatewayFromEnv}=await import('../dist/provider-gateway.js?healthcap='+Date.now());
    const h=createGatewayFromEnv().health();
    assert.equal(h.capabilities.reasoning.primary,'reasoning-primary');
    assert.equal(JSON.stringify(h).includes('secret'),false);
  } finally { for(const k of Object.keys(process.env)){if(!(k in old))delete process.env[k];} Object.assign(process.env,old); }
});

test('scheduler skips an explicitly exhausted provider',async()=>{
  class Named { constructor(name){this.name=name;this.calls=0} async generate(r){this.calls++;return {text:this.name,model:r.model,provider:this.name,usage:{inputTokens:1,outputTokens:1}}} }
  const exhausted=new Named('exhausted'), available=new Named('available');
  const g=new AIGateway({fallbackEnabled:true,timeoutMs:2000,maxRetries:0,
    primary:{name:'exhausted',baseUrl:'x',apiKey:'',model:'m'},
    fallbacks:[{name:'available',baseUrl:'y',apiKey:'',model:'m'}],
    providerQuotas:{exhausted:{limit:10,remaining:0,resetAt:new Date(Date.now()+60000).toISOString()},available:{limit:10,remaining:7}},
  },exhausted,new Good(),[available]);
  const r=await g.generate({tenantId:'t',model:'default',prompt:'hello',maxOutputTokens:10,timeoutMs:1000});
  assert.equal(r.provider,'available'); assert.equal(exhausted.calls,0); assert.equal(available.calls,1);
});

test('scheduler prefers provider with more remaining quota',async()=>{
  class Named { constructor(name){this.name=name} async generate(r){return {text:this.name,model:r.model,provider:this.name,usage:{inputTokens:1,outputTokens:1}}} }
  const a=new Named('a'),b=new Named('b');
  const g=new AIGateway({fallbackEnabled:true,timeoutMs:2000,maxRetries:0,
    primary:{name:'a',baseUrl:'x',apiKey:'',model:'m'},fallbacks:[{name:'b',baseUrl:'y',apiKey:'',model:'m'}],
    providerQuotas:{a:{limit:10,remaining:2},b:{limit:10,remaining:8}},
  },a,new Good(),[b]);
  const r=await g.generate({tenantId:'t',model:'default',prompt:'hello',maxOutputTokens:10,timeoutMs:1000});
  assert.equal(r.provider,'b');
});

test('scheduler re-enables a provider after its reset time',async()=>{
  class Named { constructor(name){this.name=name;this.calls=0} async generate(r){this.calls++;return {text:this.name,model:r.model,provider:this.name,usage:{inputTokens:1,outputTokens:1}}} }
  const reset=new Named('reset');
  const g=new AIGateway({fallbackEnabled:true,timeoutMs:2000,maxRetries:0,
    primary:{name:'reset',baseUrl:'x',apiKey:'',model:'m'},
    providerQuotas:{reset:{limit:3,remaining:0,resetAt:new Date(Date.now()-1000).toISOString()}},
  },reset,new Good());
  const r=await g.generate({tenantId:'t',model:'default',prompt:'hello',maxOutputTokens:10,timeoutMs:1000});
  assert.equal(r.provider,'reset'); assert.equal(reset.calls,1);
});

test('429 retry metadata marks a provider exhausted and routes to fallback',async()=>{
  class RateLimited { constructor(){this.calls=0} async generate(){this.calls++;throw new ProviderHttpError(429,{'retry-after':'60','x-ratelimit-remaining':'0'},'AI_PROVIDER_HTTP_429')} }
  const limited=new RateLimited();
  const g=new AIGateway({fallbackEnabled:true,timeoutMs:2000,maxRetries:0,
    primary:{name:'limited',baseUrl:'x',apiKey:'',model:'m'},fallbacks:[{name:'backup',baseUrl:'y',apiKey:'',model:'m'}],
    providerQuotas:{limited:{limit:10,remaining:10},backup:{limit:10,remaining:5}},
  },limited,new Good(),[new Good()]);
  const r=await g.generate({tenantId:'t',model:'default',prompt:'hello',maxOutputTokens:10,timeoutMs:1000});
  assert.equal(r.fallback,true); assert.equal(limited.calls,1);
  const h=g.health(); assert.equal(h.quota.find(x=>x.name==='limited').status,'exhausted');
});

test('unknown provider quota remains eligible',async()=>{
  const g=new AIGateway({fallbackEnabled:true,timeoutMs:2000,maxRetries:0,
    primary:{name:'unknown',baseUrl:'x',apiKey:'',model:'m'}
  },new Good(),new Good());
  const r=await g.generate({tenantId:'t',model:'default',prompt:'hello',maxOutputTokens:10,timeoutMs:1000});
  assert.equal(r.provider,'good'); assert.equal(g.health().quota[0].status,'unknown');
});

test('capability pools maintain independent quota scheduling',async()=>{
  class Named { constructor(name){this.name=name} async generate(r){return {text:this.name,model:r.model,provider:this.name,usage:{inputTokens:1,outputTokens:1}}} }
  const generic=new Named('generic'), codingLow=new Named('coding-low'), codingHigh=new Named('coding-high');
  const g=new AIGateway({fallbackEnabled:true,timeoutMs:2000,maxRetries:0,
    primary:{name:'generic',baseUrl:'x',apiKey:'',model:'m'},
    capabilityPools:{coding:{primary:{name:'coding-low',baseUrl:'x',apiKey:'',model:'m'},fallbacks:[{name:'coding-high',baseUrl:'x',apiKey:'',model:'m'}]}},
    providerQuotas:{generic:{limit:10,remaining:9},'coding-low':{limit:10,remaining:1},'coding-high':{limit:10,remaining:6}},
  },generic,new Good(),[],{coding:{primary:codingLow,fallbacks:[codingHigh]}});
  const r=await g.generate({tenantId:'t',capability:'coding',model:'default',prompt:'hello',maxOutputTokens:10,timeoutMs:1000});
  assert.equal(r.provider,'coding-high'); assert.equal(generic!==codingHigh,true);
});
