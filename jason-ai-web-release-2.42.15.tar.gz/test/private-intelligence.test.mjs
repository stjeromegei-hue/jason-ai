import test from 'node:test';
import assert from 'node:assert/strict';
import {addMemory,listMemories,deleteMemory,validatePublicUrl} from '../dist/private-intelligence.js';
test('memory is tenant isolated',()=>{const a=addMemory('t1','FACT','hello');addMemory('t2','FACT','secret');assert.equal(listMemories('t1').length,1);assert.equal(listMemories('t1')[0].content,'hello');assert.equal(deleteMemory('t1',a.id),true);assert.equal(listMemories('t1').length,0);assert.equal(listMemories('t2').length,1)});
test('private URLs fail closed',async()=>{await assert.rejects(()=>validatePublicUrl('http://127.0.0.1/x'),/PRIVATE_URL_FORBIDDEN/);await assert.rejects(()=>validatePublicUrl('file:///etc/passwd'),/UNSUPPORTED_URL_SCHEME/)});
