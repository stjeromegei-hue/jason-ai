import test from 'node:test';
import assert from 'node:assert/strict';
import {requestContext,formatError} from '../dist/operations.js';

test('request ids accept safe inbound ids',()=>{const c=requestContext({'x-request-id':'release-20400'});assert.equal(c.requestId,'release-20400')});
test('invalid request ids are replaced',()=>{const c=requestContext({'x-request-id':'bad id'});assert.notEqual(c.requestId,'bad id');assert.ok(c.requestId.length>8)});
test('internal errors do not leak implementation details',()=>{assert.deepEqual(formatError(new Error('SECRET_DB_PASSWORD'), 'r1'),{error:'internal_error',requestId:'r1'})});

test('rate limiter fails closed after configured limit',async()=>{
  const {FixedWindowRateLimiter,isJsonContentType}=await import('../dist/operations.js');
  const r=new FixedWindowRateLimiter(2,60000);
  assert.equal(r.allow('x',1000),true); assert.equal(r.allow('x',1001),true); assert.equal(r.allow('x',1002),false); assert.equal(r.allow('x',61001),true);
  assert.equal(isJsonContentType({'content-type':'application/json; charset=utf-8'}),true); assert.equal(isJsonContentType({'content-type':'text/plain'}),false);
});
