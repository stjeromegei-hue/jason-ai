import test from 'node:test';
import assert from 'node:assert/strict';
import {MemoryUsageStore,UsageLimitError} from '../dist/usage.js';

test('usage quota blocks the 11th video and exposes reset', async()=>{
  process.env.JASON_VIDEO_LIMIT='10';
  process.env.JASON_USAGE_RESET_HOUR='7';
  process.env.JASON_USAGE_RESET_MINUTE='57';
  process.env.JASON_USAGE_TIMEZONE='Asia/Kolkata';
  const s=new MemoryUsageStore();
  for(let i=0;i<10;i++) await s.consume('private','video');
  const state=await s.state('private','video');
  assert.equal(state.used,10); assert.equal(state.remaining,0); assert.equal(state.status,'EXHAUSTED'); assert.ok(state.resetAt);
  await assert.rejects(()=>s.consume('private','video'),e=>e instanceof UsageLimitError && e.state.resetAt===state.resetAt);
});

test('usage is isolated by tenant', async()=>{
  process.env.JASON_IMAGE_LIMIT='2';
  const s=new MemoryUsageStore();
  await s.consume('a','images'); await s.consume('a','images');
  assert.equal((await s.state('a','images')).status,'EXHAUSTED');
  assert.equal((await s.state('b','images')).used,0);
});
