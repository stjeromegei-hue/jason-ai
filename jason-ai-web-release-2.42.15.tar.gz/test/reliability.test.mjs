import test from 'node:test';
import assert from 'node:assert/strict';
import {backoffDelay,withRetry,aggregateHealth,snapshot,checksum,validateBackupMetadata,recoveryObjectives,readinessForRecovery} from '../dist/reliability.js';

test('retry uses bounded exponential backoff',()=>{assert.equal(backoffDelay(1),100);assert.equal(backoffDelay(2),200);assert.equal(backoffDelay(20),2000)});
test('retry succeeds after transient failures',async()=>{let n=0;const sleeps=[];const v=await withRetry(async()=>{n++;if(n<3)throw Error('temporary');return 'ok'}, {maxAttempts:3,baseDelayMs:5,maxDelayMs:20},async ms=>sleeps.push(ms));assert.equal(v,'ok');assert.equal(n,3);assert.deepEqual(sleeps,[5,10])});
test('retry exhausts and preserves final error',async()=>{let n=0;await assert.rejects(()=>withRetry(async()=>{n++;throw Error('final')},{maxAttempts:2,baseDelayMs:1,maxDelayMs:2},async()=>{}),/final/);assert.equal(n,2)});
test('health aggregation fails closed',()=>{assert.equal(aggregateHealth([]),'healthy');assert.equal(aggregateHealth([{name:'db',state:'degraded'}]),'degraded');assert.equal(aggregateHealth([{name:'db',state:'healthy'},{name:'ai',state:'failed'}]),'failed')});
test('snapshot contains release and timestamp',()=>{const s=snapshot('22000',[{name:'db',state:'healthy'}],new Date('2026-01-01T00:00:00Z'));assert.equal(s.state,'healthy');assert.equal(s.timestamp,'2026-01-01T00:00:00.000Z')});
test('backup checksum is deterministic',()=>{assert.match(checksum('jason'),/^[a-f0-9]{64}$/);assert.equal(checksum('jason'),checksum('jason'))});
test('backup metadata validates',()=>{assert.equal(validateBackupMetadata({sizeBytes:10,sha256:'a'.repeat(64),createdAt:'2026-01-01T00:00:00Z',database:'jason'}),true);assert.throws(()=>validateBackupMetadata({sizeBytes:0,sha256:'a'.repeat(64),createdAt:'2026-01-01',database:'jason'}),/INVALID_BACKUP_SIZE/)});
test('recovery objectives are explicit',()=>{assert.deepEqual(recoveryObjectives(),{rpoMinutes:60,rtoMinutes:120})});
test('recovery gate identifies missing controls',()=>{assert.deepEqual(readinessForRecovery({backupVerified:true,restoreVerified:false,migrationsVerified:true,secretsVerified:false}),{ready:false,failed:['restoreVerified','secretsVerified']});assert.equal(readinessForRecovery({backupVerified:true,restoreVerified:true,migrationsVerified:true,secretsVerified:true}).ready,true)});
