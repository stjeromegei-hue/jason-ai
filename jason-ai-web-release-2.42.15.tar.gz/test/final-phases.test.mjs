import test from 'node:test'; import assert from 'node:assert/strict';
import {createWorkspace,completeOnboarding,buildAnswer,buildArtifact} from '../dist/product.js';
import {indexKnowledge,searchKnowledge,markStale,supersede,canAccess} from '../dist/knowledge.js';
import {adminCan,makeSnapshot,securityEvent} from '../dist/admin.js';
import {authorizeUsage,normalizePlan} from '../dist/billing-production.js';
import {recordConsent,redactSecrets,validateRetention} from '../dist/privacy.js';
import {certifyRelease,percentile} from '../dist/production.js';

test('workspace onboarding and answer citation dedup',()=>{const w=createWorkspace('t1',' Main ');assert.equal(w.name,'Main');assert.equal(completeOnboarding(w).onboardingComplete,true);const a=buildAnswer(w.id,'Evidence-backed',[{id:'c1',sourceId:'s1',label:'Source'},{id:'c1',sourceId:'s1',label:'Source'}],'HIGH','ANSWER');assert.equal(a.citations.length,1)});
test('artifact creation rejects empty data',()=>{assert.throws(()=>buildArtifact('w','REPORT','','x'),/INVALID_ARTIFACT/);assert.equal(buildArtifact('w','REPORT','R','content').kind,'REPORT')});
test('knowledge is tenant isolated and searchable',()=>{const a=indexKnowledge('t1','d1','Doc','alpha beta gamma');const b=indexKnowledge('t2','d2','Other','alpha');assert.equal(searchKnowledge([a,b],'t1','alpha beta').length,1);assert.equal(canAccess(a,'t2'),false);assert.equal(markStale(a).status,'STALE');assert.equal(supersede(a,'new').version,2)});
test('admin permissions and snapshots',()=>{assert.equal(adminCan('VIEWER','VIEW'),true);assert.equal(adminCan('MEMBER','MANAGE_USERS'),false);assert.equal(makeSnapshot('t',{users:1,documents:2,storageBytes:3,tokens:4,researchRuns:5,securityEvents:6}).tenantId,'t');assert.equal(securityEvent('t','LOGIN_FAILURE','WARN').severity,'WARN')});
test('billing enforces subscription and quota',()=>{const s={tenantId:'t',plan:'FREE',status:'ACTIVE',renewalAt:null};assert.equal(authorizeUsage(s,{documents:0,tokens:0,storageBytes:0,researchRuns:0},{documents:1}).allowed,true);assert.equal(authorizeUsage(s,{documents:50,tokens:0,storageBytes:0,researchRuns:0},{documents:1}).reason,'QUOTA_EXCEEDED');assert.equal(normalizePlan('PRO'),'PRO');assert.equal(normalizePlan('bad'),'FREE')});
test('privacy controls redact credentials',()=>{assert.equal(redactSecrets('api_key=secret123 token=abc'),'api_key=[REDACTED] token=[REDACTED]');assert.equal(recordConsent('t','u','ai','1',true).granted,true);assert.equal(validateRetention({auditDays:365,feedbackDays:180,deletedDocumentGraceDays:30}),true)});
test('release certification and percentile',()=>{const c=certifyRelease('24.0.0',[{name:'build',passed:true,details:'ok'},{name:'tests',passed:true,details:'240 passed'}]);assert.equal(c.passed,true);assert.equal(c.sha256.length,64);assert.equal(percentile([5,1,9,3],.95),9)});
