import test from 'node:test';
import assert from 'node:assert/strict';
import {MemoryRepository} from '../dist/persistence.js';

test('memory repository isolates documents by tenant', async()=>{
 const r=new MemoryRepository();
 const d=await r.saveDocument({tenantId:'t1',name:'a.txt',mime:'text/plain',sizeBytes:3,content:'abc',chunks:['abc']});
 assert.equal((await r.getDocument(d.id,'t1')).id,d.id);
 assert.equal(await r.getDocument(d.id,'t2'),undefined);
});

test('memory repository persists reports',async()=>{
 const r=new MemoryRepository(); const x=await r.saveReport({tenantId:'t1',kind:'REPORT',title:'Test',content:'hello'});
 assert.equal(x.tenantId,'t1'); assert.equal(x.content,'hello');
});
