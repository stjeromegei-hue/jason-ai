import test from 'node:test';import assert from 'node:assert/strict';import {authorize,validateUpload} from '../dist/security.js';import {ingestDocument,buildReport} from '../dist/platform.js';
test('RBAC and tenant-ready user',()=>{assert.equal(authorize({id:'1',tenantId:'t',email:'a@b.com',role:'ADMIN',active:true},'MEMBER'),true);assert.equal(authorize({id:'1',tenantId:'t',email:'a@b.com',role:'VIEWER',active:true},'MEMBER'),false)});
test('upload validation',()=>{assert.equal(validateUpload('a.pdf',100,'application/pdf').ok,true);assert.equal(validateUpload('a.exe',100,'application/octet-stream').ok,false)});
test('document ingestion hashes and chunks',()=>{const x=ingestDocument('t','a.pdf','application/pdf',100,'hello world '.repeat(500));assert.equal(x.document.status,'READY');assert.ok(x.document.sha256.length===64);assert.ok(x.chunks.length>1);assert.equal(x.chunks[0].tenantId,'t')});
test('report generation deterministic shape',()=>{const r=buildReport('t','REPORT','Test',['Evidence','Conclusion']);assert.equal(r.tenantId,'t');assert.match(r.content,/Conclusion/)});

test('unsafe path filename is rejected',()=>{assert.equal(validateUpload('../evil.txt',10,'text/plain').ok,false);});
