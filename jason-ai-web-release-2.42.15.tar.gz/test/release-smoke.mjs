import test from 'node:test';
import assert from 'node:assert/strict';
import {startServer} from '../dist/api.js';

test('API health smoke', async()=>{const server=await startServer(0);await new Promise(r=>server.once('listening',r));const port=server.address().port;try{const r=await fetch(`http://127.0.0.1:${port}/health`);assert.equal(r.status,200);const j=await r.json();assert.equal(j.release,'24212');assert.equal(j.status,'ready');}finally{server.close();}});
