import test from 'node:test';
import assert from 'node:assert/strict';
import { createAgentRun, setAgentInputs, publicAgentRun } from '../dist/agent.js';

test('agent public representation never exposes internal plan inputs', () => {
  const run = createAgentRun('tenant-sec', 'user-sec', {steps:[{tool:'knowledge.search',input:{query:'private secret'}}]});
  setAgentInputs(run, [{input:{query:'private secret'}}]);
  const pub = publicAgentRun(run);
  assert.equal(Object.hasOwn(pub, '_inputs'), false);
  assert.equal(JSON.stringify(pub).includes('private secret'), false);
});
