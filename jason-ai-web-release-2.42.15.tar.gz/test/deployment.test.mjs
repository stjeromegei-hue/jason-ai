import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';

test('production compose has migration promotion gate and database requirement',async()=>{
 const s=await readFile('deploy/docker-compose.production.yml','utf8');
 assert.match(s,/REQUIRE_DATABASE: "true"/);
 assert.match(s,/service_completed_successfully/);
 assert.match(s,/postgres:16-alpine/);
});
test('production proxy enforces HTTPS redirect and forwards request identity',async()=>{
 const s=await readFile('deploy/nginx.production.conf','utf8');
 assert.match(s,/return 308 https:\/\/\$host/);
 assert.match(s,/ssl_protocols TLSv1\.2 TLSv1\.3/);
 assert.match(s,/X-Request-ID/);
 assert.match(s,/proxy_buffering off/);
});
test('production example rejects deterministic AI by default',async()=>{
 const s=await readFile('.env.production.example','utf8');
 assert.match(s,/REQUIRE_DATABASE=true/);
 assert.match(s,/ALLOW_DETERMINISTIC_AI=false/);
 assert.doesNotMatch(s,/POSTGRES_PASSWORD=change-me/);
});
test('deployment documentation states live-deployment boundary and forward-only rollback',async()=>{
 const s=await readFile('DEPLOYMENT-PRODUCTION-21800.md','utf8');
 assert.match(s,/not considered live/);
 assert.match(s,/forward-only/);
});
