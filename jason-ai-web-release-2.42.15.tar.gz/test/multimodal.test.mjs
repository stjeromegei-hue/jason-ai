import test from 'node:test';
import assert from 'node:assert/strict';
import {multimodalStates,mediaRequestFingerprint} from '../dist/multimodal.js';

test('multimodal capabilities fail closed without providers',()=>{
  for(const k of ['JASON_VOICE_INPUT_BASE_URL','JASON_VOICE_OUTPUT_BASE_URL','JASON_IMAGE_BASE_URL','JASON_VIDEO_BASE_URL']) delete process.env[k];
  const s=multimodalStates(); assert.equal(s.length,4); assert.ok(s.every(x=>x.status==='UNAVAILABLE'));
});
test('media fingerprint is deterministic and tenant scoped',()=>{
  const a=mediaRequestFingerprint({tenantId:'a',prompt:'x'},'images');
  const b=mediaRequestFingerprint({tenantId:'a',prompt:'x'},'images');
  const c=mediaRequestFingerprint({tenantId:'b',prompt:'x'},'images');
  assert.equal(a,b); assert.notEqual(a,c);
});
test('paid media provider remains blocked in zero-cost mode',async()=>{
  process.env.JASON_IMAGE_BASE_URL='https://example.invalid/image'; process.env.JASON_IMAGES_PAID='true'; process.env.JASON_PAID_PROVIDERS='false'; process.env.JASON_SPENDING_LIMIT_INR='0';
  const s=multimodalStates().find(x=>x.capability==='images'); assert.equal(s.status,'PAID_OFF');
  delete process.env.JASON_IMAGE_BASE_URL; delete process.env.JASON_IMAGES_PAID;
});
