import test from 'node:test';
import assert from 'node:assert/strict';
import {ConcurrencyLimiter,percentile,runLoad,performanceBudget} from '../dist/performance.js';

test('performance percentile is deterministic',()=>{assert.equal(percentile([1,2,3,4,5],.5),3);assert.equal(percentile([], .95),0);});
test('concurrency limiter never exceeds configured concurrency',async()=>{const limiter=new ConcurrencyLimiter(3);let active=0,max=0;await Promise.all(Array.from({length:20},()=>limiter.run(async()=>{active++;max=Math.max(max,active);await Promise.resolve();active--;})));assert.equal(max,3);});
test('load runner reports successful throughput and latency',async()=>{const r=await runLoad({requests:50,concurrency:5,task:async()=>{await Promise.resolve();}});assert.equal(r.completed,50);assert.equal(r.failed,0);assert.equal(r.errorRate,0);assert.ok(r.rps>0);});
test('load runner contains task failures',async()=>{const r=await runLoad({requests:10,concurrency:2,task:async()=>{throw new Error('synthetic');}});assert.equal(r.failed,10);assert.equal(r.completed,0);assert.equal(r.errorRate,1);});
test('performance budget fails on excessive latency/error rate',()=>{const r={requests:10,concurrency:2,completed:9,failed:1,durationMs:1000,rps:10,p50Ms:100,p95Ms:1500,p99Ms:2500,maxMs:2600,errorRate:.1};const b=performanceBudget(r);assert.equal(b.passed,false);assert.equal(b.reasons.length,3);});
