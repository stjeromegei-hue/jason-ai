import test from 'node:test';
import assert from 'node:assert/strict';
import {BetaStore,onboardingSteps} from '../dist/beta.js';

test('beta onboarding exposes deterministic required steps',()=>{
  const steps=onboardingSteps();
  assert.equal(steps.length,5);
  assert.equal(steps.filter(s=>s.required).length,3);
});

test('beta store records consent and feedback with tenant/user ownership',()=>{
  const store=new BetaStore();
  const c=store.setConsent({tenantId:'t1',userId:'u1',kind:'privacy',version:'v1',accepted:true});
  assert.equal(c.tenantId,'t1'); assert.equal(c.userId,'u1'); assert.equal(c.accepted,true);
  const f=store.recordFeedback({tenantId:'t1',userId:'u1',kind:'idea',message:'Add source comparison.'});
  assert.equal(f.tenantId,'t1'); assert.equal(f.userId,'u1');
});

test('beta store rejects malformed feedback and consent',()=>{
  const store=new BetaStore();
  assert.throws(()=>store.recordFeedback({tenantId:'',userId:'u1',kind:'bug',message:'x'}),/INVALID_FEEDBACK/);
  assert.throws(()=>store.setConsent({tenantId:'t1',userId:'u1',kind:'privacy',version:'',accepted:true}),/INVALID_CONSENT/);
});
