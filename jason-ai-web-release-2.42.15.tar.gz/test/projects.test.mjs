import test from 'node:test';
import assert from 'node:assert/strict';
import {MemoryRepository} from '../dist/persistence.js';
import {createProject,addProjectItem,updateProject,projectFingerprint} from '../dist/projects.js';
test('projects are tenant isolated',async()=>{const repo=new MemoryRepository();const a=createProject('t1','u1',{name:'Alpha'});const b=createProject('t2','u2',{name:'Beta'});await repo.saveProject(a);await repo.saveProject(b);assert.equal((await repo.listProjects('t1')).length,1);assert.equal((await repo.getProject(b.id,'t1')),undefined);});
test('project item is bound to project tenant',async()=>{const repo=new MemoryRepository();const p=createProject('t','u',{name:'P'});await repo.saveProject(p);const i=addProjectItem(p.id,'t',{kind:'REPORT',refId:'r1',title:'R'});await repo.addProjectItem(i);assert.equal((await repo.listProjectItems(p.id,'t')).length,1);assert.throws(()=>addProjectItem(p.id,'other',{kind:'REPORT',refId:'r2'}),/PROJECT_NOT_FOUND/);});
test('project update is bounded and fingerprinted',async()=>{const p=createProject('t','u',{name:'P'});const n=updateProject(p.id,'t',{name:'P2',description:'x'});assert.equal(n.name,'P2');assert.equal(projectFingerprint(n).length,64);assert.throws(()=>updateProject(p.id,'other',{name:'x'}),/PROJECT_NOT_FOUND/);});
test('project input limits',()=>{assert.throws(()=>createProject('t','u',{name:' '.repeat(5)}),/INVALID_PROJECT_NAME/);});
