import test from 'node:test';
import assert from 'node:assert/strict';
import {buildReleaseManifest,evaluatePromotion,deploymentDigest,canPromoteToProduction,validateArtifactSha256} from '../dist/deployment.js';

test('artifact SHA-256 validation is strict',()=>{
  assert.equal(validateArtifactSha256('a'.repeat(64)),true);
  assert.equal(validateArtifactSha256('A'.repeat(64)),false);
  assert.equal(validateArtifactSha256('short'),false);
});

test('required failed check blocks promotion',()=>{
  assert.equal(evaluatePromotion([{name:'build',passed:true,required:true,details:'ok'},{name:'security',passed:false,required:true,details:'failed'}]),'BLOCKED');
  assert.equal(evaluatePromotion([{name:'optional',passed:false,required:false,details:'advisory'}]),'READY');
});

test('release manifest is deterministic apart from timestamp',()=>{
  const input={release:'24200',packageVersion:'2.41.0',environment:'staging',artifactSha256:'b'.repeat(64),migrations:10,checks:[{name:'build',passed:true,required:true,details:'ok'}],generatedAt:'2026-10-07T00:00:00.000Z'};
  const a=buildReleaseManifest(input), b=buildReleaseManifest(input);
  assert.equal(a.status,'READY'); assert.deepEqual(a,b); assert.equal(deploymentDigest(a).length,64);
});

test('production promotion requires a ready staging manifest',()=>{
  const ready=buildReleaseManifest({release:'24200',packageVersion:'2.41.0',environment:'staging',artifactSha256:'c'.repeat(64),migrations:10,checks:[]});
  const prod=buildReleaseManifest({release:'24200',packageVersion:'2.41.0',environment:'production',artifactSha256:'c'.repeat(64),migrations:10,checks:[]});
  assert.equal(canPromoteToProduction(ready),true);
  assert.equal(canPromoteToProduction(prod),false);
});
