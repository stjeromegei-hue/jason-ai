import test from 'node:test';
import assert from 'node:assert/strict';
import {runHappyPath,runFailureMatrix} from '../dist/e2e.js';

test('E2E happy path crosses auth, file, research, AI, report and logout',async()=>{
  const result=await runHappyPath();
  assert.equal(result.passed,true);
  assert.ok(result.checks.length>=10);
});

test('E2E failure matrix fails closed',()=>{
  const results=runFailureMatrix();
  assert.equal(results.every(x=>x.passed),true);
  assert.equal(results.length,5);
});
