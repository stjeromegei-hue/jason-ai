import test from 'node:test';
import assert from 'node:assert/strict';
import { StreamingDeterministicProvider } from '../dist/ai-provider.js';

test('streaming provider emits deltas and terminal usage', async()=>{
  const p=new StreamingDeterministicProvider();
  const events=[];
  for await(const e of p.stream({tenantId:'t',model:'deterministic',prompt:'hello world',maxOutputTokens:20,timeoutMs:1000})) events.push(e);
  assert.ok(events.some(e=>e.type==='delta'));
  assert.equal(events.at(-1).type,'done');
  assert.equal(typeof events.at(-1).usage.outputTokens,'number');
});
