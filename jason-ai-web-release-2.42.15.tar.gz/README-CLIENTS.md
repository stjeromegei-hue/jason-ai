# JASON AI Client Layer — Web/PWA + Private Android

One frontend codebase now serves:

- Browser/Web
- Installable PWA
- Private Android APK through Capacitor

Both clients call the same JASON backend, authentication, projects, knowledge, memory, research and AI Gateway. The frontend does not contain provider secrets.

The capability dashboard uses `/api/capabilities`. Provider quota numbers are environment-driven and are not fabricated; when no quota is configured the UI shows provider unavailable rather than pretending a free allowance exists.

₹0 mode is represented by `spending.limit=0`, `spent=0`, `paidProvidersEnabled=false` unless explicitly enabled server-side.
