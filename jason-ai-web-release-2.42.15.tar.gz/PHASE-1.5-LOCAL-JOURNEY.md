# JASON AI — Phase 1.5 Local Product Journey

Phase 1.5 validates the local product journey end-to-end without a VPS, domain, paid AI provider, or production database.

## Verified flows
- UI shell and PWA assets
- account signup → verification → login → session → logout
- private Projects creation
- artifact/report creation
- document ingestion → Knowledge indexing → Knowledge search
- Memory creation
- deterministic local AI generation
- Agent tool discovery
- multimodal status / ₹0 policy
- paid-provider hard ceiling remains ₹0

## Commands
```bash
npm run phase1:smoke
npm run phase1:journey
npm test
npm run e2e
npm run security:gate
npm run recovery:gate
npm run check:migrations
```

## Important boundary
This is a local-development certification. The deterministic provider is a development fallback and is not represented as production-quality AI. Public deployment, real external model providers, production PostgreSQL, TLS, and signed Android builds remain infrastructure-dependent.
