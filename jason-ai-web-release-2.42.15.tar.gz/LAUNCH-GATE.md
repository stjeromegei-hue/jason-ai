# JASON AI Launch Gate — Phase 20200

## Automated
- TypeScript build must pass.
- Full test suite must pass.
- `/health` must return 200.
- `/ready` must return 200 only when the configured database is reachable.
- `REQUIRE_DATABASE=true` must fail startup when `DATABASE_URL` is absent.

## Infrastructure
- PostgreSQL 16+ provisioned.
- TLS/HTTPS termination configured.
- Secret manager configured; no credentials committed.
- Automated PostgreSQL backups and restore drill completed.
- Monitoring and alerting configured.
- DNS/domain configured.

## Security
- Production secrets rotated from staging.
- Rate limits enabled at edge/application layer.
- Upload limits enforced.
- Audit logging enabled.
- Dependency and container scans reviewed.

## Release
- Staging smoke test passed.
- Authenticated end-to-end test passed.
- Rollback image/version identified.
- Public launch only after a human verifies the production environment.
