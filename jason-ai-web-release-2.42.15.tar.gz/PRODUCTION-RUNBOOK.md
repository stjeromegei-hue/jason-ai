# JASON AI Production Runbook

## 1. Prepare secrets

Copy `.env.production.example` to `.env.production` on the production host and replace every placeholder. Keep `.env.production` outside source control.

Required: `NODE_ENV=production`, `REQUIRE_DATABASE=true`, a real PostgreSQL URL, database credentials, and `ALLOW_DETERMINISTIC_AI=false`.

JASON's default spending policy remains ₹0: paid providers disabled and automatic billing disabled. If this policy is changed later, it must be an explicit configuration decision.

## 2. TLS

The bundled Nginx terminator expects `deploy/certs/fullchain.pem` and `deploy/certs/privkey.pem`. Supply real certificates on the host; never commit private keys. If TLS is terminated by an upstream load balancer, set `JASON_TLS_TERMINATED_EXTERNALLY=true` and enforce HTTPS at that upstream layer.

## 3. Preflight

```bash
npm ci
npm run build
NODE_ENV=production REQUIRE_DATABASE=true DATABASE_URL='postgresql://...' POSTGRES_DB=jason POSTGRES_USER='...' POSTGRES_PASSWORD='...' npm run verify:env
# With TLS files present:
NODE_ENV=production REQUIRE_DATABASE=true DATABASE_URL='postgresql://...' POSTGRES_DB=jason POSTGRES_USER='...' POSTGRES_PASSWORD='...' npm run production:preflight
```

## 4. Deploy

```bash
docker compose -f deploy/docker-compose.production.yml up -d --build
```

The migration service must finish successfully before the application becomes healthy. Verify `/health` through the HTTPS endpoint and inspect the container health states.

## 5. Backup / recovery

Run `scripts/backup-postgres.sh` using production credentials and retain backups outside the application host. Test restoration periodically with `scripts/restore-postgres.sh`. Rollback is forward-only: promote a previously verified immutable release; do not mutate production data or binaries manually.

## 6. AI provider

Production must use a real configured provider/runtime if AI generation is enabled. Never enable the deterministic development fallback as a substitute for a real model in production.

## 7. Launch declaration

A release is only considered live after DNS, TLS, database connectivity, migrations, health checks, and post-deployment smoke tests succeed against the real production endpoint. This repository alone is not proof of public deployment.

## 8. One-command launch

On the production host, after installing Docker and placing the real `.env.production` and TLS certificates:

```bash
JASON_PUBLIC_URL=https://your-domain.example npm run launch:production
```

This verifies the environment, runs preflight, validates Compose, builds/starts the stack, waits for the application health endpoint, and—when `JASON_PUBLIC_URL` is set—performs an external HTTPS `/health` smoke test. It never enables paid providers automatically.

For a later smoke check without changing the stack:

```bash
npm run postdeploy:smoke -- https://your-domain.example
```
