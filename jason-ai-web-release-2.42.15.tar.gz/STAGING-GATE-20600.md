# JASON AI Staging Gate — 20600

Required before production promotion:

1. Run `npm ci && npm run build && npm test`.
2. Provision a non-default PostgreSQL staging database.
3. Set `NODE_ENV=staging`, `REQUIRE_DATABASE=true`, and a real `DATABASE_URL`.
4. Run migrations with `npm run migrate`.
5. Start the application and run `BASE_URL=https://staging.example npm run staging:check`.
6. Execute `scripts/backup-postgres.sh` and restore into a disposable database with `scripts/restore-postgres.sh`.
7. Verify tenant isolation, authentication, file ingestion, research planning, and report creation with E2E tests.
8. Record the release SHA-256 and promote only if every gate passes.

No production credential belongs in source control.
