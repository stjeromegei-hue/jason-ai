# Private Android APK build

The repository now contains a native Android wrapper project. It loads the same JASON Web/PWA frontend and API, so Web and APK share the same account and backend.

Before release, replace `JASON_API_BASE` in `android/app/build.gradle` with the HTTPS production JASON URL.

Build with Android Studio or Gradle after installing the Android SDK and Gradle/Android build tooling. This environment does not contain the Android SDK/Gradle toolchain, so a signed APK cannot be truthfully claimed as compiled here.

Security:
- HTTPS only (`usesCleartextTraffic=false`)
- No AI provider secrets in APK
- Same server-side authentication and zero-cost policy as Web/PWA
- `ai.jason.private` application ID
