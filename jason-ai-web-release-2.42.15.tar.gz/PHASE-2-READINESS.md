# JASON AI — Phase 2 Readiness

Phase 2 is the transition from the verified ₹0 local product to a real production service.

## Already ready

- Production Docker Compose stack
- PostgreSQL migration path
- HTTPS reverse-proxy configuration
- Production preflight
- Launch gate
- Security gate
- Recovery/backup tooling
- Rollback tooling
- Post-deployment HTTPS smoke test
- Hard ₹0 spending ceiling
- Paid AI providers disabled by default

## Required external infrastructure

1. Linux VPS or equivalent Docker host
2. Public DNS record for the chosen domain/subdomain
3. TLS certificate, or upstream TLS termination
4. Production PostgreSQL credentials (the supplied Compose stack can host PostgreSQL initially)
5. Optional real AI provider/runtime if production AI generation is required

## Recommended initial policy

```text
JASON_PAID_PROVIDERS=false
JASON_SPENDING_LIMIT_INR=0
AI_PROVIDER_PAID=false
ALLOW_DETERMINISTIC_AI=false   # production
```

Do not place API keys, database passwords, TLS private keys, or Android signing keys in source control.

## Host launch

```bash
npm ci
npm run build
npm run phase2:readiness
npm run production:preflight
npm run launch:production
```

Set `JASON_PUBLIC_URL=https://your-domain.example` for the external HTTPS smoke test.

## Important boundary

The repository can certify source readiness locally, but public deployment cannot be honestly marked complete until a real host, DNS, TLS, and production secrets exist.
