# JASON AI Web Release 2.42.15

## Release status

- Web/PWA release: READY
- Build: PASS
- Tests: 185/185 PASS
- E2E: PASS
- Security gate: PASS
- Recovery gate: PASS
- Migration check: PASS (15 migrations)
- Local `/health`: PASS
- Local `/ready`: PASS
- Local Web UI: HTTP 200
- Paid providers: OFF by default / ₹0 spending limit

## Included in 2.42.15

- Existing JASON AI Web/PWA product surface
- Authentication and tenant isolation
- Chat/reasoning/task routing
- Research/evidence/verification foundations
- File intelligence and private Knowledge/RAG
- Memory and Projects
- Safe Agents and approvals
- Creation/reporting foundations
- AI provider pools and capability-aware routing
- Adaptive quota scheduling
- Provider cooldown and 429/rate-limit handling
- Persistent provider scheduler state in PostgreSQL
- Capability-scoped provider state
- Production Docker/NGINX configuration
- Migrations, security, recovery and release gates

## Production deployment boundary

The repository is deployment-ready, but this environment does not contain the customer's production hosting credentials, domain/DNS, TLS certificate or production AI-provider credentials. No public URL is claimed until an actual deployment succeeds.

Production must provide:

1. A reachable Docker-compatible host (or equivalent deployment target).
2. PostgreSQL credentials/URL.
3. TLS termination with a valid certificate, either through this NGINX stack or an external HTTPS proxy.
4. At least one permitted production AI provider/model for real AI responses. Paid providers remain disabled when the ₹0 policy is active.
5. A public HTTPS hostname, assigned through DNS.

Run `scripts/launch-production.sh` after `.env.production` is populated. Set `JASON_PUBLIC_URL=https://your-hostname` to enable the post-deploy HTTPS smoke test.
